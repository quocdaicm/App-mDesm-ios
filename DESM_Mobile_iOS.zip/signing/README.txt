Chứng chỉ ký app cho workflow .github/workflows/build.yml (bạn đã chọn để công khai trong repo).
  cert.p12 (chứng chỉ + khoá riêng) · cert_password.txt (mật khẩu) · app.mobileprovision (profile Ad Hoc, gắn UDID 1 máy)
Workflow ưu tiên GitHub Secrets (CERT_P12_BASE64, CERT_PASSWORD, PROFILE_BASE64) nếu có, không thì dùng các file này.
Nếu sau này muốn thu hồi: developer.apple.com > Certificates > Revoke, rồi tạo chứng chỉ + profile mới và thay file.
