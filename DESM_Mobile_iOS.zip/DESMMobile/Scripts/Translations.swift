// Translations.swift — từ điển Anh→Việt cho giao diện DESM (khớp nguyên chuỗi). Dịch phía máy khách, dữ liệu không bị đổi.
// Bổ sung từ mới: Cài đặt > Ngôn ngữ > "Sao chép chuỗi chưa dịch" rồi điền vào "Từ điển bổ sung" (desmCustomDict).
// Xem DEV_NOTES.md.
import Foundation
import SwiftUI

/// Từ điển Anh → Việt cho giao diện web DESM (khớp nguyên cả chuỗi, không phân biệt hoa/thường).
/// - Chuỗi gốc viết HOA toàn bộ (từ 3 chữ cái trở lên) thì bản dịch tự được viết HOA theo.
/// - Dữ liệu (mã kiện, mô tả hàng, tên vị trí...) không có trong từ điển nên không bị đổi.
/// - Thiếu từ nào: Cài đặt > Ngôn ngữ > "Sao chép chuỗi chưa dịch", rồi bổ sung ở ô "Từ điển bổ sung".
enum ViDict {
    static let pairs: [[String]] = [
        // Menu & khung trang
        ["Dashboard - DESM", "Bảng điều khiển - DESM"],
        ["Doosan Enerbility Supply Management", "Quản lý cung ứng Doosan Enerbility"],
        ["Notice", "Thông báo"],
        ["Information", "Thông tin"],
        ["Vessel Map", "Bản đồ tàu"],
        ["EPC Supply MGMT", "Quản lý cung ứng EPC"],
        ["Supply MGMT 2.0", "Quản lý cung ứng 2.0"],
        ["P/L Extractor - MPW", "Trích xuất P/L - MPW"],
        ["Monthly Progress", "Tiến độ hàng tháng"],
        ["Shipping Mark", "Ký mã hiệu"],
        ["Onshore PO", "PO trong nước"],
        ["Requisitions (POR)", "Yêu cầu mua hàng (POR)"],
        ["Requisition Manage (POR Manage)", "Quản lý yêu cầu mua hàng (POR)"],
        ["Purchase Order & Contract", "Đơn đặt hàng & Hợp đồng"],
        ["Quality Control", "Kiểm soát chất lượng"],
        ["Shipping Status", "Tình trạng vận chuyển"],
        ["Site Material MGMT", "Quản lý vật tư công trường"],
        ["WBS & PKG/Item search", "Tìm WBS & Kiện hàng/Hạng mục"],
        ["Package", "Kiện hàng"],
        ["Detail Item", "Hạng mục chi tiết"],
        ["Material Receiving", "Nhận vật tư"],
        ["Material Inspection(OPI / OSDM)", "Kiểm tra vật tư (OPI / OSDM)"],
        ["Special Item Management", "Quản lý hạng mục đặc biệt"],
        ["Requisition for Stored Items", "Yêu cầu xuất hàng lưu kho"],
        ["RSI Creation", "Tạo RSI"],
        ["Outgoing Control", "Kiểm soát xuất kho"],
        ["RSI Summary", "Tổng hợp RSI"],
        ["Work In Process Control", "Kiểm soát công việc đang thực hiện"],
        ["Material Return Form", "Phiếu trả vật tư"],
        ["MRF Creation", "Tạo MRF"],
        ["Return Control", "Kiểm soát trả hàng"],
        ["MRF Summary", "Tổng hợp MRF"],
        ["Material Map", "Bản đồ vật tư"],
        ["Site User MGMT", "Quản lý người dùng công trường"],
        ["Site User Project MGMT", "Quản lý dự án của người dùng công trường"],
        ["Project Digital Hub", "Trung tâm số dự án"],
        ["Refresh", "Làm mới"],
        ["Language", "Ngôn ngữ"],
        ["Logout", "Đăng xuất"],
        ["Login", "Đăng nhập"],
        ["Remove Tab", "Đóng tab"],
        ["Opensouce License", "Giấy phép mã nguồn mở"],
        ["Rendering ...", "Đang hiển thị ..."],
        ["Go Top", "Lên đầu trang"],
        ["Select Files", "Chọn tệp"],

        // Hộp thoại
        ["Cancel", "Hủy"],
        ["Title", "Tiêu đề"],
        ["Message", "Thông báo"],
        ["Close", "Đóng"],
        ["Are you sure to comfirm?", "Bạn có chắc chắn muốn xác nhận?"],
        ["Are you sure to confirm?", "Bạn có chắc chắn muốn xác nhận?"],
        ["Log", "Nhật ký"],
        ["Password Change", "Đổi mật khẩu"],
        ["Current Password", "Mật khẩu hiện tại"],
        ["New Password", "Mật khẩu mới"],
        ["New Password Confirmation", "Xác nhận mật khẩu mới"],
        ["Save", "Lưu"],
        ["No data found", "Không có dữ liệu"],

        // Bộ lọc & nút (màn hình Package)
        ["Search", "Tìm kiếm"],
        ["Reset", "Đặt lại"],
        ["Project", "Dự án"],
        ["Shipment No.", "Số lô hàng"],
        ["All", "Tất cả"],
        ["Packing List No.", "Số Packing List"],
        ["Package No.", "Số kiện hàng"],
        ["Description", "Mô tả"],
        ["Location", "Vị trí"],
        ["All Exists", "Tất cả đã có"],
        ["All Not Exists", "Tất cả chưa có"],
        ["Vendor", "Nhà cung cấp"],
        ["Remark", "Ghi chú"],
        ["MRR Received", "Đã nhận MRR"],
        ["Yes", "Có"],
        ["No", "Không"],
        ["Received", "Đã nhận"],
        ["Customs", "Hải quan"],
        ["Material Confirm", "Xác nhận vật tư"],
        ["MRR Result", "Kết quả MRR"],
        ["Good", "Tốt"],
        ["Defect", "Lỗi"],
        ["MRR Received Date", "Ngày nhận MRR"],
        ["Received Date", "Ngày nhận"],
        ["MIR Category", "Phân loại MIR"],
        ["Electrical", "Điện"],
        ["Mechanical", "Cơ khí"],
        ["I&C", "Đo lường & Điều khiển"],
        ["Civil", "Xây dựng"],
        ["Commissioning", "Chạy thử"],
        ["Etc", "Khác"],
        ["Package Status", "Trạng thái kiện hàng"],
        ["Open", "Mở"],
        ["Partially", "Một phần"],
        ["Detail Item Creation", "Tạo hạng mục chi tiết"],
        ["Material Cancel", "Hủy vật tư"],
        ["Location Delete", "Xóa vị trí"],
        ["Location Update", "Cập nhật vị trí"],
        ["Received Date Update", "Cập nhật ngày nhận"],
        ["QR Code", "Mã QR"],
        ["Area", "Khu vực"],

        // Tiêu đề cột lưới
        ["Material", "Vật tư"],
        ["Confirm", "Xác nhận"],
        ["Cancel Date", "Ngày hủy"],
        ["Canceled By", "Người hủy"],
        ["Invoice No", "Số hóa đơn"],
        ["Closed", "Đã đóng"],
        ["Description of Goods", "Mô tả hàng hóa"],
        ["Specification", "Quy cách"],
        ["Packing Style", "Kiểu đóng gói"],
        ["Measurement", "Kích thước"],
        ["Net Weight", "Trọng lượng tịnh"],
        ["Gross Weight", "Trọng lượng cả bì"],
        ["Excel Remark", "Ghi chú Excel"],
        ["Visual Check", "Kiểm tra ngoại quan"],
        ["Last Outgoing Date", "Ngày xuất gần nhất"],
        ["QTY", "SL"],
        ["(UNIT, spare part..)", "(Đơn vị, phụ tùng..)"],
        ["Location Last Updated Date", "Ngày cập nhật vị trí gần nhất"],
        ["Location Last Updated By", "Người cập nhật vị trí gần nhất"],
        ["Shortage", "Thiếu"],
        ["Overage", "Thừa"],
        ["Damage", "Hư hỏng"],
        ["Missing", "Mất"],
        ["Style:", "Kiểu:"],
        ["Size:", "Cỡ:"],
        ["Normal", "Bình thường"],
        ["Scale:", "Tỉ lệ:"],

        // Từ thông dụng
        ["Add", "Thêm"],
        ["Delete", "Xóa"],
        ["Edit", "Sửa"],
        ["Update", "Cập nhật"],
        ["Create", "Tạo mới"],
        ["Upload", "Tải lên"],
        ["Download", "Tải xuống"],
        ["Export", "Xuất file"],
        ["Import", "Nhập file"],
        ["Print", "In"],
        ["Submit", "Gửi"],
        ["Approve", "Phê duyệt"],
        ["Reject", "Từ chối"],
        ["Apply", "Áp dụng"],
        ["Select", "Chọn"],
        ["Select All", "Chọn tất cả"],
        ["Status", "Trạng thái"],
        ["Date", "Ngày"],
        ["From", "Từ"],
        ["To", "Đến"],
        ["Remarks", "Ghi chú"],
        ["Total", "Tổng"],
        ["Unit", "Đơn vị"],
        ["Name", "Tên"],
        ["User", "Người dùng"],
        ["Password", "Mật khẩu"],
        ["Error", "Lỗi"],
        ["Success", "Thành công"],
        ["Warning", "Cảnh báo"],
        ["Loading...", "Đang tải..."],
        ["Please select", "Vui lòng chọn"],
        ["Saved successfully.", "Đã lưu thành công."],
        ["Deleted successfully.", "Đã xóa thành công."],
        ["Do you want to save?", "Bạn có muốn lưu không?"],
        ["Do you want to delete?", "Bạn có muốn xóa không?"],
    ]
}

// MARK: - Dịch màn hình native (nút "Dịch" ở Package, Package chi tiết, RSI Detail)
//
// - Nhãn cố định (Received, V/C, SHORT, REMAIN...): tra từ điển ngay, không cần mạng (ViDict.pairs + nativePairs).
// - Dữ liệu (mô tả hàng, ghi chú...): dịch bằng "AI riêng" của app (Cài đặt > AI riêng, cần khoá API), bản dịch được nhớ lại theo từng chuỗi.
// Không đụng tới dữ liệu gửi lên DESM: chỉ đổi chữ HIỂN THỊ. Chưa build/chưa thử máy thật.

extension ViDict {
    /// Nhãn riêng của các màn native (ưu tiên hơn từ điển web khi trùng).
    static let nativePairs: [[String]] = [
        ["Package", "Kiện hàng"],
        ["Detail Item", "Hạng mục chi tiết"],
        ["Detail Item Lines", "Số dòng hạng mục"],
        ["Detail Item List", "Danh sách hạng mục"],
        ["RSI & MRF List", "Danh sách RSI & MRF"],
        ["RSI Detail", "Chi tiết RSI"],
        ["MRF Detail", "Chi tiết MRF"],
        ["REMAIN", "CÒN LẠI"],
        ["Remain", "Còn lại"],
        ["S/C & Excel Remarks", "Ghi chú S/C & Excel"],
        ["REMARKS", "GHI CHÚ"],
        ["Received", "Ngày nhận"],
        ["MRR Received", "Ngày nhận MRR"],
        ["V/C", "Kiểm tra ngoại quan"],
        ["Good", "Tốt"],
        ["L(cm)", "Dài(cm)"],
        ["W(cm)", "Rộng(cm)"],
        ["H(cm)", "Cao(cm)"],
        ["CBM", "Thể tích (CBM)"],
        ["Net(kg)", "Tịnh(kg)"],
        ["Gross", "Cả bì(kg)"],
        ["SHORT", "THIẾU"],
        ["OVER", "THỪA"],
        ["DMG", "HƯ HỎNG"],
        ["MISSING", "MẤT"],
        ["CLOSE", "ĐÃ ĐÓNG"],
        ["OPEN", "ĐANG MỞ"],
        ["SKID", "SKID (khung pallet)"],
        ["In Q'ty", "SL nhập"],
        ["Out Q'ty", "SL xuất"],
        ["RSI Q'ty", "SL RSI"],
        ["RSI Bal.", "Dư RSI"],
        ["MRF Q'ty", "SL MRF"],
        ["MRF Bal.", "Dư MRF"],
        ["Cancel", "Huỷ"],
        ["Location Update", "Cập nhật vị trí"],
        ["Location Delete", "Xoá vị trí"],
        ["Material Confirm", "Xác nhận vật tư"],
        ["Material Cancel", "Huỷ xác nhận vật tư"],
        ["Customs Y/N", "Hải quan Y/N"],
        ["Packing List No.", "Số Packing List"],
        ["Package No.", "Số kiện"],
        ["Description", "Mô tả"],
        ["PKG.", "KIỆN"],
        ["ALL", "TẤT CẢ"],
        ["Search", "Tìm kiếm"],
    ]

    private static let lookupMap: [String: String] = {
        var m: [String: String] = [:]
        for p in pairs where p.count == 2 { m[p[0].lowercased()] = p[1] }
        for p in nativePairs where p.count == 2 { m[p[0].lowercased()] = p[1] }
        return m
    }()

    /// Tra nhãn (không phân biệt hoa/thường). "Location Update (3)" -> "Cập nhật vị trí (3)". Không có thì trả nil.
    static func lookup(_ s: String) -> String? {
        let k = s.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !k.isEmpty else { return nil }
        if let v = lookupMap[k.lowercased()] { return caseLike(k, v) }
        if k.hasSuffix(")"), let r = k.range(of: " (", options: .backwards) {
            let base = String(k[k.startIndex..<r.lowerBound])
            if let v = lookupMap[base.lowercased()] { return caseLike(base, v) + String(k[r.lowerBound...]) }
        }
        return nil
    }

    private static func caseLike(_ orig: String, _ v: String) -> String {
        let letters = orig.filter { $0.isLetter }
        return (letters.count >= 3 && orig == orig.uppercased()) ? v.uppercased() : v
    }
}

@MainActor
final class NativeTranslator: ObservableObject {
    static let shared = NativeTranslator()

    @Published var on: Bool { didSet { UserDefaults.standard.set(on, forKey: "desmNativeVi") } }
    @Published var busy = false
    @Published var note: String? = nil
    @Published private(set) var data: [String: String] = [:]   // chuỗi dữ liệu tiếng Anh -> bản dịch AI
    private static let dataKey = "desmNativeViData.v1"

    private init() {
        on = UserDefaults.standard.bool(forKey: "desmNativeVi")
        if let d = UserDefaults.standard.dictionary(forKey: Self.dataKey) as? [String: String] { data = d }
    }

    /// Chuỗi để hiển thị: tắt dịch -> nguyên văn; bật -> nhãn (từ điển) rồi bản dịch AI đã nhớ của dữ liệu.
    func t(_ s: String) -> String {
        guard on, !s.isEmpty else { return s }
        if let v = ViDict.lookup(s) { return v }
        return data[s.trimmingCharacters(in: .whitespacesAndNewlines)] ?? s
    }

    /// Chuỗi dữ liệu có đáng gửi AI dịch không (bỏ mã, số, chuỗi đã là tiếng Việt, chuỗi ngắn).
    static func worth(_ s: String) -> Bool {
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.count < 4 || t.count > 400 { return false }
        if ViDict.lookup(t) != nil { return false }
        let vi = "ăâđêôơưáàảãạấầẩẫậắằẳẵặéèẻẽẹếềểễệíìỉĩịóòỏõọốồổỗộớờởỡợúùủũụứừửữựýỳỷỹỵ"
        if t.lowercased().contains(where: { vi.contains($0) }) { return false }
        if !t.contains(" ") && t.rangeOfCharacter(from: .decimalDigits) != nil { return false }
        return t.filter { $0.isLetter }.count >= 3
    }

    /// Dịch các chuỗi dữ liệu chưa có bản dịch bằng AI riêng (mỗi lượt 25 chuỗi). Lỗi thì ghi vào `note`, nhãn vẫn dịch bằng từ điển.
    func translate(_ texts: [String]) async {
        guard on else { return }
        while busy {
            try? await Task.sleep(nanoseconds: 300_000_000)
            if !on { return }
        }
        var seen = Set<String>()
        var todo: [String] = []
        for raw in texts {
            let t = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if data[t] == nil, !seen.contains(t), Self.worth(t) { seen.insert(t); todo.append(t) }
        }
        if todo.isEmpty { return }
        busy = true
        note = nil
        defer { busy = false }
        if Self.webOn {
            let got = await Self.webTranslateAll(todo)
            if !got.isEmpty {
                if data.count > 800 { data = [:] }
                for (k, v) in got { data[k] = v }
                UserDefaults.standard.set(data, forKey: Self.dataKey)
            }
            todo = todo.filter { data[$0] == nil }
            if todo.isEmpty { return }
        }
        let cands = AIStore.candidates()
        if cands.isEmpty {
            note = Self.webOn ? "Không dịch được một số mô tả hàng (mạng hoặc Google Dịch từ chối). Thử lại sau, hoặc nhập khoá ở Cài đặt > AI riêng."
                              : "Nhãn đã dịch. Muốn dịch cả mô tả hàng: bật Google Dịch trong Cài đặt > Ngôn ngữ, hoặc nhập khoá ở Cài đặt > AI riêng."
            return
        }
        let system = "You translate English construction and electrical material descriptions from a power plant project into natural Vietnamese. Keep part numbers, codes, units, sizes and brand names unchanged. Reply with ONLY a JSON array of strings, same length and same order as the input array. No explanation, no code fences."
        var lastError = ""
        var start = 0
        while start < todo.count {
            let chunk = Array(todo[start..<min(start + 25, todo.count)])
            start += 25
            guard let inp = try? JSONSerialization.data(withJSONObject: chunk), let user = String(data: inp, encoding: .utf8) else { continue }
            var done = false
            for p in cands {
                do {
                    let turn = try await AIClient.chat(p, key: AIStore.key(p.id), model: AIStore.model(p), system: system,
                                                       msgs: [.user(user)], tools: [])
                    let out = Self.parseArray(turn.text)
                    if out.isEmpty { lastError = "AI trả về định dạng lạ"; continue }
                    if data.count > 800 { data = [:] }
                    for i in 0..<min(out.count, chunk.count) where !out[i].isEmpty { data[chunk[i]] = out[i] }
                    done = true
                    break
                } catch {
                    lastError = error.localizedDescription
                    if AIStore.isTransient(error) { AIStore.markFailed(p.id) }
                }
            }
            if !done { break }
        }
        UserDefaults.standard.set(data, forKey: Self.dataKey)
        if !lastError.isEmpty && todo.contains(where: { data[$0] == nil }) {
            note = "Chưa dịch được một số mô tả hàng: " + lastError
        }
    }

    /// Bật: mô tả hàng được gửi lên Google Dịch (không cần khoá). Tắt: chỉ dùng AI riêng nếu có khoá. Mặc định bật.
    static var webOn: Bool {
        get { UserDefaults.standard.object(forKey: "desmNativeViWeb") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "desmNativeViWeb") }
    }

    private static let webSession: URLSession = {
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = 15
        cfg.timeoutIntervalForResource = 20
        return URLSession(configuration: cfg)
    }()

    /// Dịch một chuỗi Anh -> Việt qua điểm cuối công khai của Google Dịch (không chính thức, có thể bị giới hạn tần suất).
    nonisolated static func webTranslate(_ text: String) async -> String? {
        var comps = URLComponents(string: "https://translate.googleapis.com/translate_a/single")
        comps?.queryItems = [
            URLQueryItem(name: "client", value: "gtx"), URLQueryItem(name: "sl", value: "en"),
            URLQueryItem(name: "tl", value: "vi"), URLQueryItem(name: "dt", value: "t"),
            URLQueryItem(name: "q", value: text),
        ]
        guard let url = comps?.url else { return nil }
        do {
            let (data, resp) = try await webSession.data(from: url)
            guard (resp as? HTTPURLResponse)?.statusCode == 200,
                  let root = try JSONSerialization.jsonObject(with: data) as? [Any],
                  let segs = root.first as? [Any] else { return nil }
            let out = segs.compactMap { ($0 as? [Any])?.first as? String }.joined()
            return out.isEmpty ? nil : out
        } catch { return nil }
    }

    /// Dịch song song (tối đa 5 chuỗi cùng lúc), trả về các chuỗi dịch được.
    nonisolated static func webTranslateAll(_ list: [String]) async -> [String: String] {
        var result: [String: String] = [:]
        var idx = 0
        while idx < list.count {
            let batch = Array(list[idx..<min(idx + 5, list.count)])
            idx += 5
            await withTaskGroup(of: (String, String?).self) { g in
                for t in batch { g.addTask { (t, await Self.webTranslate(t)) } }
                for await (k, v) in g { if let v = v { result[k] = v } }
            }
        }
        return result
    }

    private static func parseArray(_ text: String) -> [String] {
        guard let a = text.firstIndex(of: "["), let b = text.lastIndex(of: "]"), a < b else { return [] }
        let json = String(text[a...b])
        guard let d = json.data(using: .utf8), let arr = (try? JSONSerialization.jsonObject(with: d)) as? [Any] else { return [] }
        return arr.map { ($0 as? String) ?? "" }
    }
}

/// Nút "Dịch" ở thanh trên của màn: bật/tắt dịch màn hình. `texts` = các chuỗi dữ liệu đang hiện (để AI dịch); `signature` đổi khi dữ liệu đổi.
struct NativeTranslateButton: View {
    @ObservedObject private var tr = NativeTranslator.shared
    var signature: Int = 0
    var texts: () -> [String] = { [] }

    var body: some View {
        Button {
            tr.on.toggle()
            if tr.on { Task { await tr.translate(texts()) } } else { tr.note = nil }
        } label: {
            ZStack {
                if tr.busy { ProgressView().scaleEffect(0.8) }
                else { Image(systemName: tr.on ? "character.bubble.fill" : "character.bubble").font(.system(size: 19, weight: .semibold)) }
            }
            .frame(width: 30, height: 30)
            .background(Circle().fill(tr.on ? Color.tabBlue : Color.clear))
        }
        .foregroundColor(tr.on ? Color.white : Color.primary)
        .accessibilityLabel(tr.on ? "Tắt dịch màn hình" : "Dịch màn hình sang tiếng Việt")
        .task(id: tr.on ? signature : -1) {
            if tr.on { await tr.translate(texts()) }
        }
    }
}

/// Dòng báo nhỏ khi dịch dữ liệu bằng AI không được (đặt đầu nội dung màn hình).
struct NativeTranslateNote: View {
    @ObservedObject private var tr = NativeTranslator.shared
    var body: some View {
        if tr.on, let n = tr.note {
            Text(n).font(.system(size: 12, weight: .medium)).foregroundColor(.orange)
                .frame(maxWidth: .infinity, alignment: .leading).padding(10)
                .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.orange.opacity(0.12)))
        }
    }
}
