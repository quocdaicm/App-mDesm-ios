// DesmExport.swift — xuất bảng dữ liệu của mọi màn hình ra CSV và Excel (.xlsx), không dùng thư viện ngoài.
//
// Cách dùng trong một màn (nội dung của sheet đã gắn `.desmSheet()` hoặc `.desmShotButton()`):
//     .desmExport { DesmTable(name: "tien-do", headers: ["A", "B"], rows: [["1", "2"]]) }
// Closure chỉ chạy khi người dùng bấm nút xuất (nút tròn nằm trên nút máy ảnh), nên luôn lấy dữ liệu MỚI NHẤT của màn.
// Closure phải đọc dữ liệu từ ViewModel/@State (không chụp bản sao giá trị của thuộc tính `let`).
//
// CSV: UTF-8 có BOM (Excel đọc đúng tiếng Việt), xuống dòng CRLF.
// XLSX: tự ghép file zip (không nén) gồm 1 sheet, hàng tiêu đề đậm + cố định + bộ lọc; ô là số thuần thì ghi dạng số,
//       mã có số 0 đứng đầu (vd 0009) giữ nguyên dạng chữ.
// CHƯA build Xcode / chưa mở thử bằng Excel thật.

import SwiftUI

struct DesmTable {
    var name: String
    var headers: [String]
    var rows: [[String]]
}

enum DesmExportFormat {
    case csv, xlsx
    var ext: String { self == .csv ? "csv" : "xlsx" }
}

enum DesmExport {
    // MARK: Ghi file

    /// Ghi bảng ra file tạm, trả về đường dẫn để chia sẻ. nil nếu ghi lỗi.
    static func write(_ t: DesmTable, as format: DesmExportFormat) -> URL? {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyyMMdd-HHmmss"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(slug(t.name))-\(f.string(from: Date())).\(format.ext)")
        let data = format == .csv ? csvData(t) : xlsxData(t)
        do { try data.write(to: url, options: .atomic); return url } catch { return nil }
    }

    static func slug(_ s: String) -> String {
        let keep = s.lowercased().unicodeScalars.map { c -> Character in
            (c.isASCII && (CharacterSet.alphanumerics.contains(c) || c == "-" || c == "_")) ? Character(c) : "-"
        }
        let r = String(keep).split(separator: "-", omittingEmptySubsequences: true).joined(separator: "-")
        return r.isEmpty ? "desm" : r
    }

    // MARK: CSV

    static func csvCell(_ s: String) -> String {
        if s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r") {
            return "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\""
        }
        return s
    }

    static func csvText(_ t: DesmTable) -> String {
        var lines = [t.headers.map(csvCell).joined(separator: ",")]
        for r in t.rows { lines.append(r.map(csvCell).joined(separator: ",")) }
        return lines.joined(separator: "\r\n")
    }

    static func csvData(_ t: DesmTable) -> Data {
        var d = Data([0xEF, 0xBB, 0xBF])
        d.append(Data(csvText(t).utf8))
        return d
    }

    // MARK: XLSX

    static func xmlEscape(_ s: String) -> String {
        var o = ""
        o.reserveCapacity(s.count + 8)
        for u in s.unicodeScalars {
            switch u {
            case "&": o += "&amp;"
            case "<": o += "&lt;"
            case ">": o += "&gt;"
            case "\"": o += "&quot;"
            case "\n", "\t": o.unicodeScalars.append(u)
            default:
                if u.value < 0x20 || u.value == 0xFFFE || u.value == 0xFFFF { continue }   // ký tự không hợp lệ trong XML
                o.unicodeScalars.append(u)
            }
        }
        return o
    }

    static func colName(_ i: Int) -> String {
        var n = i + 1, s = ""
        while n > 0 { let r = (n - 1) % 26; s = String(UnicodeScalar(UInt8(65 + r))) + s; n = (n - 1) / 26 }
        return s
    }

    /// Số thuần (không số 0 đứng đầu, tối đa 15 chữ số) mới ghi dạng số; còn lại là chữ.
    static func numberValue(_ s: String) -> String? {
        let t = s.trimmingCharacters(in: .whitespaces)
        if t.isEmpty || t.count > 15 { return nil }
        var digits = 0, dots = 0
        for (i, c) in t.enumerated() {
            if c.isASCII && c.isNumber { digits += 1 }
            else if c == "." { dots += 1 }
            else if c == "-" && i == 0 { continue }
            else { return nil }
        }
        if digits == 0 || dots > 1 || t.hasSuffix(".") || t.hasPrefix(".") { return nil }
        let body = t.hasPrefix("-") ? String(t.dropFirst()) : t
        if body.count > 1 && body.hasPrefix("0") && !body.hasPrefix("0.") { return nil }
        return t
    }

    static func sheetName(_ s: String) -> String {
        var n = s.filter { !"[]:*?/\\".contains($0) }
        if n.isEmpty { n = "DESM" }
        return String(n.prefix(31))
    }

    static func xlsxData(_ t: DesmTable) -> Data {
        let colCount = max(t.headers.count, t.rows.map { $0.count }.max() ?? 0, 1)
        var widths = [Int](repeating: 8, count: colCount)
        func note(_ c: Int, _ s: String) {
            let longest = s.split(separator: "\n", omittingEmptySubsequences: false).map { $0.count }.max() ?? 0
            widths[c] = min(60, max(widths[c], longest + 2))
        }
        for (c, h) in t.headers.enumerated() { note(c, h) }
        for r in t.rows { for (c, v) in r.enumerated() where c < colCount { note(c, v) } }

        var sheet = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
        sheet += "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
        sheet += "<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>"
        sheet += "<cols>"
        for c in 0..<colCount { sheet += "<col min=\"\(c + 1)\" max=\"\(c + 1)\" width=\"\(widths[c])\" customWidth=\"1\"/>" }
        sheet += "</cols><sheetData>"
        func textCell(_ ref: String, _ v: String, style: Int) -> String {
            "<c r=\"\(ref)\" t=\"inlineStr\"\(style > 0 ? " s=\"\(style)\"" : "")><is><t xml:space=\"preserve\">\(xmlEscape(v))</t></is></c>"
        }
        sheet += "<row r=\"1\">"
        for c in 0..<colCount { sheet += textCell("\(colName(c))1", c < t.headers.count ? t.headers[c] : "", style: 1) }
        sheet += "</row>"
        for (i, r) in t.rows.enumerated() {
            let n = i + 2
            sheet += "<row r=\"\(n)\">"
            for c in 0..<colCount where c < r.count && !r[c].isEmpty {
                let ref = "\(colName(c))\(n)"
                if let num = numberValue(r[c]) { sheet += "<c r=\"\(ref)\"><v>\(num)</v></c>" }
                else { sheet += textCell(ref, r[c], style: 0) }
            }
            sheet += "</row>"
        }
        sheet += "</sheetData>"
        sheet += "<autoFilter ref=\"A1:\(colName(colCount - 1))\(max(1, t.rows.count + 1))\"/>"
        sheet += "</worksheet>"

        let name = xmlEscape(sheetName(t.name))
        let files: [(String, String)] = [
            ("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>"),
            ("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"),
            ("xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"\(name)\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"),
            ("xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>"),
            ("xl/styles.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFD6E9FC\"/><bgColor indexed=\"64\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/></cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>"),
            ("xl/worksheets/sheet1.xml", sheet),
        ]
        return DesmZip.build(files.map { ($0.0, Data($0.1.utf8)) })
    }
}

/// Ghép file .zip tối thiểu (không nén, method 0) — đủ cho gói .xlsx.
enum DesmZip {
    private static let crcTable: [UInt32] = (0..<256).map { i -> UInt32 in
        var c = UInt32(i)
        for _ in 0..<8 { c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1) }
        return c
    }
    static func crc32(_ d: Data) -> UInt32 {
        var c: UInt32 = 0xFFFFFFFF
        for b in d { c = crcTable[Int((c ^ UInt32(b)) & 0xFF)] ^ (c >> 8) }
        return ~c
    }
    private static func le16(_ d: inout Data, _ v: UInt16) { d.append(UInt8(v & 0xFF)); d.append(UInt8(v >> 8)) }
    private static func le32(_ d: inout Data, _ v: UInt32) { for s in stride(from: 0, to: 32, by: 8) { d.append(UInt8((v >> UInt32(s)) & 0xFF)) } }

    static func build(_ files: [(String, Data)]) -> Data {
        var out = Data(), central = Data()
        let time: UInt16 = 0, date: UInt16 = (20 << 9) | (1 << 5) | 1   // 2000-01-01
        for (name, data) in files {
            let nameData = Data(name.utf8)
            let crc = crc32(data), size = UInt32(data.count), offset = UInt32(out.count)
            le32(&out, 0x04034b50); le16(&out, 20); le16(&out, 0x0800); le16(&out, 0); le16(&out, time); le16(&out, date)
            le32(&out, crc); le32(&out, size); le32(&out, size); le16(&out, UInt16(nameData.count)); le16(&out, 0)
            out.append(nameData); out.append(data)
            le32(&central, 0x02014b50); le16(&central, 20); le16(&central, 20); le16(&central, 0x0800); le16(&central, 0)
            le16(&central, time); le16(&central, date); le32(&central, crc); le32(&central, size); le32(&central, size)
            le16(&central, UInt16(nameData.count)); le16(&central, 0); le16(&central, 0); le16(&central, 0); le16(&central, 0)
            le32(&central, 0); le32(&central, offset)
            central.append(nameData)
        }
        let cdOffset = UInt32(out.count)
        out.append(central)
        le32(&out, 0x06054b50); le16(&out, 0); le16(&out, 0); le16(&out, UInt16(files.count)); le16(&out, UInt16(files.count))
        le32(&out, UInt32(central.count)); le32(&out, cdOffset); le16(&out, 0)
        return out
    }
}

// MARK: - Đăng ký nguồn dữ liệu của màn (qua PreferenceKey → nút xuất nằm trong DesmShotModifier)

struct DesmExportProvider: Equatable {
    let id: UUID
    let make: @MainActor () -> DesmTable
    static func == (a: DesmExportProvider, b: DesmExportProvider) -> Bool { a.id == b.id }
}

struct DesmExportKey: PreferenceKey {
    static let defaultValue: DesmExportProvider? = nil
    static func reduce(value: inout DesmExportProvider?, nextValue: () -> DesmExportProvider?) {
        if let n = nextValue() { value = n }
    }
}

private struct DesmExportRegister: ViewModifier {
    @State private var id = UUID()
    let make: @MainActor () -> DesmTable
    func body(content: Content) -> some View {
        content.preference(key: DesmExportKey.self, value: DesmExportProvider(id: id, make: make))
    }
}

extension View {
    /// Cho màn này nút xuất CSV/Excel; `make` được gọi lúc bấm nút.
    func desmExport(_ make: @escaping @MainActor () -> DesmTable) -> some View { modifier(DesmExportRegister(make: make)) }
}

/// Số hiển thị gọn: 25 → "25", 2.5 → "2.5".
func desmNum(_ v: Double) -> String { v == v.rounded() && abs(v) < 1e15 ? String(Int(v)) : String(format: "%g", v) }

// MARK: - Menu xuất đặt thẳng trên thanh công cụ (cho màn nằm trong NavigationStack, nhúng hoặc không phải sheet)

struct DesmExportSet {
    let label: String
    let make: @MainActor () -> DesmTable
}

/// Nút "chia sẻ" trên thanh trên: một bảng → Excel/CSV; nhiều bảng → mỗi bảng một menu con.
struct DesmExportMenu: View {
    let sets: [DesmExportSet]
    @State private var share: ShareItem? = nil

    @MainActor private func run(_ s: DesmExportSet, _ f: DesmExportFormat) {
        if let url = DesmExport.write(s.make(), as: f) { share = ShareItem(url: url) }
    }

    @ViewBuilder private func buttons(_ s: DesmExportSet) -> some View {
        Button { run(s, .xlsx) } label: { Label("Excel (.xlsx)", systemImage: "tablecells") }
        Button { run(s, .csv) } label: { Label("CSV", systemImage: "doc.plaintext") }
    }

    var body: some View {
        Menu {
            if sets.count == 1, let s = sets.first {
                buttons(s)
            } else {
                ForEach(Array(sets.enumerated()), id: \.offset) { e in
                    Menu(e.element.label) { buttons(e.element) }
                }
            }
        } label: {
            Image(systemName: "square.and.arrow.up")
        }
        .accessibilityLabel("Xuất dữ liệu ra CSV hoặc Excel")
        .sheet(item: $share) { item in ShareSheet(url: item.url) }
    }
}
