// DesmDialog.swift — hộp thoại tự vẽ thay alert/confirmationDialog hệ thống.

import SwiftUI
import PhotosUI
import WebKit
import MapKit
import CoreLocation
import UserNotifications

// MARK: - Hộp thoại tự vẽ (thay alert/confirmationDialog hệ thống)
//
// Thẻ bo tròn lớn nằm sát ĐÁY màn hình (tầm ngón cái tay phải), nút cao 52pt chiếm hết chiều ngang, màu theo app.
// `DesmDialogAction.kind`: primary = nút xanh đặc, normal = xanh nhạt, destructive = đỏ nhạt, cancel = xám.
// Chạm nền mờ: chạy nút cancel nếu có; chỉ có một nút thì chạy nút đó; còn lại thì không làm gì.

struct DesmDialogAction: Identifiable {
    enum Kind { case primary, normal, destructive, cancel }
    let id = UUID()
    let title: String
    var kind: Kind = .normal
    var handler: () -> Void = {}
}

struct DesmDialogState: Identifiable {
    let id: String
    var icon: String? = nil
    var title: String
    var message: String? = nil
    var actions: [DesmDialogAction]
    init(id: String = UUID().uuidString, icon: String? = nil, title: String, message: String? = nil, actions: [DesmDialogAction]) {
        self.id = id; self.icon = icon; self.title = title; self.message = message; self.actions = actions
    }
}

struct DesmDialogCard: View {
    let state: DesmDialogState
    let finish: () -> Void

    func fg(_ k: DesmDialogAction.Kind) -> Color {
        switch k { case .primary: return .white; case .normal: return Color.tabBlue; case .destructive: return .red; case .cancel: return .primary }
    }
    func bg(_ k: DesmDialogAction.Kind) -> Color {
        switch k {
        case .primary: return Color.tabBlue
        case .normal: return Color.tabBlue.opacity(0.12)
        case .destructive: return Color.red.opacity(0.12)
        case .cancel: return Color(.secondarySystemFill)
        }
    }
    func run(_ a: DesmDialogAction) { finish(); a.handler() }
    func backdropTap() {
        if let c = state.actions.first(where: { $0.kind == .cancel }) { run(c) }
        else if state.actions.count == 1, let a = state.actions.first { run(a) }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.opacity(0.38).ignoresSafeArea().onTapGesture { backdropTap() }
            VStack(spacing: 12) {
                if let icon = state.icon {
                    Image(systemName: icon).font(.system(size: 26, weight: .semibold)).foregroundStyle(Color.tabBlue)
                        .frame(width: 52, height: 52).background(Color.tabBlue.opacity(0.12), in: Circle())
                }
                Text(state.title).font(.system(size: 19, weight: .bold)).multilineTextAlignment(.center)
                if let m = state.message, !m.isEmpty {
                    Text(m).font(.system(size: 15)).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        .lineLimit(12).fixedSize(horizontal: false, vertical: true)
                }
                VStack(spacing: 8) {
                    ForEach(state.actions) { a in
                        Button { run(a) } label: {
                            Text(a.title).font(.system(size: 17, weight: .semibold))
                                .frame(maxWidth: .infinity, minHeight: 52)
                                .foregroundStyle(fg(a.kind))
                                .background(bg(a.kind), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.top, 4)
            }
            .padding(.horizontal, 18).padding(.top, 20).padding(.bottom, 16)
            .frame(maxWidth: .infinity)
            .background(Color(.systemBackground), in: RoundedRectangle(cornerRadius: 30, style: .continuous))
            .shadow(color: .black.opacity(0.18), radius: 22, y: 6)
            .padding(.horizontal, 12).padding(.bottom, 8)
        }
        .transition(.opacity.combined(with: .move(edge: .bottom)))
    }
}

extension View {
    /// Hiện hộp thoại đang có trong `state` (nil = ẩn); `finish` gọi khi đóng.
    func desmDialog(_ state: DesmDialogState?, finish: @escaping () -> Void) -> some View {
        overlay { if let s = state { DesmDialogCard(state: s, finish: finish) } }
            .animation(.easeOut(duration: 0.22), value: state?.id)
    }
    /// Thay `.alert(...)`: hiện khi `isPresented` = true, đóng thì đặt lại false rồi chạy hành động đã chọn.
    func desmAlert(isPresented: Binding<Bool>, icon: String? = nil, title: String, message: String? = nil, actions: [DesmDialogAction]) -> some View {
        desmDialog(isPresented.wrappedValue ? DesmDialogState(id: title, icon: icon, title: title, message: message, actions: actions) : nil,
                   finish: { isPresented.wrappedValue = false })
    }
}

/// Kiểu chung cho mọi màn hình native mở từ "Thêm": sheet toàn chiều cao, thanh kéo, màu nhấn xanh của app.
struct DesmSheetStyle: ViewModifier {
    var shot = true   // true: có nút chụp cả danh sách thành một ảnh (xem ShareSheet.swift)
    var bubble: Bool? = nil   // bong bóng AI nổi; nil = theo `shot` (màn có ô nhập ở đáy thì không hiện)
    func body(content: Content) -> some View {
        content
            .modifier(DesmShotModifier(enabled: shot))
            .overlay { if bubble ?? shot { DesmAIBubble(local: true) } }
            .modifier(DesmEdgeBackModifier())
            .tint(Color.tabBlue)
            .presentationDetents([.large])
            .presentationDragIndicator(.visible)
    }
}
extension View {
    func desmSheet(shot: Bool = true, bubble: Bool? = nil) -> some View { modifier(DesmSheetStyle(shot: shot, bubble: bubble)) }
    /// Chỉ gắn bong bóng AI nổi (cho màn không dùng `.desmSheet()`).
    func desmAIBubble(local: Bool = true) -> some View { overlay { DesmAIBubble(local: local) } }
}

/// Mục "Thêm": các nút điều hướng/công cụ cũ của thanh dưới + mở menu đầy đủ, Cài đặt.


// MARK: - Vuốt từ mép trái để quay lại (mọi màn gắn .desmSheet())
// Trang con trong NavigationStack: iOS tự xử lý vuốt mép để lùi một trang. Ở trang gốc của màn (không còn trang để lùi) thì vuốt mép = Đóng màn
// (quay về màn đã mở nó). Dùng UIScreenEdgePanGestureRecognizer đặt lên view trên cùng của màn; cho phép chạy song song với cử chỉ lùi của
// UINavigationController và chỉ đóng khi LÚC BẮT ĐẦU vuốt không còn trang nào để lùi (tránh vừa lùi trang vừa đóng cả màn).
struct DesmEdgeBackModifier: ViewModifier {
    @Environment(\.dismiss) private var dismiss
    func body(content: Content) -> some View {
        content.background(DesmEdgeBackInstaller(onBack: { dismiss() }).frame(width: 0, height: 0))
    }
}

struct DesmEdgeBackInstaller: UIViewControllerRepresentable {
    let onBack: () -> Void
    func makeUIViewController(context: Context) -> Holder { let h = Holder(); h.onBack = onBack; return h }
    func updateUIViewController(_ vc: Holder, context: Context) { vc.onBack = onBack }

    final class Holder: UIViewController, UIGestureRecognizerDelegate {
        var onBack: () -> Void = {}
        private var gesture: UIScreenEdgePanGestureRecognizer?
        private weak var host: UIViewController?
        private var canPop = false

        override func viewDidAppear(_ animated: Bool) { super.viewDidAppear(animated); install() }
        override func didMove(toParent parent: UIViewController?) { super.didMove(toParent: parent); if parent != nil { install() } }
        override func viewDidDisappear(_ animated: Bool) { super.viewDidDisappear(animated); if view.window == nil { uninstall() } }
        deinit { if let g = gesture { g.view?.removeGestureRecognizer(g) } }

        private func topHost() -> UIViewController {
            var v: UIViewController = self
            while let p = v.parent { v = p }
            return v
        }

        private func install() {
            guard gesture == nil else { return }
            let top = topHost()
            guard top !== self else { return }
            let g = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(handle(_:)))
            g.edges = .left
            g.delegate = self
            top.view.addGestureRecognizer(g)
            gesture = g
            host = top
        }

        private func uninstall() {
            if let g = gesture { g.view?.removeGestureRecognizer(g) }
            gesture = nil
            host = nil
        }

        private func navCanPop(_ vc: UIViewController?) -> Bool {
            guard let vc = vc else { return false }
            if let nav = vc as? UINavigationController, nav.viewControllers.count > 1 { return true }
            for c in vc.children where navCanPop(c) { return true }
            return false
        }

        @objc private func handle(_ r: UIScreenEdgePanGestureRecognizer) {
            switch r.state {
            case .began:
                canPop = navCanPop(host)
            case .ended:
                guard !canPop else { return }
                let t = r.translation(in: r.view).x
                let vx = r.velocity(in: r.view).x
                if t > 80 || vx > 700 { onBack() }
            default: break
            }
        }

        func gestureRecognizer(_ g: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
}


// MARK: - Bong bóng AI nổi (AI riêng + Dodo) trên mọi màn native

extension Notification.Name {
    /// Bong bóng chọn Dodo (web) từ một màn native: BrowserView đóng hết sheet rồi mở Dodo trên trang web.
    static let desmOpenDodo = Notification.Name("desmOpenDodo")
}

/// Nút tròn kéo được, nhớ vị trí. Chạm = mở trợ lý đang chọn trong Cài đặt (AI riêng / Dodo); giữ lâu = chọn trợ lý khác.
/// `local`: true = nằm trong một sheet (tự mở khung chat AI ngay trong sheet đó); false = màn chính (dùng model.showAIChat).
struct DesmAIBubble: View {
    var local = true
    @AppStorage("desmDodoBubble") private var enabled = true
    @AppStorage("desmAIEngine") private var engine = "ai"
    @AppStorage("desmAIBubbleSide") private var side = "r"
    @AppStorage("desmAIBubbleY") private var yFrac = 0.62
    @State private var drag: CGSize? = nil
    @State private var choose = false
    @State private var showChat = false

    private let size: CGFloat = 52

    private func open(_ which: String) {
        if which == "dodo" { NotificationCenter.default.post(name: .desmOpenDodo, object: nil) }
        else if local { showChat = true }
        else { BrowserModel.current?.showAIChat = true }
    }

    var body: some View {
        GeometryReader { g in
            if enabled {
                let x0 = side == "l" ? size / 2 + 6 : g.size.width - size / 2 - 6
                let y0 = min(max(CGFloat(yFrac) * g.size.height, 110), max(110, g.size.height - 150))
                ZStack {
                    Circle().fill(Color.tabBlue)
                    Image(systemName: engine == "dodo" ? "bubble.left.and.bubble.right.fill" : "sparkles")
                        .font(.system(size: 22, weight: .semibold)).foregroundStyle(.white)
                }
                .frame(width: size, height: size)
                .overlay(Circle().stroke(Color.white, lineWidth: 2))
                .shadow(color: .black.opacity(0.3), radius: 6, y: 2)
                .opacity(drag == nil ? 0.92 : 1)
                .position(x: x0 + (drag?.width ?? 0), y: y0 + (drag?.height ?? 0))
                .gesture(DragGesture(minimumDistance: 8)
                    .onChanged { drag = $0.translation }
                    .onEnded { v in
                        let fx = x0 + v.translation.width, fy = y0 + v.translation.height
                        side = fx < g.size.width / 2 ? "l" : "r"
                        yFrac = Double(min(max(fy / max(g.size.height, 1), 0.1), 0.9))
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { drag = nil }
                    })
                .onTapGesture { open(engine) }
                .onLongPressGesture(minimumDuration: 0.5) { choose = true }
                .accessibilityLabel("Trợ lý AI")
                .accessibilityAddTraits(.isButton)
            }
        }
        .sheet(isPresented: $showChat) {
            if let m = BrowserModel.current {
                AIChatView(model: m, onClose: { showChat = false })
                    .desmSheet(shot: false)
            }
        }
        .desmAlert(isPresented: $choose, icon: "sparkles", title: "Chọn trợ lý", message: "Chạm bong bóng sẽ mở trợ lý đang chọn trong Cài đặt.", actions: [
            DesmDialogAction(title: "AI riêng (đọc dữ liệu DESM)", kind: .primary) { open("ai") },
            DesmDialogAction(title: "Dodo (trợ lý của web DESM)", kind: .normal) { open("dodo") },
            DesmDialogAction(title: "Hủy", kind: .cancel),
        ])
    }
}
