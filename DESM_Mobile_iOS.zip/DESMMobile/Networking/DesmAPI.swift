// DesmAPI.swift — gọi API .do của DESM bằng URLSession + cookie phiên (không phụ thuộc trang đang mở).
//
// Trước đây desmQuery chạy fetch bên trong WKWebView nên lỗi khi trang đang ở login hoặc hết phiên, và không chạy được khi app ở nền.
// Giờ: lấy cookie từ kho cookie của WebView (nếu còn) hoặc từ bản lưu Keychain (SessionStore.storedCookies), rồi POST bằng URLSession.
// Nếu URLSession lỗi (không phải hết phiên) và vẫn còn WebView thì lùi về cách cũ (desmQueryViaWebView).
// CHƯA kiểm chứng trên máy thật: máy chủ có đòi thêm header (Referer/Origin đã gửi) hay khác biệt User-Agent không.

import Foundation
import WebKit

enum DesmAPIError: LocalizedError {
    case noSession
    case expired
    case notJSON(Int)
    case server
    case unreadable
    case noProject
    case pmsExpired
    case network(String)
    case message(String)

    var errorDescription: String? {
        switch self {
        case .noSession: return "Chưa có phiên đăng nhập DESM. Hãy mở DESM và đăng nhập trước."
        case .expired: return "Phiên DESM đã hết hạn. Hãy đăng nhập lại."
        case .notJSON(let code): return "HTTP \(code): phản hồi không phải JSON (có thể đã hết phiên)"
        case .server: return "Máy chủ trả về lỗi."
        case .unreadable: return "Không đọc được phản hồi."
        case .noProject: return "Chưa có dự án mặc định trong DESM."
        case .pmsExpired: return "Chưa đăng nhập PDH (cổng 8443) hoặc phiên PDH đã hết hạn (máy chủ trả HTTP 503). Bấm “Đăng nhập PDH”, đăng nhập xong mở lại màn này."
        case .network(let m): return "Không tải được: \(m)"
        case .message(let m): return m
        }
    }
}

/// Kết quả đã phân tích JSON (làm ở luồng nền: phản hồi vài MB mà parse trên luồng chính sẽ làm giao diện đứng).
struct DesmRowsBox: @unchecked Sendable {
    let isJSON: Bool
    let rows: [[String: Any]]?

    static func parse(_ data: Data) -> DesmRowsBox {
        guard let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return DesmRowsBox(isJSON: false, rows: nil) }
        let x = obj["results"]
        if let list = x as? [[String: Any]] { return DesmRowsBox(isJSON: true, rows: list) }
        if let d = x as? [String: Any], let list = d["list"] as? [[String: Any]] { return DesmRowsBox(isJSON: true, rows: list) }
        return DesmRowsBox(isJSON: true, rows: nil)
    }
}

extension BrowserModel {
    static let apiOrigin = "https://desm.doosanenerbility.com"
    /// Máy chủ PDH/PMS (trang /newui/progress.do, API /pms/...) chạy ở cổng 8443; cổng 443 trả 404 cho /pms/... (log 2026-11-03).
    static let pmsOrigin = "https://desm.doosanenerbility.com:8443"

    /// Phiên dùng chung (trước đây mỗi lần gọi tạo một URLSession mới mà không huỷ → rò rỉ). Có giới hạn TỔNG thời gian.
    private static let httpSession: URLSession = {
        let cfg = URLSessionConfiguration.ephemeral
        cfg.httpShouldSetCookies = false
        cfg.timeoutIntervalForRequest = 20
        cfg.timeoutIntervalForResource = 30
        return URLSession(configuration: cfg)
    }()

    /// Cookie DESM: ưu tiên kho cookie của WebView (mới nhất); không có thì dùng bản lưu trong Keychain (chạy được khi không có WebView).
    @MainActor
    func desmCookies() async -> [HTTPCookie] {
        if let store = webView?.configuration.websiteDataStore.httpCookieStore {
            let all: [HTTPCookie] = await withCheckedContinuation { cont in
                store.getAllCookies { cont.resume(returning: $0) }
            }
            let mine = all.filter { $0.domain.lowercased().contains("doosanenerbility") }
            if !mine.isEmpty { return mine }
        }
        return SessionStore.storedCookies()
    }

    /// POST một endpoint .do bằng phiên đăng nhập hiện có; trả mảng dòng (results hoặc results.list).
    @MainActor
    func desmQueryAsync(_ path: String, body: String, origin: String = BrowserModel.apiOrigin) async throws -> [[String: Any]] {
        let stats = DesmStats.shared
        func kind(_ e: Error) -> DesmStats.Kind {
            switch e as? DesmAPIError {
            case .expired?, .pmsExpired?: return .apiExpired
            case .noSession?: return .apiNoSession
            case .network?: return .apiNetwork
            case .notJSON?: return .apiNotJSON
            case .server?, .unreadable?: return .apiServer
            default: return .apiOther
            }
        }
        do {
            let r = try await desmQueryHTTP(path, body: body, origin: origin)
            stats.record(.apiOK, path: path)
            return r
        } catch DesmAPIError.expired where origin == Self.apiOrigin {
            stats.record(.apiExpired, path: path)
            throw DesmAPIError.expired
        } catch DesmAPIError.noSession {
            stats.record(.apiNoSession, path: path)
            throw DesmAPIError.noSession
        } catch {
            // Cổng khác (8443 PMS): tải trang PMS trong WebView ẩn rồi fetch cùng nguồn (như trình duyệt)
            if origin != Self.apiOrigin, webView != nil {
                AILog.add("↩︎ " + path + " (cổng PMS) lỗi (" + error.localizedDescription + ") → thử qua trang PMS")
                stats.record(.webFallback, path: path)
                do {
                    let data = try await pmsPageFetch(path, body: body)
                    let box = await Task.detached(priority: .userInitiated) { () -> DesmRowsBox in return DesmRowsBox.parse(data) }.value
                    guard box.isJSON else { throw DesmAPIError.message("Trang PMS trả dữ liệu không phải JSON.") }
                    guard let rows = box.rows else { throw DesmAPIError.server }
                    stats.record(.apiOK, path: path)
                    return rows
                } catch {
                    stats.record(kind(error), path: path)
                    throw error
                }
            }
            // Đường lui qua trang web chỉ đúng khi cùng cổng 443 (khác cổng thì fetch trong trang bị chặn CORS / 404)
            guard webView != nil, origin == Self.apiOrigin else { stats.record(kind(error), path: path); throw error }
            AILog.add("↩︎ " + path + " URLSession lỗi (" + error.localizedDescription + ") → thử qua trang web")
            stats.record(.webFallback, path: path)
            do {
                let r = try await desmQueryViaWebView(path, body: body)   // đường lui
                stats.record(.apiOK, path: path)
                return r
            } catch {
                stats.record(kind(error), path: path)
                throw error
            }
        }
    }

    @MainActor
    private func desmQueryHTTP(_ path: String, body: String, origin: String) async throws -> [[String: Any]] {
        guard let base = URL(string: origin), let url = URL(string: path, relativeTo: base)?.absoluteURL,
              url.host?.lowercased().hasSuffix("doosanenerbility.com") == true else { throw DesmAPIError.message("Địa chỉ không hợp lệ.") }
        let cookies = await desmCookies()
        guard !cookies.isEmpty else { throw DesmAPIError.noSession }

        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        req.httpMethod = "POST"
        req.httpBody = body.data(using: .utf8)
        req.allHTTPHeaderFields = HTTPCookie.requestHeaderFields(with: cookies)
        req.setValue("application/x-www-form-urlencoded; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        req.setValue("XMLHttpRequest", forHTTPHeaderField: "X-Requested-With")
        req.setValue("true", forHTTPHeaderField: "AJAX")
        req.setValue(origin, forHTTPHeaderField: "Origin")
        req.setValue(origin == Self.apiOrigin ? Self.homeURL : origin + "/newui/progress.do", forHTTPHeaderField: "Referer")
        let t0 = Date()
        let result: (Data, URLResponse)
        do { result = try await Self.httpSession.data(for: req) }
        catch {
            AILog.add("✗ HTTP " + path + " lỗi sau " + String(format: "%.1f", Date().timeIntervalSince(t0)) + "s: " + error.localizedDescription)
            throw DesmAPIError.network(error.localizedDescription)
        }
        let data = result.0
        guard let http = result.1 as? HTTPURLResponse else { throw DesmAPIError.unreadable }
        // Cổng PDH (8443): máy chủ trả 503 khi phiên PDH không hợp lệ (pdh.js của họ cũng hiểu 503 = hết phiên) → báo riêng để app mở đăng nhập PDH.
        let onPms = origin != Self.apiOrigin
        if onPms, http.statusCode == 503 || http.statusCode == 401 { throw DesmAPIError.pmsExpired }
        if http.statusCode == 401 { throw DesmAPIError.expired }
        if http.url?.path.lowercased().contains("login") == true { throw onPms ? DesmAPIError.pmsExpired : DesmAPIError.expired }   // bị chuyển về trang đăng nhập
        let t1 = Date()
        // Phân tích JSON ở luồng nền rồi mới quay lại luồng chính
        let box = await Task.detached(priority: .userInitiated) { () -> DesmRowsBox in return DesmRowsBox.parse(data) }.value
        AILog.add("← " + path + " HTTP " + String(http.statusCode) + ", " + String(data.count / 1024) + " KB, mạng " + String(format: "%.1f", t1.timeIntervalSince(t0)) + "s, phân tích " + String(format: "%.2f", Date().timeIntervalSince(t1)) + "s")
        if !box.isJSON { throw DesmAPIError.notJSON(http.statusCode) }
        guard let rows = box.rows else { throw DesmAPIError.server }
        return rows
    }

    /// Đường lui: chạy fetch ngay trong trang DESM đang mở (cách cũ). Chỉ dùng khi URLSession gặp lỗi không phải hết phiên.
    @MainActor
    func desmQueryViaWebView(_ path: String, body: String) async throws -> [[String: Any]] {
        guard let webView = webView else { throw DesmAPIError.noSession }
        let js = #"""
        if (!/(^|\.)doosanenerbility\.com$/i.test(location.hostname)) return JSON.stringify({ err: 'Hãy mở DESM và đăng nhập trước.' });
        const ac = new AbortController();
        const tm = setTimeout(function() { try { ac.abort(); } catch (e) {} }, 20000);
        try {
          const r = await fetch(path, { method: 'POST', credentials: 'include', cache: 'no-store', signal: ac.signal,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' }, body: body });
          const t = await r.text(); clearTimeout(tm); let s;
          try { s = JSON.parse(t); } catch (e) { return JSON.stringify({ err: 'HTTP ' + r.status + ': phản hồi không phải JSON (có thể đã hết phiên)' }); }
          const x = s && s.results;
          const list = Array.isArray(x) ? x : (x && Array.isArray(x.list) ? x.list : null);
          if (!list) return JSON.stringify({ err: 'Máy chủ trả về lỗi.' });
          return JSON.stringify({ list: list });
        } catch (e) {
          clearTimeout(tm);
          if (e && e.name === 'AbortError') return JSON.stringify({ err: 'Quá thời gian chờ (20 giây) khi tải dữ liệu từ trang.' });
          return JSON.stringify({ err: String(e && e.message || e) });
        }
        """#
        let t0 = Date()
        let result: Any?
        do {
            // callAsyncJavaScript không tự hết hạn (trang bận/đang chuyển trang thì chờ mãi) → đua với đồng hồ 25 giây
            result = try await aiRaceThrowing(25, timeoutError: DesmAPIError.network("trang web không phản hồi sau 25 giây")) {
                return try await webView.callAsyncJavaScript(js, arguments: ["path": path, "body": body], in: nil, in: .page)
            }
        } catch {
            AILog.add("✗ WebView " + path + " lỗi sau " + String(format: "%.1f", Date().timeIntervalSince(t0)) + "s: " + error.localizedDescription)
            if error is DesmAPIError { throw error }
            throw DesmAPIError.network(error.localizedDescription)
        }
        AILog.add("← WebView " + path + " xong sau " + String(format: "%.1f", Date().timeIntervalSince(t0)) + "s")
        guard let text = result as? String, let data = text.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw DesmAPIError.unreadable }
        if let err = obj["err"] as? String { throw DesmAPIError.message(err) }
        return obj["list"] as? [[String: Any]] ?? []
    }

    /// Số dự án mặc định (SEGMENT1 của getInitDefailProject.do) — hầu hết màn hình cần nó trước.
    /// Có nhớ đệm 30 phút: trước đây MỖI lần tìm đều gọi thêm một request này trước request chính (hai lượt mạng nối tiếp).
    @MainActor
    func desmProjectNo() async throws -> String {
        if let c = DesmProjectCache.value, Date().timeIntervalSince(c.at) < 1800 { return c.no }
        do {
            let rows = try await desmQueryAsync("/getInitDefailProject.do", body: "")
            guard let no = rows.first?["SEGMENT1"] as? String, !no.isEmpty else { throw DesmAPIError.noProject }
            DesmProjectCache.value = (no, Date())
            return no
        } catch {
            DesmProjectCache.value = nil   // lỗi/hết phiên: lần sau hỏi lại
            throw error
        }
    }

    /// Bản callback cũ (giữ để các màn hình chưa chuyển sang async vẫn chạy). `done` luôn được gọi trên main.
    func desmQuery(_ path: String, body: String, done: @escaping ([[String: Any]]?, String) -> Void) {
        Task { @MainActor in
            do { done(try await self.desmQueryAsync(path, body: body), "") }
            catch { done(nil, error.localizedDescription) }
        }
    }
}

/// Nhớ số dự án mặc định để các màn hình không phải hỏi máy chủ lại ở mỗi lần tìm.
enum DesmProjectCache { @MainActor static var value: (no: String, at: Date)? = nil }


// MARK: - Cổng PMS (8443): gọi API từ chính trang /newui/progress.do trong WebView ẩn
// Dùng khi URLSession tới :8443 bị 503/401 (phiên 443 không dùng được cho 8443). Trang tải bằng cùng kho cookie của WebView chính,
// nên nếu web mở được trang Tiến độ thì đường này cũng chạy được. CHƯA thử máy thật.

@MainActor
final class PmsPageLoader: NSObject, WKNavigationDelegate {
    private var cont: CheckedContinuation<Void, Error>?
    private var gen = 0

    func load(_ v: WKWebView, _ url: URL, timeout: Double) async throws {
        gen += 1
        let mine = gen
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in
            cont = c
            v.load(URLRequest(url: url))
            Task { @MainActor [weak self] in
                try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                if let self = self, self.gen == mine {
                    self.finish(DesmAPIError.network("trang PMS (cổng 8443) không tải xong sau \(Int(timeout)) giây — mạng/VPN có thể chặn cổng 8443"))
                }
            }
        }
    }

    private func finish(_ e: Error?) {
        guard let c = cont else { return }
        cont = nil
        if let e = e { c.resume(throwing: e) } else { c.resume() }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { finish(nil) }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { finish(DesmAPIError.network(error.localizedDescription)) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { finish(DesmAPIError.network(error.localizedDescription)) }
}

extension BrowserModel {
    @MainActor private static var pmsView: WKWebView?
    @MainActor private static let pmsLoader = PmsPageLoader()
    @MainActor private static var pmsLoadedAt = Date.distantPast

    /// Mở trang đăng nhập PDH (cổng 8443) ngay trong trình duyệt của app. Máy chủ tự chuyển về login.do nếu chưa có phiên; tài khoản đã lưu sẽ được điền sẵn.
    @MainActor
    func openPmsLogin() {
        guard let url = URL(string: Self.pmsOrigin + "/home.do") else { return }
        Self.pmsView = nil   // lần gọi sau tải lại trang gốc 8443 với cookie mới
        navigate(url)
    }

    /// POST một endpoint của cổng 8443 từ trong một trang cùng gốc (https://…:8443) — y như trình duyệt, nên cookie/UA/header đúng.
    /// Trang gốc là file CSS tĩnh nhỏ, KHÔNG phải /newui/progress.do: trang đó chạy pdh.js, gặp 503 sẽ tự chuyển sang /logout.do (làm mất phiên)
    /// và còn chạy các script của app + tải cả loạt API thừa. WebView ẩn dùng cấu hình riêng (không script chèn), chỉ chia sẻ kho cookie.
    @MainActor
    func pmsPageFetch(_ path: String, body: String) async throws -> Data {
        guard let main = webView else { throw DesmAPIError.noSession }
        guard let pageURL = URL(string: Self.pmsOrigin + "/resources/newui/pdh.css") else { throw DesmAPIError.message("Địa chỉ PMS không hợp lệ.") }
        var view = Self.pmsView
        if view == nil || Date().timeIntervalSince(Self.pmsLoadedAt) > 600 {
            let cfg = WKWebViewConfiguration()
            cfg.websiteDataStore = main.configuration.websiteDataStore
            let v = WKWebView(frame: CGRect(x: 0, y: 0, width: 390, height: 700), configuration: cfg)
            v.navigationDelegate = Self.pmsLoader
            Self.pmsView = v
            view = v
            AILog.add("⤓ tải trang gốc PMS " + pageURL.absoluteString)
            do { try await Self.pmsLoader.load(v, pageURL, timeout: 25) }
            catch { Self.pmsView = nil; AILog.add("✗ trang PMS: " + error.localizedDescription); throw error }
            Self.pmsLoadedAt = Date()
        }
        guard let v = view else { throw DesmAPIError.noSession }
        let js = #"""
        const ac = new AbortController();
        const tm = setTimeout(function() { try { ac.abort(); } catch (e) {} }, 20000);
        try {
          const r = await fetch(path, { method: 'POST', credentials: 'include', cache: 'no-store', signal: ac.signal,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest', 'AJAX': 'true' }, body: body });
          const t = await r.text(); clearTimeout(tm);
          return JSON.stringify({ status: r.status, url: r.url || '', text: t });
        } catch (e) {
          clearTimeout(tm);
          return JSON.stringify({ err: String(e && e.message || e) });
        }
        """#
        let t0 = Date()
        let result: Any?
        do {
            result = try await aiRaceThrowing(25, timeoutError: DesmAPIError.network("trang PMS không phản hồi sau 25 giây")) {
                return try await v.callAsyncJavaScript(js, arguments: ["path": path, "body": body], in: nil, in: .page)
            }
        } catch {
            Self.pmsView = nil
            AILog.add("✗ PMS " + path + " lỗi: " + error.localizedDescription)
            if error is DesmAPIError { throw error }
            throw DesmAPIError.network(error.localizedDescription)
        }
        guard let text = result as? String, let d = text.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { throw DesmAPIError.unreadable }
        if let err = obj["err"] as? String { Self.pmsView = nil; throw DesmAPIError.message(err) }
        let status = (obj["status"] as? Int) ?? 0
        let finalURL = ((obj["url"] as? String) ?? "").lowercased()
        AILog.add("← PMS " + path + " HTTP " + String(status) + " " + String(format: "%.1f", Date().timeIntervalSince(t0)) + "s")
        // 503/401 hoặc bị chuyển về login = chưa có phiên PDH
        if status == 401 || status == 503 || finalURL.contains("login") { throw DesmAPIError.pmsExpired }
        if status >= 400 { throw DesmAPIError.message("HTTP \(status) từ cổng PMS (8443) ngay cả khi gọi từ trang PMS.") }
        return (obj["text"] as? String ?? "").data(using: .utf8) ?? Data()
    }
}
