// PackageListView.swift — màn "Package" native (Thêm > Package): tìm kiện, bộ lọc đầy đủ như web, chip Packing List /
// Còn hàng / Đã xuất hết, sắp xếp, Xuất CSV, chọn nhiều kiện và các thao tác Material Confirm/Cancel, Location Update/Delete, Customs.
// Bấm một kiện → PackageDetailView (PackageDetailView.swift). Dữ liệu/API: PackageData.swift.
// Giao diện bám ảnh trang web Package: ô lọc bo tròn, nút Search xanh, nút làm mới xám, hàng nút thao tác màu xanh ngọc,
// thẻ kiện trắng có viền trái xanh lá (CLOSE) / cam / xanh, viên thuốc Remaining.
// CHƯA build Xcode / chưa thử máy thật.

import SwiftUI

// MARK: - Thành phần giao diện dùng chung

/// Bố cục xếp chip tự xuống dòng (iOS 16 Layout).
struct PkgFlow: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxW = proposal.width ?? .infinity
        var x: CGFloat = 0, y: CGFloat = 0, rowH: CGFloat = 0, w: CGFloat = 0
        for s in subviews {
            let sz = s.sizeThatFits(.unspecified)
            if x > 0 && x + sz.width > maxW { y += rowH + spacing; x = 0; rowH = 0 }
            x += sz.width + spacing
            rowH = max(rowH, sz.height)
            w = max(w, x - spacing)
        }
        return CGSize(width: w, height: y + rowH)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX, y = bounds.minY, rowH: CGFloat = 0
        for s in subviews {
            let sz = s.sizeThatFits(.unspecified)
            if x > bounds.minX && x + sz.width > bounds.maxX { y += rowH + spacing; x = bounds.minX; rowH = 0 }
            s.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(sz))
            x += sz.width + spacing
            rowH = max(rowH, sz.height)
        }
    }
}

struct PkgChip: View {
    let title: String
    var on: Bool
    var tint: Color = Color.tabBlue
    var icon: String? = nil
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if let i = icon { Image(systemName: i).font(.system(size: 13, weight: .semibold)) }
                Text(title).font(.system(size: 14, weight: .semibold))
            }
            .padding(.horizontal, 14).padding(.vertical, 9)
            .foregroundStyle(on ? Color.white : tint)
            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(on ? tint : Color(.secondarySystemGroupedBackground)))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(tint.opacity(on ? 0 : 0.35), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

struct PkgField: View {
    let placeholder: String
    @Binding var text: String
    var submit: () -> Void = {}

    var body: some View {
        TextField(placeholder, text: $text)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .submitLabel(.search)
            .onSubmit(submit)
            .font(.system(size: 16))
            .padding(.horizontal, 14).frame(height: 46)
            .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.tabBlue.opacity(0.25), lineWidth: 1))
    }
}

struct PkgLabeled<Content: View>: View {
    let title: String
    let content: Content
    init(_ title: String, @ViewBuilder content: () -> Content) { self.title = title; self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary)
            content
        }
    }
}

struct PkgYN: View {
    let title: String
    @Binding var value: String
    var body: some View {
        PkgLabeled(title) {
            Picker(title, selection: $value) {
                Text("Tất cả").tag("")
                Text("Y").tag("Y")
                Text("N").tag("N")
            }
            .pickerStyle(.segmented)
        }
    }
}

struct PkgMenuField: View {
    let placeholder: String
    @Binding var text: String
    let options: [String]
    var body: some View {
        HStack(spacing: 8) {
            PkgField(placeholder: placeholder, text: $text)
            Menu {
                Button("(Tất cả)") { text = "" }
                ForEach(options, id: \.self) { o in Button(o) { text = o } }
            } label: {
                Image(systemName: "chevron.down.circle.fill").font(.system(size: 26)).foregroundStyle(Color.tabBlue)
            }
            .disabled(options.isEmpty)
        }
    }
}

struct PkgDateField: View {
    let title: String
    @Binding var date: Date?
    var body: some View {
        PkgLabeled(title) {
            HStack(spacing: 6) {
                if let d = date {
                    DatePicker("", selection: Binding(get: { d }, set: { date = $0 }), displayedComponents: .date).labelsHidden()
                    Button { date = nil } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }.buttonStyle(.plain)
                } else {
                    Button { date = Date() } label: {
                        Text("Chọn ngày").font(.system(size: 15)).foregroundStyle(Color.tabBlue)
                            .frame(maxWidth: .infinity, minHeight: 40, alignment: .leading).padding(.horizontal, 12)
                            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

struct PkgPill: View {
    let icon: String
    let title: String
    var tint: Color = Color(red: 0.31, green: 0.62, blue: 0.74)
    var enabled = true
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: icon).font(.system(size: 16, weight: .semibold))
                Text(title).font(.system(size: 16, weight: .bold))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 18).frame(height: 46)
            .background(Capsule().fill(LinearGradient(colors: [tint, tint.opacity(0.78)], startPoint: .leading, endPoint: .trailing)))
            .opacity(enabled ? 1 : 0.45)
        }
        .buttonStyle(.plain)
    }
}

struct PkgTag: View {
    let text: String
    var tint: Color
    var body: some View {
        Text(text).font(.system(size: 12, weight: .bold)).foregroundStyle(tint)
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(Capsule().fill(tint.opacity(0.14)))
    }
}

/// Nền xanh nhạt giống trang web.
struct PkgBackground: View {
    var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
            LinearGradient(colors: [Color.tabBlue.opacity(0.10), Color.tabBlueLight.opacity(0.04), Color.clear], startPoint: .top, endPoint: .bottom)
        }
        .ignoresSafeArea()
    }
}

typealias PkgAsk = (_ icon: String, _ title: String, _ message: String, _ button: String, _ destructive: Bool, _ run: @escaping () -> Void) -> Void

/// Các thao tác ghi trên một nhóm kiện: hỏi xác nhận (ask) rồi gọi PackageVM. Dùng chung cho danh sách và chi tiết.
struct PkgActionOps {
    let vm: PackageVM
    let model: BrowserModel
    let ask: PkgAsk
    let openLoc: ([PkgRow]) -> Void

    func need(_ rows: [PkgRow]) -> Bool {
        if rows.isEmpty { vm.error = "Hãy chọn ít nhất một kiện trước."; return false }
        return true
    }
    func locationUpdate(_ rows: [PkgRow]) { if need(rows) { openLoc(rows) } }
    func locationDelete(_ rows: [PkgRow]) {
        if !need(rows) { return }
        ask("mappin.slash", "Xoá vị trí (Location Delete)", "Xoá vị trí của \(rows.count) kiện đã chọn trên DESM? Thao tác này không tự hoàn tác được.", "Xoá vị trí", true) {
            vm.deleteLocation(model, rows: rows)
        }
    }
    func materialConfirm(_ rows: [PkgRow]) {
        if !need(rows) { return }
        ask("checkmark.seal.fill", "Xác nhận vật tư (Material Confirm)", "Xác nhận \(rows.count) kiện đã chọn trên DESM?", "Xác nhận", false) {
            vm.confirmMaterial(model, rows: rows)
        }
    }
    func materialCancel(_ rows: [PkgRow]) {
        if !need(rows) { return }
        ask("xmark.seal.fill", "Hủy xác nhận (Material Cancel)", "Hủy xác nhận \(rows.count) kiện đã chọn? Kiện đã có RSI sẽ bị từ chối.", "Hủy xác nhận", true) {
            vm.cancelMaterial(model, rows: rows)
        }
    }
    func customs(_ rows: [PkgRow]) {
        if !need(rows) { return }
        guard let target = vm.customsTarget(rows: rows) else {
            vm.error = "Các kiện đã chọn có giá trị Customs khác nhau — chỉ đổi được khi cùng giá trị."
            return
        }
        ask("shippingbox.fill", "Đổi Customs", "Đổi Customs của \(rows.count) kiện sang \(target)?", "Đổi sang \(target)", false) {
            vm.setCustoms(model, rows: rows, to: target)
        }
    }
}

/// Nội dung menu "Thao tác" (dùng trong Menu { } ở danh sách và chi tiết).
struct PkgActionMenuItems: View {
    let ops: PkgActionOps
    let rows: [PkgRow]
    var body: some View {
        Group {
            Button { ops.locationUpdate(rows) } label: { Label("Location Update", systemImage: "mappin.and.ellipse") }
            Button { ops.locationDelete(rows) } label: { Label("Location Delete", systemImage: "mappin.slash") }
            Button { ops.materialConfirm(rows) } label: { Label("Material Confirm", systemImage: "checkmark.seal") }
            Button { ops.materialCancel(rows) } label: { Label("Material Cancel", systemImage: "xmark.seal") }
            Button { ops.customs(rows) } label: { Label("Customs Y/N", systemImage: "shippingbox") }
        }
    }
}

// MARK: - Bảng lọc đầy đủ (nút "Bộ lọc")

struct PkgFilterPanel: View {
    @ObservedObject var vm: PackageVM
    var onSearch: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            PkgLabeled("Description") { PkgField(placeholder: "Mô tả / tên vật tư", text: $vm.filter.desc, submit: onSearch) }
            PkgLabeled("Voyage") { PkgMenuField(placeholder: "Voyage (ATTRIBUTE10)", text: $vm.filter.voyage, options: vm.voyages) }
            PkgLabeled("Location") { PkgMenuField(placeholder: "Vị trí kho", text: $vm.filter.location, options: vm.locations) }
            HStack(spacing: 10) {
                PkgLabeled("Remark") { PkgField(placeholder: "Remark", text: $vm.filter.remark, submit: onSearch) }
                PkgLabeled("Vendor") { PkgField(placeholder: "Vendor", text: $vm.filter.vendor, submit: onSearch) }
            }
            PkgYN(title: "Confirm Material", value: $vm.filter.confirm)
            PkgYN(title: "Receipted", value: $vm.filter.receipted)
            PkgYN(title: "MRR Received", value: $vm.filter.mrrReceived)
            PkgYN(title: "Customs", value: $vm.filter.customs)
            PkgLabeled("V/C (MRR Visual Check)") { PkgField(placeholder: "Để trống = All (vd Good)", text: $vm.filter.visual, submit: onSearch) }
            HStack(spacing: 10) {
                PkgDateField(title: "Receipt từ", date: $vm.filter.recFrom)
                PkgDateField(title: "Receipt đến", date: $vm.filter.recTo)
            }
            HStack(spacing: 10) {
                PkgDateField(title: "MRR từ", date: $vm.filter.mrrFrom)
                PkgDateField(title: "MRR đến", date: $vm.filter.mrrTo)
            }
            HStack {
                Button { vm.filter = PkgFilter() } label: {
                    Text("Xoá bộ lọc").font(.system(size: 15, weight: .semibold)).foregroundStyle(.red)
                        .frame(maxWidth: .infinity, minHeight: 44)
                        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.red.opacity(0.10)))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 4)
    }
}

// MARK: - Thẻ kiện

struct PkgCard: View {
    let row: PkgRow
    let selected: Bool
    var onToggle: () -> Void
    var onOpen: () -> Void
    var onLocation: () -> Void

    var accent: Color {
        if row.isClose { return Color(red: 0.25, green: 0.70, blue: 0.40) }
        if row.hasQty && row.shipped > 0 && row.remaining > 0 { return Color.orange }
        return Color.tabBlue
    }

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Button(action: onToggle) {
                Image(systemName: selected ? "checkmark.square.fill" : "square")
                    .font(.system(size: 28, weight: .regular))
                    .foregroundStyle(selected ? Color.tabBlue : Color(.tertiaryLabel))
                    .frame(width: 34, height: 34)
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 6) {
                Button(action: onOpen) {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text(row.no).font(.system(size: 20, weight: .heavy)).foregroundStyle(.primary)
                                .lineLimit(2).minimumScaleFactor(0.8)
                            Spacer(minLength: 4)
                            if row.customs == "Y" { PkgTag(text: "Customs", tint: .purple) }
                            if row.confirmed { Image(systemName: "checkmark.seal.fill").font(.system(size: 15)).foregroundStyle(.green) }
                        }
                        if !row.desc.isEmpty {
                            Text(row.desc).font(.system(size: 17)).foregroundStyle(.primary).lineLimit(3)
                        }
                        let sub = [row.s("PACKAGE_TYPE"), row.plNo].filter { !$0.isEmpty }.joined(separator: " · ")
                        if !sub.isEmpty {
                            Text(sub).font(.system(size: 15)).foregroundStyle(.secondary).lineLimit(1)
                        }
                        statusRow
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                Divider()
                Button(action: onLocation) {
                    HStack(spacing: 6) {
                        Image(systemName: "mappin.and.ellipse").font(.system(size: 16, weight: .semibold))
                        Text(row.loc.isEmpty ? "Chưa có vị trí" : row.loc)
                            .font(.system(size: 17, weight: .bold)).underline()
                            .lineLimit(1).minimumScaleFactor(0.8)
                        Spacer(minLength: 0)
                    }
                    .foregroundStyle(row.loc.isEmpty ? Color.red : Color.primary)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 12).padding(.leading, 12).padding(.trailing, 14)
        .background(Color(.secondarySystemGroupedBackground))
        .overlay(alignment: .leading) { Rectangle().fill(accent).frame(width: 6) }
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(selected ? Color.tabBlue : Color.clear, lineWidth: 2))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .shadow(color: Color.tabBlue.opacity(0.10), radius: 8, y: 3)
    }

    var statusRow: some View {
        HStack(spacing: 8) {
            Text(row.statusText + (row.lines.isEmpty ? "" : " : " + row.lines))
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(row.isClose ? Color(red: 0.12, green: 0.55, blue: 0.28) : Color.secondary)
                .lineLimit(1).minimumScaleFactor(0.8)
            if !row.qtyText.isEmpty {
                Text(row.qtyText).font(.system(size: 16, weight: .bold)).foregroundStyle(Color.tabBlue)
                    .padding(.horizontal, 12).padding(.vertical, 5)
                    .background(Capsule().fill(Color.tabBlue.opacity(0.12)))
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            if row.showRemaining {
                let left = row.remaining
                let tint: Color = left > 0.0005 ? Color.orange : Color(red: 0.12, green: 0.55, blue: 0.28)
                Text("Remain " + PkgFmt.num(max(left, 0))).font(.system(size: 15, weight: .bold)).foregroundStyle(tint)
                    .padding(.horizontal, 12).padding(.vertical, 5)
                    .background(Capsule().fill(tint.opacity(0.14)))
                    .lineLimit(1).minimumScaleFactor(0.8)
            }
        }
    }
}

struct PkgLocTarget: Identifiable {
    let id = UUID()
    let params: [[String: Any]]
    let names: [String]
    let noun: String
    init(rows: [PkgRow]) { params = rows.map { $0.param(code: "SUMMARY") }; names = rows.map { $0.no }; noun = "kiện" }
    init(items: [PkgItem]) { params = items.map { $0.param }; names = items.map { $0.material.isEmpty ? $0.desc : $0.material }; noun = "hạng mục" }
}

// MARK: - Màn danh sách

struct DesmPackageSheet: View {
    @ObservedObject var model: BrowserModel
    var onClose: () -> Void
    /// Bấm một RSI/MRF trong chi tiết kiện: BrowserView đóng màn này rồi mở RSI Detail / MRF Detail đúng phiếu.
    var onOpenDoc: (DesmDocKind, String) -> Void = { _, _ in }

    @StateObject private var vm = PackageVM()
    @State private var showFilters = false
    @State private var detailRow: PkgRow? = nil
    @State private var locTarget: PkgLocTarget? = nil
    @State private var dialog: DesmDialogState? = nil
    @State private var share: ShareItem? = nil

    func ask(_ icon: String, _ title: String, _ message: String, _ button: String, _ destructive: Bool, _ run: @escaping () -> Void) {
        dialog = DesmDialogState(icon: icon, title: title, message: message, actions: [
            DesmDialogAction(title: button, kind: destructive ? .destructive : .primary, handler: run),
            DesmDialogAction(title: "Huỷ", kind: .cancel)
        ])
    }

    var ops: PkgActionOps {
        PkgActionOps(vm: vm, model: model, ask: { i, t, m, b, d, r in ask(i, t, m, b, d, r) }, openLoc: { rows in locTarget = PkgLocTarget(rows: rows) })
    }

    func runSearch() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        vm.search(model)
    }

    func exportCSV() {
        let r = vm.csv()
        if r.count == 0 { vm.error = "Không có kiện nào để xuất."; return }
        let f = DateFormatter(); f.dateFormat = "yyyyMMdd-HHmmss"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("package-\(f.string(from: Date())).csv")
        var data = Data([0xEF, 0xBB, 0xBF]); data.append(Data(r.text.utf8))
        do { try data.write(to: url); share = ShareItem(url: url) }
        catch let err { vm.error = "Không lưu được file: \(err.localizedDescription)" }
    }

    // MARK: Các khối giao diện

    var searchCard: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                Button { withAnimation(.easeInOut(duration: 0.2)) { showFilters.toggle() } } label: {
                    let n = vm.filter.count
                    HStack {
                        Text("Bộ lọc" + (n > 0 ? " (\(n))" : "")).font(.system(size: 19, weight: .bold)).foregroundStyle(Color(red: 0.10, green: 0.16, blue: 0.40))
                        Spacer(minLength: 4)
                        Image(systemName: showFilters ? "chevron.up" : "chevron.down").font(.system(size: 13, weight: .bold)).foregroundStyle(.secondary)
                    }
                    .padding(.horizontal, 16).frame(height: 52)
                    .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.tabBlue.opacity(0.25), lineWidth: 1))
                }
                .buttonStyle(.plain)

                Button { runSearch() } label: {
                    HStack(spacing: 8) {
                        if vm.loading { ProgressView().tint(.white) } else { Image(systemName: "magnifyingglass").font(.system(size: 17, weight: .semibold)) }
                        Text("Search").font(.system(size: 18, weight: .bold))
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 18).frame(height: 52)
                    .background(RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(LinearGradient(colors: [Color.tabBlue, Color(red: 0.30, green: 0.62, blue: 0.92)], startPoint: .leading, endPoint: .trailing)))
                    .shadow(color: Color.tabBlue.opacity(0.35), radius: 8, y: 3)
                }
                .buttonStyle(.plain)
                .disabled(vm.loading)

                Button { vm.resetFilters() } label: {
                    Image(systemName: "arrow.triangle.2.circlepath").font(.system(size: 20, weight: .semibold)).foregroundStyle(Color.tabBlue)
                        .frame(width: 52, height: 52)
                        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color(.systemGray4)))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Xoá ô tìm và bộ lọc")
            }
            HStack(spacing: 10) {
                PkgField(placeholder: "Packing List No.", text: $vm.plNo, submit: runSearch)
                PkgField(placeholder: "Package No.", text: $vm.pkgNo, submit: runSearch)
            }
            if showFilters { PkgFilterPanel(vm: vm, onSearch: runSearch) }
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Color(.secondarySystemGroupedBackground).opacity(0.7)))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.tabBlue.opacity(0.15), lineWidth: 1))
    }

    var actionPills: some View {
        let rows = vm.selectedRows
        let on = !rows.isEmpty
        return ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                PkgPill(icon: "mappin.and.ellipse", title: "Location Update", tint: Color(red: 0.34, green: 0.40, blue: 0.82), enabled: on) { ops.locationUpdate(rows) }
                PkgPill(icon: "mappin.slash", title: "Location Delete", tint: Color(red: 0.34, green: 0.40, blue: 0.82), enabled: on) { ops.locationDelete(rows) }
                PkgPill(icon: "xmark.circle", title: "Material Cancel", enabled: on) { ops.materialCancel(rows) }
                PkgPill(icon: "pencil.line", title: "Material Confirm", enabled: on) { ops.materialConfirm(rows) }
                PkgPill(icon: "shippingbox", title: "Customs Y/N", tint: Color(red: 0.55, green: 0.38, blue: 0.80), enabled: on) { ops.customs(rows) }
            }
            .padding(.horizontal, 2).padding(.vertical, 2)
        }
    }

    var banners: some View {
        VStack(spacing: 8) {
            if let e = vm.error {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.red)
                    Text(e).font(.system(size: 14)).foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading)
                    Button { vm.error = nil } label: { Image(systemName: "xmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary) }.buttonStyle(.plain)
                }
                .padding(12).background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.red.opacity(0.10)))
            }
            if let n = vm.notice {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                    Text(n).font(.system(size: 14, weight: .semibold)).foregroundStyle(Color(red: 0.12, green: 0.50, blue: 0.25)).frame(maxWidth: .infinity, alignment: .leading)
                    Button { vm.notice = nil } label: { Image(systemName: "xmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary) }.buttonStyle(.plain)
                }
                .padding(12).background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.green.opacity(0.12)))
            }
            if vm.busy {
                HStack(spacing: 8) { ProgressView(); Text("Đang gửi lệnh lên DESM…").font(.system(size: 14, weight: .semibold)) }
                    .frame(maxWidth: .infinity, alignment: .leading).padding(12)
                    .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.tabBlue.opacity(0.10)))
            }
        }
    }

    func chipsBlock(shownCount: Int) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            if vm.plCounts.count > 1 {
                PkgFlow(spacing: 8) {
                    PkgChip(title: "Tất cả (\(vm.rows.count))", on: vm.plSel == nil) { vm.plSel = nil; vm.pruneSelection() }
                    ForEach(vm.plCounts) { p in
                        PkgChip(title: "\(p.name) (\(p.count))", on: vm.plSel == p.name) { vm.plSel = p.name; vm.pruneSelection() }
                    }
                }
            }
            PkgFlow(spacing: 8) {
                PkgChip(title: "Tất cả (\(vm.stockCount(.all)))", on: vm.stockSel == .all) { vm.stockSel = .all; vm.pruneSelection() }
                PkgChip(title: "Còn hàng (\(vm.stockCount(.open)))", on: vm.stockSel == .open, tint: Color.orange) { vm.stockSel = .open; vm.pruneSelection() }
                PkgChip(title: "Đã xuất hết (\(vm.stockCount(.done)))", on: vm.stockSel == .done, tint: Color(red: 0.20, green: 0.62, blue: 0.36)) { vm.stockSel = .done; vm.pruneSelection() }
            }
            PkgFlow(spacing: 8) {
                ForEach(PkgSort.allCases, id: \.self) { s in
                    PkgChip(title: s.rawValue, on: vm.sort == s) { vm.sort = s }
                }
                PkgChip(title: "Chưa có vị trí (\(vm.noLocCount))", on: vm.onlyNoLoc, tint: Color.red) { vm.onlyNoLoc.toggle(); vm.pruneSelection() }
                PkgChip(title: "Xuất CSV (\(vm.selected.isEmpty ? shownCount : vm.selected.count))",
                        on: false, icon: "arrow.down.doc.fill") { exportCSV() }
            }
        }
    }

    func selectAllBar(shown: [PkgRow]) -> some View {
        let allOn = !shown.isEmpty && shown.allSatisfy { vm.selected.contains($0.id) }
        return HStack {
            Button { vm.setAll(!allOn) } label: {
                HStack(spacing: 8) {
                    Image(systemName: allOn ? "checkmark.square.fill" : "square").font(.system(size: 22)).foregroundStyle(allOn ? Color.tabBlue : Color(.tertiaryLabel))
                    Text("Chọn tất cả · \(shown.count) kiện").font(.system(size: 15, weight: .bold)).foregroundStyle(.primary)
                }
            }
            .buttonStyle(.plain)
            Spacer()
            if let t = vm.lastSearch {
                Text("Cập nhật \(PkgFmt.timeFmt.string(from: t))").font(.system(size: 12)).foregroundStyle(.secondary)
            }
        }
        .padding(.horizontal, 6)
    }

    var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: vm.searched ? "tray" : "shippingbox").font(.system(size: 42)).foregroundStyle(Color.tabBlue.opacity(0.5))
            Text(vm.searched ? "Không có kiện nào theo điều kiện này." : "Chưa có kiện hàng nào. Hãy nhập điều kiện lọc rồi bấm Search.")
                .font(.system(size: 17)).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 48).padding(.horizontal, 20)
    }

    var selectionBar: some View {
        HStack(spacing: 10) {
            Text("\(vm.selected.count) kiện đã chọn").font(.system(size: 15, weight: .bold))
            Spacer()
            Button("Bỏ chọn") { vm.selected = [] }.font(.system(size: 15, weight: .semibold))
            Menu {
                PkgActionMenuItems(ops: ops, rows: vm.selectedRows)
            } label: {
                Label("Thao tác", systemImage: "ellipsis.circle.fill").font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white).padding(.horizontal, 14).frame(height: 38)
                    .background(Capsule().fill(Color.tabBlue))
            }
        }
        .padding(.leading, 16).padding(.trailing, 70).padding(.vertical, 10)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.tabBlue.opacity(0.2), lineWidth: 1))
        .padding(.horizontal, 12).padding(.bottom, 8)
    }

    var body: some View {
        let list = vm.shown
        NavigationStack {
            ZStack(alignment: .bottom) {
                PkgBackground()
                ScrollView {
                    LazyVStack(spacing: 12) {
                        searchCard
                        actionPills
                        banners
                        if vm.loading && vm.rows.isEmpty {
                            VStack(spacing: 10) { ProgressView(); Text("Đang tìm…").foregroundStyle(.secondary) }.padding(.vertical, 40)
                        } else if vm.rows.isEmpty {
                            emptyState
                        } else {
                            chipsBlock(shownCount: list.count)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            selectAllBar(shown: list)
                            if list.isEmpty {
                                Text("Không có kiện nào khớp bộ lọc này.").font(.system(size: 16)).foregroundStyle(.secondary).padding(.vertical, 30)
                            }
                            ForEach(list) { r in
                                PkgCard(row: r, selected: vm.selected.contains(r.id),
                                        onToggle: { if vm.selected.contains(r.id) { vm.selected.remove(r.id) } else { vm.selected.insert(r.id) } },
                                        onOpen: { detailRow = r },
                                        onLocation: { locTarget = PkgLocTarget(rows: [r]) })
                            }
                        }
                    }
                    .padding(.horizontal, 14).padding(.top, 8)
                    .padding(.bottom, vm.selected.isEmpty ? 90 : 150)
                }
                if !vm.selected.isEmpty { selectionBar }
            }
            .navigationTitle("Package")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { onClose() } }
            }
            .navigationDestination(isPresented: Binding(get: { detailRow != nil }, set: { if !$0 { detailRow = nil } })) {
                if let r = detailRow {
                    PackageDetailView(model: model, listVM: vm, row: r, onOpenDoc: { kind, no in onOpenDoc(kind, no) })
                }
            }
        }
        .sheet(item: $locTarget) { t in
            PkgLocationSheet(model: model, target: t, onSaved: {
                vm.notice = "Đã cập nhật vị trí \(t.names.count) \(t.noun) ✓"
                vm.reload(model)
            })
            .desmSheet(shot: false)
        }
        .sheet(item: $share) { item in
            ShareSheet(url: item.url, extra: item.extra)
        }
        .desmDialog(dialog) { dialog = nil }
        .onAppear { vm.loadOptions(model) }
    }
}

// MARK: - Chọn vị trí mới (Location Update): chọn bản đồ → chọn ô

struct PkgLocationSheet: View {
    @ObservedObject var model: BrowserModel
    let target: PkgLocTarget
    var onSaved: () -> Void

    @Environment(\.dismiss) private var dismiss
    @StateObject private var lvm = PkgLocationVM()
    @State private var dialog: DesmDialogState? = nil
    @State private var working = false
    @State private var msg: String? = nil

    var mapName: String { lvm.maps.first(where: { $0.id == lvm.mapId })?.name ?? lvm.mapId }

    func choose(_ cell: PkgCell) {
        if working { return }
        working = true; msg = nil
        let list = PkgFmt.json(target.params)
        Task { @MainActor in
            let c = await lvm.check(model, list: list, cell: cell)
            working = false
            if let e = c.err { msg = "Kiểm tra vị trí lỗi: " + e; return }
            let dup = c.diff != nil
            let text = (dup ? "Có kiện đang ở vị trí khác — sẽ bị chuyển. " : "") + "Chuyển \(target.names.count) \(target.noun) sang \(mapName) / \(cell.name)?"
            dialog = DesmDialogState(icon: "mappin.and.ellipse", title: dup ? "Kiện đang ở vị trí khác" : "Cập nhật vị trí", message: text, actions: [
                DesmDialogAction(title: "Cập nhật", kind: .primary) { doSave(cell, list) },
                DesmDialogAction(title: "Huỷ", kind: .cancel)
            ])
        }
    }

    func doSave(_ cell: PkgCell, _ list: String) {
        working = true
        Task { @MainActor in
            let r = await lvm.save(model, list: list, cell: cell, count: target.names.count)
            working = false
            switch r {
            case .saved:
                onSaved()
                dismiss()
            case .failed(let m):
                msg = m
            }
        }
    }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .top) {
                PkgBackground()
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("\(target.names.count) \(target.noun) sẽ được chuyển").font(.system(size: 16, weight: .bold))
                            Text(target.names.prefix(3).joined(separator: ", ") + (target.names.count > 3 ? " … +\(target.names.count - 3)" : ""))
                                .font(.system(size: 14)).foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading).padding(14)
                        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))

                        if let m = msg {
                            Text(m).font(.system(size: 14)).foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading).padding(12)
                                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.red.opacity(0.10)))
                        }
                        if let e = lvm.error {
                            Text(e).font(.system(size: 14)).foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading).padding(12)
                                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.red.opacity(0.10)))
                        }
                        if lvm.loadingMaps { ProgressView("Đang tải bản đồ…").frame(maxWidth: .infinity).padding(.vertical, 20) }

                        if !lvm.maps.isEmpty {
                            Text("BẢN ĐỒ").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary)
                            PkgFlow(spacing: 8) {
                                ForEach(lvm.maps) { m in
                                    PkgChip(title: m.name, on: lvm.mapId == m.id) { lvm.mapId = m.id; lvm.term = ""; lvm.loadCells(model) }
                                }
                            }
                            PkgField(placeholder: "Tìm ô vị trí (vd Y3-1)", text: $lvm.term)
                            Text("CHỌN Ô VỊ TRÍ · \(lvm.filtered.count)").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary)
                            if lvm.loadingCells { ProgressView().frame(maxWidth: .infinity).padding(.vertical, 20) }
                            if !lvm.loadingCells && lvm.filtered.isEmpty {
                                Text("Không có ô vị trí nào.").font(.system(size: 15)).foregroundStyle(.secondary).padding(.vertical, 20)
                            }
                            PkgFlow(spacing: 8) {
                                ForEach(lvm.filtered) { c in
                                    Button { choose(c) } label: {
                                        Text(c.name).font(.system(size: 16, weight: .bold)).foregroundStyle(Color.tabBlue)
                                            .padding(.horizontal, 16).padding(.vertical, 11)
                                            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.tabBlue.opacity(0.10)))
                                            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.tabBlue.opacity(0.35), lineWidth: 1))
                                    }
                                    .buttonStyle(.plain)
                                    .disabled(working)
                                }
                            }
                        }
                    }
                    .padding(14)
                }
                if working {
                    ProgressView().padding(18).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16)).padding(.top, 80)
                }
            }
            .navigationTitle("Cập nhật vị trí")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { dismiss() } } }
        }
        .desmDialog(dialog) { dialog = nil }
        .onAppear { lvm.loadMaps(model) }
    }
}
