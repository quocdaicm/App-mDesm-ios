// PackageListView.swift — màn "Package" native (Thêm > Package): tìm kiện, bộ lọc đầy đủ như web, chip Packing List /
// Còn hàng / Đã xuất hết, sắp xếp, Xuất CSV, chọn nhiều kiện và các thao tác Material Confirm/Cancel, Location Update/Delete, Customs.
// Bấm một kiện → PackageDetailView (PackageDetailView.swift). Dữ liệu/API: PackageData.swift.
// Giao diện bám ảnh trang web Package: ô lọc bo tròn, nút Search xanh, nút làm mới xám, hàng nút thao tác màu xanh ngọc,
// thẻ kiện trắng có viền trái xanh lá (CLOSE) / cam / xanh, viên thuốc Remaining.
// CHƯA build Xcode / chưa thử máy thật.

import SwiftUI

// MARK: - Thành phần giao diện dùng chung

/// Bố cục xếp chip tự xuống dòng (iOS 16 Layout).
struct PkgFlow: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxW = proposal.width ?? .infinity
        var x: CGFloat = 0, y: CGFloat = 0, rowH: CGFloat = 0, w: CGFloat = 0
        for s in subviews {
            let sz = s.sizeThatFits(.unspecified)
            if x > 0 && x + sz.width > maxW { y += rowH + spacing; x = 0; rowH = 0 }
            x += sz.width + spacing
            rowH = max(rowH, sz.height)
            w = max(w, x - spacing)
        }
        return CGSize(width: w, height: y + rowH)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX, y = bounds.minY, rowH: CGFloat = 0
        for s in subviews {
            let sz = s.sizeThatFits(.unspecified)
            if x > bounds.minX && x + sz.width > bounds.maxX { y += rowH + spacing; x = bounds.minX; rowH = 0 }
            s.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(sz))
            x += sz.width + spacing
            rowH = max(rowH, sz.height)
        }
    }
}

struct PkgChip: View {
    let title: String
    var on: Bool
    var tint: Color = Color.tabBlue
    var icon: String? = nil
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if let i = icon { Image(systemName: i).font(.system(size: 13, weight: .semibold)) }
                Text(title).font(.system(size: 14, weight: .semibold))
            }
            .padding(.horizontal, 14).padding(.vertical, 9)
            .foregroundStyle(on ? Color.white : tint)
            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(on ? tint : Color(.secondarySystemGroupedBackground)))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(tint.opacity(on ? 0 : 0.35), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

struct PkgField: View {
    let placeholder: String
    @Binding var text: String
    var submit: () -> Void = {}

    var body: some View {
        TextField(placeholder, text: $text)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .submitLabel(.search)
            .onSubmit(submit)
            .font(.system(size: 16))
            .padding(.horizontal, 14).frame(height: 46)
            .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.tabBlue.opacity(0.25), lineWidth: 1))
    }
}

struct PkgLabeled<Content: View>: View {
    let title: String
    let content: Content
    init(_ title: String, @ViewBuilder content: () -> Content) { self.title = title; self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary)
            content
        }
    }
}

struct PkgYN: View {
    let title: String
    @Binding var value: String
    var body: some View {
        PkgLabeled(title) {
            Picker(title, selection: $value) {
                Text("Tất cả").tag("")
                Text("Y").tag("Y")
                Text("N").tag("N")
            }
            .pickerStyle(.segmented)
        }
    }
}

struct PkgMenuField: View {
    let placeholder: String
    @Binding var text: String
    let options: [String]
    var body: some View {
        HStack(spacing: 8) {
            PkgField(placeholder: placeholder, text: $text)
            Menu {
                Button("(Tất cả)") { text = "" }
                ForEach(options, id: \.self) { o in Button(o) { text = o } }
            } label: {
                Image(systemName: "chevron.down.circle.fill").font(.system(size: 26)).foregroundStyle(Color.tabBlue)
            }
            .disabled(options.isEmpty)
        }
    }
}

struct PkgDateField: View {
    let title: String
    @Binding var date: Date?
    var body: some View {
        PkgLabeled(title) {
            HStack(spacing: 6) {
                if let d = date {
                    DatePicker("", selection: Binding(get: { d }, set: { date = $0 }), displayedComponents: .date).labelsHidden()
                    Button { date = nil } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }.buttonStyle(.plain)
                } else {
                    Button { date = Date() } label: {
                        Text("Chọn ngày").font(.system(size: 15)).foregroundStyle(Color.tabBlue)
                            .frame(maxWidth: .infinity, minHeight: 40, alignment: .leading).padding(.horizontal, 12)
                            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

struct PkgPill: View {
    let icon: String
    let title: String
    var tint: Color = Color(red: 0.31, green: 0.62, blue: 0.74)
    var enabled = true
    /// true = giãn đều hết chiều ngang (dùng khi xếp 2 nút cạnh nhau cho cân giữa)
    var fill = false
    let action: () -> Void
    @ObservedObject private var tr = NativeTranslator.shared
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: icon).font(.system(size: 16, weight: .semibold))
                Text(tr.t(title)).font(.system(size: 16, weight: .bold)).lineLimit(1).minimumScaleFactor(0.75)
            }
            .foregroundStyle(.white)
            .padding(.horizontal, fill ? 10 : 18)
            .frame(maxWidth: fill ? .infinity : nil)
            .frame(height: 46)
            .background(Capsule().fill(LinearGradient(colors: [tint, tint.opacity(0.78)], startPoint: .leading, endPoint: .trailing)))
            .opacity(enabled ? 1 : 0.45)
        }
        .buttonStyle(.plain)
    }
}

struct PkgTag: View {
    let text: String
    var tint: Color
    var body: some View {
        Text(text).font(.system(size: 12, weight: .bold)).foregroundStyle(tint)
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(Capsule().fill(tint.opacity(0.14)))
    }
}

/// Nền xanh nhạt giống trang web.
struct PkgBackground: View {
    var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
            LinearGradient(colors: [Color.tabBlue.opacity(0.10), Color.tabBlueLight.opacity(0.04), Color.clear], startPoint: .top, endPoint: .bottom)
        }
        .ignoresSafeArea()
    }
}

/// Ẩn bàn phím (dùng khi chạm ngoài ô nhập / kéo danh sách / bấm Xong)
func pkgHideKeyboard() {
    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
}

extension View {
    /// Kéo cuộn hoặc chạm ra ngoài ô nhập thì tự ẩn bàn phím; thêm nút "Xong" trên bàn phím. Không chặn các nút bên trong.
    func pkgKeyboardDismiss() -> some View {
        self
            .scrollDismissesKeyboard(.interactively)
            .simultaneousGesture(TapGesture().onEnded { pkgHideKeyboard() })
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Xong") { pkgHideKeyboard() }.font(.system(size: 16, weight: .semibold))
                }
            }
    }
}

typealias PkgAsk = (_ icon: String, _ title: String, _ message: String, _ button: String, _ destructive: Bool, _ run: @escaping () -> Void) -> Void

/// Các thao tác ghi trên một nhóm kiện: hỏi xác nhận (ask) rồi gọi PackageVM. Dùng chung cho danh sách và chi tiết.
struct PkgActionOps {
    let vm: PackageVM
    let model: BrowserModel
    let ask: PkgAsk
    let openLoc: ([PkgRow]) -> Void

    func need(_ rows: [PkgRow]) -> Bool {
        if rows.isEmpty { vm.error = "Hãy chọn ít nhất một kiện trước."; return false }
        return true
    }
    func locationUpdate(_ rows: [PkgRow]) { if need(rows) { openLoc(rows) } }
    func locationDelete(_ rows: [PkgRow]) {
        if !need(rows) { return }
        ask("mappin.slash", "Xoá vị trí (Location Delete)", "Xoá vị trí của \(rows.count) kiện đã chọn trên DESM? Thao tác này không tự hoàn tác được.", "Xoá vị trí", true) {
            vm.deleteLocation(model, rows: rows)
        }
    }
    func materialConfirm(_ rows: [PkgRow]) {
        if !need(rows) { return }
        ask("checkmark.seal.fill", "Xác nhận vật tư (Material Confirm)", "Xác nhận \(rows.count) kiện đã chọn trên DESM?", "Xác nhận", false) {
            vm.confirmMaterial(model, rows: rows)
        }
    }
    func materialCancel(_ rows: [PkgRow]) {
        if !need(rows) { return }
        ask("xmark.seal.fill", "Hủy xác nhận (Material Cancel)", "Hủy xác nhận \(rows.count) kiện đã chọn? Kiện đã có RSI sẽ bị từ chối.", "Hủy xác nhận", true) {
            vm.cancelMaterial(model, rows: rows)
        }
    }
    func customs(_ rows: [PkgRow]) {
        if !need(rows) { return }
        guard let target = vm.customsTarget(rows: rows) else {
            vm.error = "Các kiện đã chọn có giá trị Customs khác nhau — chỉ đổi được khi cùng giá trị."
            return
        }
        ask("shippingbox.fill", "Đổi Customs", "Đổi Customs của \(rows.count) kiện sang \(target)?", "Đổi sang \(target)", false) {
            vm.setCustoms(model, rows: rows, to: target)
        }
    }
}

/// Nội dung menu "Thao tác" (dùng trong Menu { } ở danh sách và chi tiết).
struct PkgActionMenuItems: View {
    let ops: PkgActionOps
    let rows: [PkgRow]
    var body: some View {
        Group {
            Button { ops.locationUpdate(rows) } label: { Label("Location Update", systemImage: "mappin.and.ellipse") }
            Button { ops.locationDelete(rows) } label: { Label("Location Delete", systemImage: "mappin.slash") }
            Button { ops.materialConfirm(rows) } label: { Label("Material Confirm", systemImage: "checkmark.seal") }
            Button { ops.materialCancel(rows) } label: { Label("Material Cancel", systemImage: "xmark.seal") }
            Button { ops.customs(rows) } label: { Label("Customs Y/N", systemImage: "shippingbox") }
        }
    }
}

// MARK: - Bảng lọc đầy đủ (nút "Bộ lọc")

struct PkgFilterPanel: View {
    @ObservedObject var vm: PackageVM
    var onSearch: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            PkgLabeled("Description") { PkgField(placeholder: "Mô tả / tên vật tư", text: $vm.filter.desc, submit: onSearch) }
            PkgLabeled("Voyage") { PkgMenuField(placeholder: "Voyage (ATTRIBUTE10)", text: $vm.filter.voyage, options: vm.voyages) }
            PkgLabeled("Location") { PkgMenuField(placeholder: "Vị trí kho", text: $vm.filter.location, options: vm.locations) }
            HStack(spacing: 10) {
                PkgLabeled("Remark") { PkgField(placeholder: "Remark", text: $vm.filter.remark, submit: onSearch) }
                PkgLabeled("Vendor") { PkgField(placeholder: "Vendor", text: $vm.filter.vendor, submit: onSearch) }
            }
            PkgYN(title: "Confirm Material", value: $vm.filter.confirm)
            PkgYN(title: "Receipted", value: $vm.filter.receipted)
            PkgYN(title: "MRR Received", value: $vm.filter.mrrReceived)
            PkgYN(title: "Customs", value: $vm.filter.customs)
            PkgLabeled("V/C (MRR Visual Check)") { PkgField(placeholder: "Để trống = All (vd Good)", text: $vm.filter.visual, submit: onSearch) }
            HStack(spacing: 10) {
                PkgDateField(title: "Receipt từ", date: $vm.filter.recFrom)
                PkgDateField(title: "Receipt đến", date: $vm.filter.recTo)
            }
            HStack(spacing: 10) {
                PkgDateField(title: "MRR từ", date: $vm.filter.mrrFrom)
                PkgDateField(title: "MRR đến", date: $vm.filter.mrrTo)
            }
            HStack {
                Button { vm.filter = PkgFilter() } label: {
                    Text("Xoá bộ lọc").font(.system(size: 15, weight: .semibold)).foregroundStyle(.red)
                        .frame(maxWidth: .infinity, minHeight: 44)
                        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.red.opacity(0.10)))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 4)
    }
}

// MARK: - Thẻ kiện

struct PkgCard: View {
    let row: PkgRow
    let selected: Bool
    var onToggle: () -> Void
    var onOpen: () -> Void
    var onLocation: () -> Void
    @ObservedObject private var tr = NativeTranslator.shared

    var accent: Color {
        if row.isClose { return Color(red: 0.25, green: 0.70, blue: 0.40) }
        if row.hasQty && row.shipped > 0 && row.remaining > 0 { return Color.orange }
        return Color.tabBlue
    }

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Button(action: onToggle) {
                Image(systemName: selected ? "checkmark.square.fill" : "square")
                    .font(.system(size: 28, weight: .regular))
                    .foregroundStyle(selected ? Color.tabBlue : Color(.tertiaryLabel))
                    .frame(width: 34, height: 34)
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 6) {
                Button(action: onOpen) {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text(row.no).font(.system(size: 20, weight: .heavy)).foregroundStyle(.primary)
                                .lineLimit(2).minimumScaleFactor(0.8)
                            Spacer(minLength: 4)
                            if row.customs == "Y" { PkgTag(text: "Customs", tint: .purple) }
                            if row.confirmed { Image(systemName: "checkmark.seal.fill").font(.system(size: 15)).foregroundStyle(.green) }
                        }
                        if !row.desc.isEmpty {
                            Text(tr.t(row.desc)).font(.system(size: 17)).foregroundStyle(.primary).lineLimit(3)
                        }
                        let sub = [row.s("PACKAGE_TYPE"), row.plNo].filter { !$0.isEmpty }.joined(separator: " · ")
                        if !sub.isEmpty {
                            Text(sub).font(.system(size: 15)).foregroundStyle(.secondary).lineLimit(1)
                        }
                        statusRow
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                Divider()
                Button(action: onLocation) {
                    HStack(spacing: 6) {
                        Image(systemName: "mappin.and.ellipse").font(.system(size: 16, weight: .semibold))
                        Text(row.loc.isEmpty ? "Chưa có vị trí" : row.loc)
                            .font(.system(size: 17, weight: .bold)).underline()
                            .lineLimit(1).minimumScaleFactor(0.8)
                        Spacer(minLength: 0)
                    }
                    .foregroundStyle(row.loc.isEmpty ? Color.red : Color.primary)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 12).padding(.leading, 10).padding(.trailing, 12)
        .background(Color(.secondarySystemGroupedBackground))
        .overlay(alignment: .leading) { Rectangle().fill(accent).frame(width: 6) }
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(selected ? Color.tabBlue : Color.clear, lineWidth: 2))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .shadow(color: Color.tabBlue.opacity(0.10), radius: 8, y: 3)
    }

    var statusRow: some View {
        let okGreen = Color(red: 0.12, green: 0.55, blue: 0.28)
        let st = row.statusText + (row.lines.isEmpty ? "" : " : " + row.lines)
        let stTint: Color = row.isClose ? okGreen : (row.accentIsPartial ? Color.orange : Color.secondary)
        let left = max(row.remaining, 0)
        let leftTint: Color = left > 0.0005 ? Color.orange : okGreen
        return VStack(alignment: .leading, spacing: 8) {
            // Dòng trạng thái: hiện đủ chữ, không bị cắt "…"
            Text(st)
                .font(.system(size: 14, weight: .heavy)).foregroundStyle(stTint)
                .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(Capsule().fill(stTint.opacity(0.14)))
            if row.hasQty {
                // Ba ô số liệu chia đều: Tổng · Đã xuất · Còn lại
                HStack(spacing: 8) {
                    statCell("Tổng", PkgFmt.num(row.total), Color.tabBlue)
                    statCell("Đã xuất", PkgFmt.num(row.shipped), Color.tabBlue)
                    if row.showRemaining { statCell("Còn lại", PkgFmt.num(left), leftTint) }
                }
            }
        }
    }

    func statCell(_ title: String, _ value: String, _ tint: Color) -> some View {
        VStack(spacing: 2) {
            Text(title).font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
            Text(value).font(.system(size: 17, weight: .bold)).foregroundStyle(tint)
                .lineLimit(1).minimumScaleFactor(0.55)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 7).padding(.horizontal, 4)
        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(tint.opacity(0.10)))
    }
}

struct PkgLocTarget: Identifiable {
    let id = UUID()
    let params: [[String: Any]]
    let names: [String]
    let noun: String
    init(rows: [PkgRow]) { params = rows.map { $0.param(code: "SUMMARY") }; names = rows.map { $0.no }; noun = "kiện" }
    init(items: [PkgItem]) { params = items.map { $0.param }; names = items.map { $0.material.isEmpty ? $0.desc : $0.material }; noun = "hạng mục" }
}

/// Nút thao tác gọn (lưới 2 cột) — dùng cho khối "Thao tác".
struct PkgActionButton: View {
    let icon: String
    let title: String
    var tint: Color
    var enabled = true
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 7) {
                Image(systemName: icon).font(.system(size: 14, weight: .semibold))
                Text(title).font(.system(size: 14, weight: .bold)).lineLimit(1).minimumScaleFactor(0.8)
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity).frame(height: 42)
            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(tint))
            .opacity(enabled ? 1 : 0.4)
        }
        .buttonStyle(.plain)
    }
}

/// Khung thẻ có tiêu đề nhỏ — gom các nhóm điều khiển cho ngăn nắp.
struct PkgCardBox<Content: View>: View {
    var title: String? = nil
    var trailing: String? = nil
    let content: Content
    init(title: String? = nil, trailing: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title; self.trailing = trailing; self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if title != nil || trailing != nil {
                HStack {
                    if let t = title { Text(t.uppercased()).font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary).tracking(0.5) }
                    Spacer()
                    if let r = trailing { Text(r).font(.system(size: 12, weight: .semibold)).foregroundStyle(Color.tabBlue) }
                }
            }
            content
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color(.secondarySystemGroupedBackground).opacity(0.7)))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.tabBlue.opacity(0.15), lineWidth: 1))
    }
}

// MARK: - Màn danh sách

struct DesmPackageSheet: View {
    @ObservedObject var model: BrowserModel
    /// true = màn chính của app (full màn hình, không có nút Đóng)
    var embedded = false
    var onClose: () -> Void = {}
    /// Bấm một RSI/MRF trong chi tiết kiện: BrowserView đóng màn này rồi mở RSI Detail / MRF Detail đúng phiếu.
    var onOpenDoc: (DesmDocKind, String) -> Void = { _, _ in }

    @StateObject private var vm = PackageVM()
    @State private var showFilters = false
    /// Ẩn/hiện toàn bộ khối từ "Tìm kiếm" trở xuống (nhớ lựa chọn giữa các lần mở).
    @AppStorage("pkg.showTools") private var showTools = true
    @State private var detailRow: PkgRow? = nil
    @State private var locTarget: PkgLocTarget? = nil
    @State private var dialog: DesmDialogState? = nil
    @State private var share: ShareItem? = nil
    @State private var pendingOpen: PkgNativeSearch? = nil

    /// Nhận yêu cầu tìm kiện (quét mã…): điền ô, Search, xong thì mở đúng kiện nếu được yêu cầu.
    func consume(_ s: PkgNativeSearch?) {
        guard let s = s else { return }
        model.nativeSearch = nil
        vm.plNo = ""; vm.pkgNo = ""; vm.filter = PkgFilter()
        if s.kind == .package { vm.pkgNo = s.term } else { vm.plNo = s.term }
        pendingOpen = s.open ? s : nil
        detailRow = nil
        vm.search(model)
    }

    func finishPending() {
        guard let s = pendingOpen else { return }
        pendingOpen = nil
        func norm(_ x: String) -> String { String(x.uppercased().filter { $0.isLetter || $0.isNumber }) }
        let key = norm(s.key), term = norm(s.term)
        let hit = vm.rows.first(where: { norm($0.no) == term || (!key.isEmpty && norm($0.no).hasSuffix(key)) })
            ?? (vm.rows.count == 1 ? vm.rows.first : nil)
        if let r = hit { detailRow = r }
    }

    func ask(_ icon: String, _ title: String, _ message: String, _ button: String, _ destructive: Bool, _ run: @escaping () -> Void) {
        dialog = DesmDialogState(icon: icon, title: title, message: message, actions: [
            DesmDialogAction(title: button, kind: destructive ? .destructive : .primary, handler: run),
            DesmDialogAction(title: "Huỷ", kind: .cancel)
        ])
    }

    var ops: PkgActionOps {
        PkgActionOps(vm: vm, model: model, ask: { i, t, m, b, d, r in ask(i, t, m, b, d, r) }, openLoc: { rows in locTarget = PkgLocTarget(rows: rows) })
    }

    func runSearch() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        vm.search(model)
    }

    func exportCSV() {
        let r = vm.csv()
        if r.count == 0 { vm.error = "Không có kiện nào để xuất."; return }
        let f = DateFormatter(); f.dateFormat = "yyyyMMdd-HHmmss"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("package-\(f.string(from: Date())).csv")
        var data = Data([0xEF, 0xBB, 0xBF]); data.append(Data(r.text.utf8))
        do { try data.write(to: url); share = ShareItem(url: url) }
        catch let err { vm.error = "Không lưu được file: \(err.localizedDescription)" }
    }

    // MARK: Các khối giao diện

    /// Thanh bật/tắt: ẩn hết ô tìm kiếm, nút thao tác, bộ lọc nhanh để dành chỗ cho danh sách.
    func toolsToggleBar(shownCount: Int) -> some View {
        let nf = vm.filter.count
        var parts: [String] = []
        if !vm.rows.isEmpty { parts.append("\(shownCount) kiện") }
        if nf > 0 { parts.append("\(nf) bộ lọc") }
        if !vm.selected.isEmpty { parts.append("\(vm.selected.count) đã chọn") }
        let summary = parts.isEmpty ? "Tìm kiếm & thao tác" : parts.joined(separator: " · ")
        return Button { withAnimation(.easeInOut(duration: 0.22)) { showTools.toggle() } } label: {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").font(.system(size: 15, weight: .bold)).foregroundStyle(Color.tabBlue)
                Text(showTools ? "Tìm kiếm & thao tác" : summary)
                    .font(.system(size: 15, weight: .bold)).foregroundStyle(Color(red: 0.10, green: 0.16, blue: 0.40)).lineLimit(1)
                Spacer(minLength: 6)
                Text(showTools ? "Ẩn" : "Hiện").font(.system(size: 14, weight: .semibold)).foregroundStyle(Color.tabBlue)
                Image(systemName: showTools ? "chevron.up" : "chevron.down").font(.system(size: 12, weight: .bold)).foregroundStyle(Color.tabBlue)
            }
            .padding(.horizontal, 14).frame(height: 44)
            .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.tabBlue.opacity(0.25), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(showTools ? "Ẩn khối tìm kiếm" : "Hiện khối tìm kiếm")
    }

    var searchCard: some View {
        PkgCardBox(title: "Tìm kiếm") {
            // Hàng 1: hai ô nhập
            HStack(spacing: 10) {
                PkgField(placeholder: "Packing List No.", text: $vm.plNo, submit: runSearch)
                PkgField(placeholder: "Package No.", text: $vm.pkgNo, submit: runSearch)
            }
            // Hàng 2: Bộ lọc · Search · Làm mới
            HStack(spacing: 10) {
                Button { withAnimation(.easeInOut(duration: 0.2)) { showFilters.toggle() } } label: {
                    let n = vm.filter.count
                    HStack(spacing: 6) {
                        Image(systemName: "slider.horizontal.3").font(.system(size: 15, weight: .semibold))
                        Text("Bộ lọc" + (n > 0 ? " (\(n))" : "")).font(.system(size: 16, weight: .bold))
                        Image(systemName: showFilters ? "chevron.up" : "chevron.down").font(.system(size: 11, weight: .bold))
                    }
                    .foregroundStyle(Color(red: 0.10, green: 0.16, blue: 0.40))
                    .padding(.horizontal, 14).frame(height: 48)
                    .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                    .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.tabBlue.opacity(0.25), lineWidth: 1))
                }
                .buttonStyle(.plain)

                Button { runSearch() } label: {
                    HStack(spacing: 8) {
                        if vm.loading { ProgressView().tint(.white) } else { Image(systemName: "magnifyingglass").font(.system(size: 16, weight: .semibold)) }
                        Text("Search").font(.system(size: 17, weight: .bold))
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity).frame(height: 48)
                    .background(RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(LinearGradient(colors: [Color.tabBlue, Color(red: 0.30, green: 0.62, blue: 0.92)], startPoint: .leading, endPoint: .trailing)))
                    .shadow(color: Color.tabBlue.opacity(0.30), radius: 6, y: 2)
                }
                .buttonStyle(.plain)
                .disabled(vm.loading)

                Button { vm.resetFilters() } label: {
                    Image(systemName: "arrow.triangle.2.circlepath").font(.system(size: 18, weight: .semibold)).foregroundStyle(Color.tabBlue)
                        .frame(width: 48, height: 48)
                        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.systemGray5)))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Xoá ô tìm và bộ lọc")
            }
            if showFilters { PkgFilterPanel(vm: vm, onSearch: runSearch) }
        }
    }

    var actionPills: some View {
        let rows = vm.selectedRows
        let on = !rows.isEmpty
        let indigo = Color.tabBlue
        let teal = Color(red: 0.31, green: 0.62, blue: 0.74)
        let purple = Color(red: 0.55, green: 0.38, blue: 0.80)
        let cols = [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)]
        return PkgCardBox(title: "Thao tác", trailing: on ? "\(rows.count) kiện đã chọn" : "Chọn kiện bên dưới") {
            LazyVGrid(columns: cols, spacing: 10) {
                PkgActionButton(icon: "mappin.and.ellipse", title: "Location Update", tint: indigo, enabled: on) { ops.locationUpdate(rows) }
                PkgActionButton(icon: "mappin.slash", title: "Location Delete", tint: indigo, enabled: on) { ops.locationDelete(rows) }
                PkgActionButton(icon: "pencil.line", title: "Material Confirm", tint: teal, enabled: on) { ops.materialConfirm(rows) }
                PkgActionButton(icon: "xmark.circle", title: "Material Cancel", tint: teal, enabled: on) { ops.materialCancel(rows) }
            }
            PkgActionButton(icon: "shippingbox", title: "Customs Y/N", tint: purple, enabled: on) { ops.customs(rows) }
        }
    }

    var banners: some View {
        VStack(spacing: 8) {
            if let e = vm.error {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.red)
                    Text(e).font(.system(size: 14)).foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading)
                    Button { vm.error = nil } label: { Image(systemName: "xmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary) }.buttonStyle(.plain)
                }
                .padding(12).background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.red.opacity(0.10)))
            }
            if let n = vm.notice {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                    Text(n).font(.system(size: 14, weight: .semibold)).foregroundStyle(Color(red: 0.12, green: 0.50, blue: 0.25)).frame(maxWidth: .infinity, alignment: .leading)
                    Button { vm.notice = nil } label: { Image(systemName: "xmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary) }.buttonStyle(.plain)
                }
                .padding(12).background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.green.opacity(0.12)))
            }
            if vm.busy {
                HStack(spacing: 8) { ProgressView(); Text("Đang gửi lệnh lên DESM…").font(.system(size: 14, weight: .semibold)) }
                    .frame(maxWidth: .infinity, alignment: .leading).padding(12)
                    .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.tabBlue.opacity(0.10)))
            }
        }
    }

    func chipsBlock(shownCount: Int) -> some View {
        let green = Color(red: 0.20, green: 0.62, blue: 0.36)
        return PkgCardBox(title: "Lọc nhanh") {
            if vm.plCounts.count > 1 {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Packing List").font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            PkgChip(title: "Tất cả (\(vm.rows.count))", on: vm.plSel == nil) { vm.plSel = nil; vm.pruneSelection() }
                            ForEach(vm.plCounts) { p in
                                PkgChip(title: "\(p.name) (\(p.count))", on: vm.plSel == p.name) { vm.plSel = p.name; vm.pruneSelection() }
                            }
                        }
                    }
                }
            }
            VStack(alignment: .leading, spacing: 6) {
                Text("Tình trạng").font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        PkgChip(title: "Tất cả (\(vm.stockCount(.all)))", on: vm.stockSel == .all) { vm.stockSel = .all; vm.pruneSelection() }
                        PkgChip(title: "Còn hàng (\(vm.stockCount(.open)))", on: vm.stockSel == .open, tint: Color.orange) { vm.stockSel = .open; vm.pruneSelection() }
                        PkgChip(title: "Đã xuất hết (\(vm.stockCount(.done)))", on: vm.stockSel == .done, tint: green) { vm.stockSel = .done; vm.pruneSelection() }
                        PkgChip(title: "Chưa có vị trí (\(vm.noLocCount))", on: vm.onlyNoLoc, tint: Color.red) { vm.onlyNoLoc.toggle(); vm.pruneSelection() }
                    }
                }
            }
            HStack(spacing: 10) {
                Menu {
                    Picker("Sắp xếp", selection: $vm.sort) {
                        ForEach(PkgSort.allCases, id: \.self) { s in Text(s.rawValue).tag(s) }
                    }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "arrow.up.arrow.down").font(.system(size: 13, weight: .semibold))
                        Text(vm.sort.rawValue).font(.system(size: 14, weight: .semibold)).lineLimit(1)
                        Image(systemName: "chevron.down").font(.system(size: 10, weight: .bold))
                    }
                    .foregroundStyle(Color.tabBlue)
                    .padding(.horizontal, 14).padding(.vertical, 9)
                    .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.tabBlue.opacity(0.35), lineWidth: 1))
                }
                Spacer(minLength: 6)
                PkgChip(title: "Xuất CSV (\(vm.selected.isEmpty ? shownCount : vm.selected.count))",
                        on: false, icon: "arrow.down.doc.fill") { exportCSV() }
            }
        }
    }

    func selectAllBar(shown: [PkgRow]) -> some View {
        let allOn = !shown.isEmpty && shown.allSatisfy { vm.selected.contains($0.id) }
        return HStack {
            Button { vm.setAll(!allOn) } label: {
                HStack(spacing: 8) {
                    Image(systemName: allOn ? "checkmark.square.fill" : "square").font(.system(size: 22)).foregroundStyle(allOn ? Color.tabBlue : Color(.tertiaryLabel))
                    Text("Chọn tất cả · \(shown.count) kiện").font(.system(size: 15, weight: .bold)).foregroundStyle(.primary)
                }
            }
            .buttonStyle(.plain)
            Spacer()
            if let t = vm.lastSearch {
                Text("Cập nhật \(PkgFmt.timeFmt.string(from: t))").font(.system(size: 12)).foregroundStyle(.secondary)
            }
        }
        .padding(.horizontal, 6)
    }

    var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: vm.searched ? "tray" : "shippingbox").font(.system(size: 42)).foregroundStyle(Color.tabBlue.opacity(0.5))
            Text(vm.searched ? "Không có kiện nào theo điều kiện này." : "Chưa có kiện hàng nào. Hãy nhập điều kiện lọc rồi bấm Search.")
                .font(.system(size: 17)).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 48).padding(.horizontal, 20)
    }

    var selectionBar: some View {
        HStack(spacing: 10) {
            Text("\(vm.selected.count) kiện đã chọn").font(.system(size: 15, weight: .bold))
            Spacer()
            Button("Bỏ chọn") { vm.selected = [] }.font(.system(size: 15, weight: .semibold))
            Menu {
                PkgActionMenuItems(ops: ops, rows: vm.selectedRows)
            } label: {
                Label("Thao tác", systemImage: "ellipsis.circle.fill").font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white).padding(.horizontal, 14).frame(height: 38)
                    .background(Capsule().fill(Color.tabBlue))
            }
        }
        .padding(.leading, 16).padding(.trailing, 70).padding(.vertical, 10)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.tabBlue.opacity(0.2), lineWidth: 1))
        .padding(.horizontal, 6).padding(.bottom, 8)
    }

    var body: some View {
        let list = vm.shown
        NavigationStack {
            ZStack(alignment: .bottom) {
                PkgBackground()
                ScrollView {
                    LazyVStack(spacing: 12) {
                        toolsToggleBar(shownCount: list.count)
                        if showTools {
                            searchCard
                            if !vm.selected.isEmpty {
                                actionPills
                                    .transition(.move(edge: .top).combined(with: .opacity))
                            }
                        }
                        banners
                        if vm.loading && vm.rows.isEmpty {
                            VStack(spacing: 10) { ProgressView(); Text("Đang tìm…").foregroundStyle(.secondary) }.padding(.vertical, 40)
                        } else if vm.rows.isEmpty {
                            emptyState
                        } else {
                            if showTools {
                                chipsBlock(shownCount: list.count)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            selectAllBar(shown: list)
                            if list.isEmpty {
                                Text("Không có kiện nào khớp bộ lọc này.").font(.system(size: 16)).foregroundStyle(.secondary).padding(.vertical, 30)
                            }
                            ForEach(list) { r in
                                PkgCard(row: r, selected: vm.selected.contains(r.id),
                                        onToggle: { if vm.selected.contains(r.id) { vm.selected.remove(r.id) } else { vm.selected.insert(r.id) } },
                                        onOpen: { detailRow = r },
                                        onLocation: { locTarget = PkgLocTarget(rows: [r]) })
                            }
                        }
                    }
                    .padding(.horizontal, 6).padding(.top, 8)
                    .padding(.bottom, vm.selected.isEmpty ? 90 : 150)
                    .animation(.easeInOut(duration: 0.2), value: vm.selected.isEmpty)
                }
                .pkgKeyboardDismiss()
                if !vm.selected.isEmpty { selectionBar }
            }
            .navigationTitle("Package")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if !embedded { ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { onClose() } } }
                ToolbarItem(placement: .navigationBarTrailing) {
                    NativeTranslateButton(signature: vm.rows.count) { vm.rows.prefix(60).map { $0.desc } }
                }
            }
            .navigationDestination(isPresented: Binding(get: { detailRow != nil }, set: { if !$0 { detailRow = nil } })) {
                if let r = detailRow {
                    PackageDetailView(model: model, listVM: vm, row: r, onOpenDoc: { kind, no in onOpenDoc(kind, no) })
                }
            }
        }
        .sheet(item: $locTarget) { t in
            PkgLocationSheet(model: model, target: t, onSaved: {
                vm.notice = "Đã cập nhật vị trí \(t.names.count) \(t.noun) ✓"
                vm.reload(model)
            })
            .desmSheet(shot: false)
        }
        .sheet(item: $share) { item in
            ShareSheet(url: item.url, extra: item.extra)
        }
        .desmDialog(dialog) { dialog = nil }
        .onAppear { vm.loadOptions(model); consume(model.nativeSearch) }
        .onChange(of: model.nativeSearch) { s in consume(s) }
        .onChange(of: vm.loading) { l in if !l { finishPending() } }
    }
}

// MARK: - Chọn vị trí mới (Location Update): chọn bản đồ → chọn ô

// MARK: - Sắp xếp ô vị trí theo từng dòng + ảnh bản đồ

/// Nhóm ô vị trí thành từng dòng: C1–C3 / ELEC, Unloading… / Y1-x / Y2-x / Y3-x …
struct PkgCellGroup: Identifiable {
    let id: String
    let rank: Int
    let cells: [PkgCell]

    static func make(_ cells: [PkgCell]) -> [PkgCellGroup] {
        func key(_ n: String) -> (String, Int) {
            let t = n.trimmingCharacters(in: .whitespaces)
            // Y1-3 → nhóm "Y1"; bất kỳ "XXX-n" → nhóm "XXX"
            if let r = t.range(of: "-", options: .backwards), t[r.upperBound...].allSatisfy({ $0.isNumber }), !t[r.upperBound...].isEmpty {
                return (String(t[..<r.lowerBound]).uppercased(), 2)
            }
            // C1, C2, C3 → nhóm "C"
            if let m = t.range(of: "^[A-Za-z]+[0-9]+$", options: .regularExpression), m.lowerBound == t.startIndex {
                return (String(t.prefix(while: { $0.isLetter })).uppercased(), 0)
            }
            return ("~", 1)   // ELEC#1, ELEC#2, Unloading Bay area… gom một dòng
        }
        var dict: [String: (Int, [PkgCell])] = [:]
        for c in cells {
            let (k, r) = key(c.name)
            dict[k, default: (r, [])].1.append(c)
        }
        return dict.map { PkgCellGroup(id: $0.key, rank: $0.value.0, cells: $0.value.1.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }) }
            .sorted { $0.rank != $1.rank ? $0.rank < $1.rank : $0.id.localizedStandardCompare($1.id) == .orderedAscending }
    }
}

/// Ảnh bản đồ + viền các ô vị trí (toạ độ theo canvas 1200×700 của web). Chạm ảnh để phóng to/thu nhỏ.
struct PkgMapPreview: View {
    let image: UIImage
    let cells: [PkgCell]
    let highlight: Set<String>
    @State private var zoomed = false

    static let W: CGFloat = 1200, H: CGFloat = 700

    func path(for c: PkgCell) -> Path {
        var p = Path()
        let nums: (String) -> [CGFloat] = { $0.split(separator: ",").compactMap { Double($0.trimmingCharacters(in: .whitespaces)) }.map { CGFloat($0) } }
        if c.type == "RECT" {
            let a = nums(c.pos)
            if a.count >= 4 { p.addRect(CGRect(x: a[0], y: a[1], width: a[2], height: a[3])) }
        } else if c.type == "LINE" {
            let pts = c.pos.split(separator: ";").map { nums(String($0)) }.filter { $0.count >= 2 }
            for (i, q) in pts.enumerated() { i == 0 ? p.move(to: CGPoint(x: q[0], y: q[1])) : p.addLine(to: CGPoint(x: q[0], y: q[1])) }
        }
        return p
    }

    var content: some View {
        ZStack(alignment: .topLeading) {
            Image(uiImage: image).resizable().frame(width: Self.W, height: Self.H)
            ForEach(cells) { c in
                let on = highlight.contains(c.id)
                path(for: c).stroke(on ? Color.orange : Color.tabBlue.opacity(0.55), lineWidth: on ? 4 : 2)
                path(for: c).fill(on ? Color.orange.opacity(0.28) : Color.clear)
            }
        }
        .frame(width: Self.W, height: Self.H)
    }

    var body: some View {
        VStack(spacing: 6) {
            if zoomed {
                ScrollView([.horizontal, .vertical]) { content.scaleEffect(0.8, anchor: .topLeading).frame(width: Self.W * 0.8, height: Self.H * 0.8, alignment: .topLeading) }
                    .frame(height: 360)
            } else {
                content.scaleEffect(fit, anchor: .topLeading)
                    .frame(width: Self.W * fit, height: Self.H * fit, alignment: .topLeading)
                    .clipped()
            }
            Text(zoomed ? "Chạm để thu nhỏ" : "Chạm để phóng to").font(.system(size: 12)).foregroundStyle(.secondary)
        }
        .onTapGesture { withAnimation(.easeInOut(duration: 0.2)) { zoomed.toggle() } }
    }

    var fit: CGFloat { UIScreen.main.bounds.width * 0.84 / Self.W }
}

struct PkgLocationSheet: View {
    @ObservedObject var model: BrowserModel
    let target: PkgLocTarget
    var onSaved: () -> Void

    @Environment(\.dismiss) private var dismiss
    @StateObject private var lvm = PkgLocationVM()
    @State private var dialog: DesmDialogState? = nil
    @State private var working = false
    @State private var msg: String? = nil

    var mapName: String { lvm.maps.first(where: { $0.id == lvm.mapId })?.name ?? lvm.mapId }

    func choose(_ cell: PkgCell) {
        if working { return }
        working = true; msg = nil
        let list = PkgFmt.json(target.params)
        Task { @MainActor in
            let c = await lvm.check(model, list: list, cell: cell)
            working = false
            if let e = c.err { msg = "Kiểm tra vị trí lỗi: " + e; return }
            let dup = c.diff != nil
            let text = (dup ? "Có kiện đang ở vị trí khác — sẽ bị chuyển. " : "") + "Chuyển \(target.names.count) \(target.noun) sang \(mapName) / \(cell.name)?"
            dialog = DesmDialogState(icon: "mappin.and.ellipse", title: dup ? "Kiện đang ở vị trí khác" : "Cập nhật vị trí", message: text, actions: [
                DesmDialogAction(title: "Cập nhật", kind: .primary) { doSave(cell, list) },
                DesmDialogAction(title: "Huỷ", kind: .cancel)
            ])
        }
    }

    func doSave(_ cell: PkgCell, _ list: String) {
        working = true
        Task { @MainActor in
            let r = await lvm.save(model, list: list, cell: cell, count: target.names.count)
            working = false
            switch r {
            case .saved:
                onSaved()
                dismiss()
            case .failed(let m):
                msg = m
            }
        }
    }

    func cellButton(_ c: PkgCell, size: CGFloat) -> some View {
        Button { choose(c) } label: {
            Text(c.name).font(.system(size: size, weight: .bold)).foregroundStyle(Color.tabBlue)
                .lineLimit(1).minimumScaleFactor(0.7)
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 6).padding(.vertical, 11)
                .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.tabBlue.opacity(0.10)))
                .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.tabBlue.opacity(0.35), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .disabled(working)
    }

    /// Một dòng: tên ngắn (Y1-1, C1…) chia 6 cột đều; tên dài (Unloading Bay area…) xếp ngang theo độ dài chữ.
    @ViewBuilder
    func cellRow(_ g: PkgCellGroup) -> some View {
        if g.cells.allSatisfy({ $0.name.count <= 6 }) {
            let cols = Array(repeating: GridItem(.flexible(), spacing: 8), count: 6)
            LazyVGrid(columns: cols, spacing: 8) {
                ForEach(g.cells) { c in cellButton(c, size: 15) }
            }
        } else {
            HStack(spacing: 8) {
                ForEach(g.cells) { c in
                    cellButton(c, size: 15).fixedSize(horizontal: c.name.count > 6, vertical: false)
                        .layoutPriority(c.name.count > 6 ? 1 : 0)
                }
            }
        }
    }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .top) {
                PkgBackground()
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("\(target.names.count) \(target.noun) sẽ được chuyển").font(.system(size: 16, weight: .bold))
                            Text(target.names.prefix(3).joined(separator: ", ") + (target.names.count > 3 ? " … +\(target.names.count - 3)" : ""))
                                .font(.system(size: 14)).foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading).padding(14)
                        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))

                        if let m = msg {
                            Text(m).font(.system(size: 14)).foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading).padding(12)
                                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.red.opacity(0.10)))
                        }
                        if let e = lvm.error {
                            Text(e).font(.system(size: 14)).foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading).padding(12)
                                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.red.opacity(0.10)))
                        }
                        if lvm.loadingMaps { ProgressView("Đang tải bản đồ…").frame(maxWidth: .infinity).padding(.vertical, 20) }

                        if !lvm.maps.isEmpty {
                            Text("BẢN ĐỒ").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary)
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 8) {
                                    ForEach(lvm.maps) { m in
                                        PkgChip(title: m.name, on: lvm.mapId == m.id) { lvm.mapId = m.id; lvm.term = ""; lvm.loadCells(model) }
                                    }
                                }
                            }
                            PkgField(placeholder: "Tìm ô vị trí (vd Y3-1)", text: $lvm.term)
                            Text("CHỌN Ô VỊ TRÍ · \(lvm.filtered.count)").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary)
                            if lvm.loadingCells { ProgressView().frame(maxWidth: .infinity).padding(.vertical, 20) }
                            if !lvm.loadingCells && lvm.filtered.isEmpty {
                                Text("Không có ô vị trí nào.").font(.system(size: 15)).foregroundStyle(.secondary).padding(.vertical, 20)
                            }
                            // Mỗi nhóm một dòng riêng: C1–C3 / ELEC, Unloading / Y1-1…Y1-6 / Y2-… / Y3-…
                            ForEach(PkgCellGroup.make(lvm.filtered)) { g in
                                cellRow(g)
                            }

                            // Ảnh bản đồ của khu vực đang chọn, nằm ngay dưới danh sách ô vị trí
                            if !lvm.maps.isEmpty && !lvm.loadingCells {
                                Text("SƠ ĐỒ · \(mapName.uppercased())").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary).padding(.top, 6)
                                if let img = lvm.mapImage {
                                    PkgMapPreview(image: img, cells: lvm.cells,
                                                  highlight: lvm.term.trimmingCharacters(in: .whitespaces).isEmpty ? [] : Set(lvm.filtered.map { $0.id }))
                                        .padding(8)
                                        .frame(maxWidth: .infinity)
                                        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                                } else if lvm.loadingImage {
                                    ProgressView("Đang tải ảnh bản đồ…").frame(maxWidth: .infinity).padding(.vertical, 24)
                                } else if let e = lvm.imageError {
                                    Text(e).font(.system(size: 14)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading).padding(12)
                                        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                                }
                            }
                        }
                    }
                    .padding(14)
                }
                .pkgKeyboardDismiss()
                if working {
                    ProgressView().padding(18).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16)).padding(.top, 80)
                }
            }
            .navigationTitle("Cập nhật vị trí")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { dismiss() } } }
        }
        .desmDialog(dialog) { dialog = nil }
        .onAppear { lvm.loadMaps(model) }
    }
}
