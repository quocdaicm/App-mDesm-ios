// ScheduleP6.swift — màn "Lịch P6" (Thêm > Lịch P6): lịch thi công Primavera P6 của dự án, đọc từ PDH (cổng 8443).
//
// API (theo schedule.js của trang /newui/schedule.do, người dùng gửi 2026-11-03):
//   /getSchScheduleList.do   PROJECT_ID           -> các bản lịch: SCHEDULE_ID, NO, DATA_DATE, SCHEDULE_TYPE (Baseline/Current), DESCRIPTION
//   /getPdhSchMainList.do    SCHEDULE_ID          -> results = activity/WBS: ID, NAME, START_DATE, FINISH_DATE, DURATION, PERCENT_COMPLETE (0..100),
//                                                    WBS_YN ('Y' = nhóm WBS), ACTIVITY_ID, CRITICAL_PATH ('Y'), WBS_NAME; relation = quan hệ trước/sau (không dùng)
// CHƯA build/chưa thử máy thật: chưa có mẫu phản hồi thật của 2 API này (chỉ có tên trường lấy từ mã nguồn trang).
// Chỉ ĐỌC dữ liệu, không ghi gì lên DESM.

import SwiftUI

// MARK: - Mô hình

struct P6Schedule: Identifiable {
    let id: String            // SCHEDULE_ID
    var no = "", dataDate = "", type = "", desc = ""
    var title: String {
        [type, dataDate.isEmpty ? "" : "Data Date " + dataDate, desc].filter { !$0.isEmpty }.joined(separator: " · ")
    }
    var isCurrent: Bool { type.lowercased().contains("current") }
}

struct P6Task: Identifiable, Sendable {
    let id: String
    var name = "", code = "", wbs = "", startText = "", finishText = "", duration = ""
    var start: Date? = nil, finish: Date? = nil
    var pct = 0.0
    var critical = false

    var isDone: Bool { pct >= 99.95 }
    func isLate(_ now: Date) -> Bool { !isDone && (finish.map { $0 < Calendar.current.startOfDay(for: now) } ?? false) }
    func isRunning(_ now: Date) -> Bool {
        guard !isDone, let s = start, let f = finish else { return false }
        let d = Calendar.current.startOfDay(for: now)
        return s <= d && d <= f
    }
    func startsSoon(_ now: Date, days: Int = 14) -> Bool {
        guard !isDone, let s = start else { return false }
        let d = Calendar.current.startOfDay(for: now)
        guard let end = Calendar.current.date(byAdding: .day, value: days, to: d) else { return false }
        return s > d && s <= end
    }
}

enum P6Filter: String, CaseIterable, Identifiable {
    case all = "Tất cả", running = "Đang chạy", soon = "14 ngày tới", late = "Trễ", critical = "Găng"
    var id: String { rawValue }
}

enum P6Parse {
    /// "2026-10-12" / "2026/10/12" / "12-10-2026" (+ giờ nếu có) -> Date
    static func date(_ raw: String) -> Date? {
        let t = raw.trimmingCharacters(in: .whitespaces)
        guard t.count >= 8 else { return nil }
        func make(_ y: Int, _ m: Int, _ d: Int) -> Date? {
            var c = DateComponents(); c.year = y; c.month = m; c.day = d
            return Calendar.current.date(from: c)
        }
        if let re = try? NSRegularExpression(pattern: #"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})"#),
           let m = re.firstMatch(in: t, range: NSRange(t.startIndex..., in: t)),
           let y = Range(m.range(at: 1), in: t).flatMap({ Int(t[$0]) }),
           let mo = Range(m.range(at: 2), in: t).flatMap({ Int(t[$0]) }),
           let d = Range(m.range(at: 3), in: t).flatMap({ Int(t[$0]) }) { return make(y, mo, d) }
        if let re = try? NSRegularExpression(pattern: #"^(\d{1,2})-(\d{1,2})-(\d{4})"#),
           let m = re.firstMatch(in: t, range: NSRange(t.startIndex..., in: t)),
           let d = Range(m.range(at: 1), in: t).flatMap({ Int(t[$0]) }),
           let mo = Range(m.range(at: 2), in: t).flatMap({ Int(t[$0]) }),
           let y = Range(m.range(at: 3), in: t).flatMap({ Int(t[$0]) }) { return make(y, mo, d) }
        return nil
    }
    private static let shortFmt: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "vi_VN"); f.dateFormat = "dd/MM/yy"; return f
    }()
    static func short(_ d: Date?, fallback: String) -> String { d.map { shortFmt.string(from: $0) } ?? (fallback.isEmpty ? "—" : fallback) }

    static func schedules(_ rows: [[String: Any]]) -> [P6Schedule] {
        rows.compactMap { r in
            let id = ProgBuilder.str(r["SCHEDULE_ID"])
            if id.isEmpty { return nil }
            var s = P6Schedule(id: id)
            s.no = ProgBuilder.str(r["NO"]); s.dataDate = ProgBuilder.str(r["DATA_DATE"])
            s.type = ProgBuilder.str(r["SCHEDULE_TYPE"]); s.desc = ProgBuilder.str(r["DESCRIPTION"])
            return s
        }
    }

    /// Chạy ở luồng nền: phản hồi có thể lớn (hàng nghìn activity).
    static func tasks(_ data: Data) -> [P6Task]? {
        guard let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let list = obj["results"] as? [[String: Any]] else { return nil }
        var out: [P6Task] = []
        out.reserveCapacity(list.count)
        for (i, r) in list.enumerated() {
            if ProgBuilder.str(r["WBS_YN"]) == "Y" { continue }          // chỉ lấy Activity, bỏ dòng nhóm WBS
            var t = P6Task(id: ProgBuilder.str(r["ID"]).isEmpty ? "row\(i)" : ProgBuilder.str(r["ID"]))
            t.name = ProgBuilder.str(r["NAME"])
            t.code = ProgBuilder.str(r["ACTIVITY_ID"])
            t.wbs = ProgBuilder.str(r["WBS_NAME"])
            t.startText = ProgBuilder.str(r["START_DATE"]); t.finishText = ProgBuilder.str(r["FINISH_DATE"])
            t.start = date(t.startText); t.finish = date(t.finishText)
            t.duration = ProgBuilder.str(r["DURATION"])
            t.pct = min(max(ProgBuilder.dbl(r["PERCENT_COMPLETE"]), 0), 100)
            t.critical = ProgBuilder.str(r["CRITICAL_PATH"]) == "Y"
            out.append(t)
        }
        return out
    }
}

// MARK: - ViewModel

@MainActor
final class DesmP6VM: ObservableObject {
    @Published var schedules: [P6Schedule] = []
    @Published var selected: String? = nil
    @Published var tasks: [P6Task] = []
    @Published var loading = false
    @Published var error: String? = nil
    @Published var needsPmsLogin = false
    @Published var filter: P6Filter = .running
    @Published var query = ""
    private var started = false

    var current: P6Schedule? { schedules.first { $0.id == selected } }

    func start(model: BrowserModel) async {
        if started { return }
        started = true
        await loadSchedules(model: model)
    }

    func loadSchedules(model: BrowserModel) async {
        if loading { return }
        loading = true; error = nil; needsPmsLogin = false
        defer { loading = false }
        do {
            let pj = try await model.desmProjectNo()
            let rows = try await model.desmQueryAsync("/getSchScheduleList.do", body: "PROJECT_ID=" + BrowserModel.enc(pj), origin: BrowserModel.pmsOrigin)
            let list = P6Parse.schedules(rows)
            guard !list.isEmpty else { throw DesmAPIError.message("Dự án chưa có bản lịch P6 nào được tải lên.") }
            schedules = list
            // Mặc định: bản "Current" có Data Date mới nhất (nếu không có thì bản đầu tiên)
            let pick = list.filter { $0.isCurrent }.max { $0.dataDate < $1.dataDate } ?? list[0]
            await loadTasks(model: model, id: pick.id, alreadyLoading: true)
        } catch {
            if case DesmAPIError.pmsExpired? = error as? DesmAPIError { needsPmsLogin = true }
            self.error = Self.explain(error, step: "/getSchScheduleList.do")
        }
    }

    func select(_ id: String, model: BrowserModel) async {
        if loading { return }
        loading = true; error = nil; needsPmsLogin = false
        defer { loading = false }
        await loadTasks(model: model, id: id, alreadyLoading: true)
    }

    private func loadTasks(model: BrowserModel, id: String, alreadyLoading: Bool) async {
        do {
            let data = try await model.progressFetch("/getPdhSchMainList.do", body: "SCHEDULE_ID=" + BrowserModel.enc(id))
            let parsed = await Task.detached(priority: .userInitiated) { P6Parse.tasks(data) }.value
            guard let list = parsed else { throw DesmAPIError.message("Không đọc được dữ liệu lịch P6.") }
            tasks = list
            selected = id
        } catch {
            if case DesmAPIError.pmsExpired? = error as? DesmAPIError { needsPmsLogin = true }
            self.error = Self.explain(error, step: "/getPdhSchMainList.do")
        }
    }

    private static func explain(_ error: Error, step: String) -> String {
        let msg = error.localizedDescription
        if msg.hasPrefix("HTTP 404") { return "Máy chủ PDH (cổng 8443) trả HTTP 404 cho \(step)." }
        return msg + " [\(step)]"
    }

    // Số liệu tổng hợp
    var activityCount: Int { tasks.count }
    var doneCount: Int { tasks.filter { $0.isDone }.count }
    var lateCount: Int { tasks.filter { $0.isLate(Date()) }.count }
    var criticalOpen: Int { tasks.filter { $0.critical && !$0.isDone }.count }
    var avgPct: Double { tasks.isEmpty ? 0 : tasks.reduce(0) { $0 + $1.pct } / Double(tasks.count) }

    var shown: [P6Task] {
        let now = Date()
        var list = tasks
        switch filter {
        case .all: break
        case .running: list = list.filter { $0.isRunning(now) }
        case .soon: list = list.filter { $0.startsSoon(now) }
        case .late: list = list.filter { $0.isLate(now) }
        case .critical: list = list.filter { $0.critical && !$0.isDone }
        }
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        if !q.isEmpty { list = list.filter { $0.name.lowercased().contains(q) || $0.code.lowercased().contains(q) || $0.wbs.lowercased().contains(q) } }
        // Sắp theo ngày kết thúc gần nhất trước (không có ngày thì xuống cuối)
        return list.sorted { a, b in
            switch (a.finish, b.finish) {
            case let (x?, y?): return x < y
            case (_?, nil): return true
            default: return false
            }
        }
    }
}

// MARK: - Giao diện

struct DesmP6Sheet: View {
    @ObservedObject var model: BrowserModel
    var onClose: () -> Void
    @StateObject private var vm = DesmP6VM()
    @ObservedObject private var tr = NativeTranslator.shared

    func stat(_ title: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 2) {
            Text(value).font(.system(size: 20, weight: .bold, design: .rounded)).foregroundColor(color).minimumScaleFactor(0.6).lineLimit(1)
            Text(title).font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
    }

    var scheduleMenu: some View {
        Menu {
            ForEach(vm.schedules) { s in
                Button { Task { await vm.select(s.id, model: model) } } label: { Text(s.title.isEmpty ? s.id : s.title) }
            }
        } label: {
            HStack(spacing: 6) {
                Text(vm.current?.title ?? "Chọn bản lịch").font(.system(size: 13, weight: .semibold)).lineLimit(1)
                Image(systemName: "chevron.up.chevron.down").font(.system(size: 10, weight: .bold))
            }
            .foregroundColor(Color.tabBlue)
            .padding(.horizontal, 12).padding(.vertical, 8)
            .background(Capsule().fill(Color.tabBlue.opacity(0.12)))
        }
    }

    func row(_ t: P6Task) -> some View {
        let now = Date()
        let late = t.isLate(now)
        return VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(t.code.isEmpty ? t.id : t.code).font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary)
                if t.critical {
                    Text("Găng").font(.system(size: 10, weight: .bold)).foregroundColor(.progRed)
                        .padding(.horizontal, 6).padding(.vertical, 2).background(Capsule().fill(Color.progRed.opacity(0.14)))
                }
                if late {
                    Text("Trễ").font(.system(size: 10, weight: .bold)).foregroundColor(.progAmber)
                        .padding(.horizontal, 6).padding(.vertical, 2).background(Capsule().fill(Color.progAmber.opacity(0.18)))
                }
                Spacer()
                Text(ProgFmt.pct(t.pct, 1)).font(.system(size: 13, weight: .bold)).foregroundColor(t.isDone ? .progGreen : Color.tabBlue)
            }
            Text(tr.t(t.name)).font(.system(size: 15, weight: .semibold)).lineLimit(3)
            if !t.wbs.isEmpty { Text(tr.t(t.wbs)).font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(1) }
            ProgressView(value: t.pct, total: 100).tint(t.isDone ? .progGreen : Color.tabBlue)
            HStack {
                Text(P6Parse.short(t.start, fallback: t.startText) + " → " + P6Parse.short(t.finish, fallback: t.finishText))
                    .font(.system(size: 12, weight: .medium))
                Spacer()
                if !t.duration.isEmpty { Text(t.duration + " ngày").font(.system(size: 12)).foregroundStyle(.secondary) }
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 10) {
                    if let e = vm.error {
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.progRed)
                            Text(e).font(.system(size: 13)).foregroundColor(.progRed).frame(maxWidth: .infinity, alignment: .leading)
                            VStack(alignment: .trailing, spacing: 6) {
                                Button("Thử lại") { Task { await vm.loadSchedules(model: model) } }.font(.system(size: 13, weight: .semibold))
                                if vm.needsPmsLogin {
                                    Button("Đăng nhập PDH") { onClose(); model.openPmsLogin() }.font(.system(size: 13, weight: .semibold))
                                }
                            }
                        }
                        .padding(12)
                        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.progRed.opacity(0.10)))
                    } else if vm.loading {
                        HStack(spacing: 10) {
                            ProgressView()
                            Text("Đang tải lịch P6…").font(.system(size: 13, weight: .medium)).foregroundStyle(.secondary)
                            Spacer()
                        }
                        .padding(12)
                        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                    }
                    NativeTranslateNote()
                    if !vm.schedules.isEmpty {
                        HStack { scheduleMenu; Spacer() }
                    }
                    if !vm.tasks.isEmpty {
                        HStack(spacing: 8) {
                            stat("Activity", "\(vm.activityCount)", Color.tabBlue)
                            stat("Hoàn thành", "\(vm.doneCount)", .progGreen)
                            stat("Trễ", "\(vm.lateCount)", .progAmber)
                            stat("Găng còn lại", "\(vm.criticalOpen)", .progRed)
                        }
                        Picker("Lọc", selection: $vm.filter) {
                            ForEach(P6Filter.allCases) { Text($0.rawValue).tag($0) }
                        }
                        .pickerStyle(.segmented)
                        TextField("Tìm theo tên, mã activity hoặc WBS", text: $vm.query)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                            .padding(.horizontal, 12).padding(.vertical, 9)
                            .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                        let list = vm.shown
                        Text("\(list.count) / \(vm.activityCount) activity" + (list.count > 200 ? " (hiện 200 đầu)" : ""))
                            .font(.system(size: 12)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                        ForEach(list.prefix(200)) { t in row(t) }
                        if list.isEmpty {
                            Text("Không có activity nào khớp bộ lọc.").font(.footnote).foregroundStyle(.secondary).padding(20)
                        }
                    }
                    Text("Nguồn: PDH P6 Data Base (lịch Primavera P6 tải lên). Chỉ xem, không ghi lên DESM. Kéo xuống để làm mới.")
                        .font(.system(size: 11)).foregroundStyle(.tertiary).frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 4)
                }
                .padding(.horizontal, 14).padding(.top, 8).padding(.bottom, 30)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Lịch P6")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { onClose() } }
                ToolbarItem(placement: .navigationBarTrailing) {
                    NativeTranslateButton(signature: vm.shown.count) {
                        Array(vm.shown.prefix(60)).flatMap { [$0.name, $0.wbs] }
                    }
                }
            }
            .refreshable { await vm.loadSchedules(model: model) }
            .task { await vm.start(model: model) }
        }
    }
}
