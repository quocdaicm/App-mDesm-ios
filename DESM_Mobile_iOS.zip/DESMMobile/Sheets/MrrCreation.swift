// MrrCreation.swift — màn "Nhập kho (MRR)": danh sách MRR + popup "MRR Creation" làm native.

import SwiftUI

// MARK: - Nhập kho (MRR) — danh sách MRR và popup "MRR Creation"
//
// Làm theo màn Material Receiving (MENU_SEQ=816) và popup desmMrrCreationPopUp.do của web (log API 2026-11-05):
//   Danh sách:  POST /getDesmMrrList.do  (STATUS, MRR_NO, MRR_NAME, PROJECT_NO, INVOICE_NO, PACKAGE_NO, RECEIVED_DATE_FROM/TO,
//               INSPECTION_DATE_FROM/TO, SHIPMENT_NO) -> results[] (MRR_HEADER_ID, MRR_NO, MRR_NAME, STATUS, INVOICE_NO, ngày, PREPARED_BY_NAME...)
//   Mở phiếu:   POST /getDesmMrrInfoList.do  (MRR_HEADER_ID) -> results.{headerList, lineList}   (results là OBJECT, không phải mảng)
//   Lưu:        POST /saveDesmMrrSave.do  — cùng cách `mrrEditor` (JS, Scripts/JSGenericCards.swift) đang dùng:
//               các trường đầu phiếu + TRANS_TYPE='Incomplete' + updateList (JSON các dòng). Lỗi = phản hồi có `error`.
//   Danh sách kiện để "Add": POST /getIdsmOsSummaryList.do với MRR_RECEIVED=N (cùng API màn Kiện hàng).
//
// ĐÃ CÓ trong log: danh sách, mở phiếu, cấu trúc form. CHƯA có trong log (đoán theo mrrEditor, chưa thử trên DESM thật):
//   - lệnh LƯU phiếu MỚI (MRR_HEADER_ID/MRR_NO/MRR_LINE_ID để trống, ATTACH_GRP_CD tự sinh UUID, VISUAL_CHECK_DATE = ngày nhận);
//   - ý nghĩa MRR_RECEIVED=N của getIdsmOsSummaryList.
// Phiếu CŨ chỉ sửa được dòng (Received Date / Visual Check) khi STATUS = Incomplete/Rejected, giống mrrEditor; đầu phiếu để xem.
// Chưa làm: Attachment, Location Update, Report, Request/Check/Confirm/Reject (web ẩn/hiện theo trạng thái, chưa có script nút).
// Mọi lệnh ghi đều vào "Nhật ký thao tác ghi" (desmWriteForm).

// MARK: Dữ liệu

enum DesmMrrFmt {
    static let day: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy/MM/dd"; return f
    }()
    static func text(_ d: Date?) -> String { d.map { day.string(from: $0) } ?? "" }
    static func date(_ s: String) -> Date? {
        let t = s.trimmingCharacters(in: .whitespaces)
        return t.count >= 10 ? day.date(from: String(t.prefix(10))) : nil
    }
    /// Như mrrFmt của JS: yyyy/MM/dd | yyyy-MM-dd | mili-giây epoch -> yyyy/MM/dd ('' nếu không đọc được).
    static func norm(_ raw: String) -> String {
        let s = raw.trimmingCharacters(in: .whitespaces)
        if s.isEmpty { return "" }
        if s.count >= 10, let d = day.date(from: String(s.prefix(10)).replacingOccurrences(of: "-", with: "/")) { return day.string(from: d) }
        if s.count >= 10, s.allSatisfy({ $0.isNumber }), let ms = Double(s) { return day.string(from: Date(timeIntervalSince1970: ms / 1000)) }
        return ""
    }
    static func num(_ s: String) -> Int { Int(s.replacingOccurrences(of: "/", with: "")) ?? 0 }
    static let shortDay: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yy/MM/dd"; return f
    }()
    /// Ngày từ máy chủ (chuỗi) -> yyyy/MM/dd để hiển thị; không đọc được thì cắt 10 ký tự đầu.
    static func show(_ raw: String) -> String {
        let n = norm(raw)
        return n.isEmpty ? String(raw.trimmingCharacters(in: .whitespaces).prefix(10)) : n
    }
    /// yyyy/MM/dd -> yy/MM/dd (cho dòng Recv/Insp ở đầu màn chi tiết).
    static func short(_ raw: String) -> String {
        let n = norm(raw)
        if let d = day.date(from: n) { return shortDay.string(from: d) }
        return raw
    }
}

struct DesmMrrHead: Identifiable {
    let id: String                       // MRR_HEADER_ID
    var no = "", name = "", status = "", invoice = ""
    var recFrom = "", recTo = "", insFrom = "", insTo = ""
    var preparedBy = "", confirmedBy = "", confirmedDate = "", remark = ""
}

struct DesmMrrLineRow: Identifiable {
    let id: String
    var lineId = ""                      // MRR_LINE_ID; rỗng = dòng mới (chưa lưu)
    var invoice = "", shipment = "", pkg = "", desc = "", type = "", location = "", trk = ""
    var received = "", visual = "Good", visualDate = "", remarks = "", attachGrp = "", filePath = "", qty = "1"
    var attCnt = 0
    var material = ""                    // MATERIAL_CODE (cần cho /deleteDesmMrrDtl.do), có thể rỗng
    var remarkEdited = false
    var dtl = ""                         // "Detail item lines" (số dòng hạng mục của kiện) — tên trường CHƯA kiểm chứng, rỗng = ẩn
    var changed = false
    var orig: (received: String, visual: String)? = nil
    var isNew: Bool { lineId.isEmpty }
}

struct DesmMrrForm {
    var headerId = ""                    // rỗng = phiếu mới
    var no = "", name = "", status = "Incomplete", remark = "", attachGrp = ""
    var recFrom: Date? = nil, recTo: Date? = nil, insFrom: Date? = nil, insTo: Date? = nil
    var preparedBy = "", preparedByName = "", preparedDate = ""
    var checkedBy = "", confirmedBy = "", confirmedByName = "", confirmedDate = ""
    var lines: [DesmMrrLineRow] = []
    var isNew: Bool { headerId.isEmpty }
    /// Giống mrrEditor: phiếu cũ chỉ sửa khi Incomplete/Rejected.
    var canEdit: Bool { isNew || status == "Incomplete" || status == "Rejected" }
    /// Nút theo trạng thái như popup web: Incomplete/Rejected = Save+Request+Delete; Pre-Confirmed = Confirm+Reject; Confirmed = Temp Save (Inspection Date + Remarks).
    var canRequest: Bool { !isNew && (status == "Incomplete" || status == "Rejected") }
    var canConfirm: Bool { !isNew && status == "Pre-Confirmed" }
    var canTemp: Bool { !isNew && status == "Confirmed" }
    var canRemark: Bool { !isNew && (canRequest || canConfirm || canTemp) }
}

// MARK: - ViewModel

@MainActor
final class DesmMrrVM: ObservableObject {
    // Bộ lọc danh sách
    @Published var status = ""
    @Published var mrrNo = ""
    @Published var mrrName = ""
    @Published var invoice = ""
    @Published var pkg = ""
    @Published var shipment = ""
    @Published var heads: [DesmMrrHead] = []
    @Published var loading = false
    @Published var searched = false
    @Published var error: String? = nil
    @Published var showFilter = true
    // Mặc định như web/ảnh: Received Date = 7 ngày gần nhất, Inspection Date để trống
    @Published var recFrom: Date? = Calendar.current.date(byAdding: .day, value: -7, to: Date())
    @Published var recTo: Date? = Date()
    @Published var insFrom: Date? = nil
    @Published var insTo: Date? = nil

    // Form
    @Published var form = DesmMrrForm()
    @Published var formLoading = false
    @Published var saving = false
    @Published var formError: String? = nil
    @Published var formNotice: String? = nil
    @Published var savedNew = false          // phiếu mới đã gửi xong → màn đóng form về danh sách
    @Published var selected = Set<String>()
    @Published var shareItem: ShareItem? = nil     // file đính kèm vừa tải -> mở bảng chia sẻ/lưu
    @Published var attBusy = false
    @Published var setDate = Date()
    @Published var setVisual = "Good"
    var project = ""

    static let statuses = ["", "Incomplete", "Pre-Confirmed", "Confirmed", "Rejected"]

    func reset() {
        status = ""; mrrNo = ""; mrrName = ""; invoice = ""; pkg = ""; shipment = ""
        recFrom = Calendar.current.date(byAdding: .day, value: -7, to: Date()); recTo = Date()
        insFrom = nil; insTo = nil
    }

    // MARK: Danh sách

    func search(_ model: BrowserModel) {
        if loading { return }
        loading = true; error = nil
        Task { @MainActor [self] in
            do {
                let pj = try await model.desmProjectNo()
                project = pj
                let e = BrowserModel.enc
                let t: (String) -> String = { $0.trimmingCharacters(in: .whitespaces) }
                var body = "STATUS=\(e(status))&MRR_NO=\(e(t(mrrNo)))&MRR_NAME=\(e(t(mrrName)))&PROJECT_NO=\(e(pj))"
                body += "&INVOICE_NO=\(e(t(invoice)))&PACKAGE_NO=\(e(t(pkg)))&RECEIVED_DATE_FROM=\(e(DesmMrrFmt.text(recFrom)))&RECEIVED_DATE_TO=\(e(DesmMrrFmt.text(recTo)))"
                body += "&INSPECTION_DATE_FROM=\(e(DesmMrrFmt.text(insFrom)))&INSPECTION_DATE_TO=\(e(DesmMrrFmt.text(insTo)))&SHIPMENT_NO=\(e(t(shipment)))"
                let rows = try await model.desmQueryAsync("/getDesmMrrList.do", body: body)
                var out: [DesmMrrHead] = []
                for r in rows {
                    let f = BrowserModel.fstr
                    var h = DesmMrrHead(id: f(r, "MRR_HEADER_ID"))
                    h.no = f(r, "MRR_NO"); h.name = f(r, "MRR_NAME"); h.status = f(r, "STATUS"); h.invoice = f(r, "INVOICE_NO")
                    h.recFrom = f(r, "RECEIVED_DATE_FROM"); h.recTo = f(r, "RECEIVED_DATE_TO")
                    h.insFrom = f(r, "INSPECTION_DATE_FROM"); h.insTo = f(r, "INSPECTION_DATE_TO")
                    h.preparedBy = f(r, "PREPARED_BY").isEmpty ? f(r, "PREPARED_BY_NAME") : f(r, "PREPARED_BY")
                    h.confirmedBy = f(r, "CONFIRMED_BY").isEmpty ? f(r, "CONFIRMED_BY_NAME") : f(r, "CONFIRMED_BY")
                    h.confirmedDate = f(r, "CONFIRMED_DATE"); h.remark = f(r, "REMARK")
                    if h.id.isEmpty { continue }
                    out.append(h)
                }
                heads = out   // máy chủ đã sắp mới nhất trước
            } catch let err {
                error = err.localizedDescription
            }
            loading = false; searched = true
        }
    }

    // MARK: Mở phiếu cũ

    func open(_ model: BrowserModel, headerId: String) {
        form = DesmMrrForm(); selected = []; formError = nil; formNotice = nil
        form.headerId = headerId
        formLoading = true
        Task { @MainActor [self] in await loadInfo(model, headerId: headerId); formLoading = false }
    }

    func loadInfo(_ model: BrowserModel, headerId: String) async {
        do {
            let obj = try await model.desmPostObject("/getDesmMrrInfoList.do", body: "MRR_HEADER_ID=\(BrowserModel.enc(headerId))")
            guard let res = obj["results"] as? [String: Any],
                  let hl = (res["headerList"] as? [[String: Any]])?.first,
                  let ll = res["lineList"] as? [[String: Any]] else { formError = "Không tải được MRR (phản hồi không đúng dạng)."; return }
            let f = BrowserModel.fstr
            var m = DesmMrrForm()
            m.headerId = headerId
            m.no = f(hl, "MRR_NO"); m.name = f(hl, "MRR_NAME"); m.status = f(hl, "STATUS"); m.remark = f(hl, "REMARK")
            m.attachGrp = f(hl, "ATTACH_GRP_CD")
            m.recFrom = DesmMrrFmt.date(f(hl, "RECEIVED_DATE_FROM")); m.recTo = DesmMrrFmt.date(f(hl, "RECEIVED_DATE_TO"))
            m.insFrom = DesmMrrFmt.date(f(hl, "INSPECTION_DATE_FROM")); m.insTo = DesmMrrFmt.date(f(hl, "INSPECTION_DATE_TO"))
            m.preparedBy = f(hl, "PREPARED_BY"); m.preparedByName = f(hl, "PREPARED_BY_NAME"); m.preparedDate = String(f(hl, "PREPARED_DATE").prefix(10))
            m.checkedBy = f(hl, "CHECKED_BY")
            m.confirmedBy = f(hl, "CONFIRMED_BY"); m.confirmedByName = f(hl, "CONFIRMED_BY_NAME"); m.confirmedDate = String(f(hl, "CONFIRMED_DATE").prefix(10))
            var lines: [DesmMrrLineRow] = []
            for (i, r) in ll.enumerated() {
                var l = DesmMrrLineRow(id: f(r, "MRR_LINE_ID").isEmpty ? "n\(i)" : f(r, "MRR_LINE_ID"))
                l.lineId = f(r, "MRR_LINE_ID")
                l.invoice = f(r, "SEL_INVOICE_NUM").isEmpty ? f(r, "PACKAGE_LIST_NO") : f(r, "SEL_INVOICE_NUM")
                l.shipment = f(r, "ATTRIBUTE10"); l.pkg = f(r, "PACKAGE_NO"); l.desc = f(r, "DESCRIPTION"); l.type = f(r, "PACKAGE_TYPE")
                l.location = f(r, "STORAGE_LOCATION"); l.trk = f(r, "TRK_ITEM_NAME")
                l.received = DesmMrrFmt.norm(f(r, "RECEIVED_DATE")); l.visual = f(r, "VISUAL_CHECK").isEmpty ? "Good" : f(r, "VISUAL_CHECK")
                l.visualDate = DesmMrrFmt.norm(f(r, "VISUAL_CHECK_DATE")); l.remarks = f(r, "REMARKS")
                l.attachGrp = f(r, "ATTACH_GRP_CD"); l.filePath = f(r, "FILE_PATH"); l.qty = f(r, "QTY").isEmpty ? "1" : f(r, "QTY")
                l.attCnt = Int(f(r, "ATTH_CNT")) ?? 0
                l.material = f(r, "MATERIAL_CODE")
                l.dtl = ["DETAIL_CNT", "DTL_CNT", "DETAIL_ITEM_CNT", "DETAIL_ITEM_LINES", "DETAIL_LINE_CNT", "ITEM_CNT"]
                    .map { f(r, $0) }.first(where: { !$0.isEmpty }) ?? ""
                lines.append(l)
            }
            m.lines = lines
            form = m
            loadDetailCounts(model, headerId: headerId)
        } catch let err {
            formError = "Không tải được MRR: " + err.localizedDescription
        }
    }

    // MARK: "Detail item lines" = số hạng mục chi tiết của kiện (đếm bằng /getIdsmOsDetailList.do, lần lượt từng kiện)

    func loadDetailCounts(_ model: BrowserModel, headerId: String) {
        let todo = form.lines.filter { $0.dtl.isEmpty && !$0.pkg.isEmpty }.map { ($0.id, $0.pkg) }
        if todo.isEmpty { return }
        Task { @MainActor [self] in
            if project.isEmpty { project = (try? await model.desmProjectNo()) ?? "" }
            if project.isEmpty { return }
            let e = BrowserModel.enc
            for (id, pkg) in todo {
                if form.headerId != headerId { return }          // đã chuyển sang phiếu khác
                var body: String = "PAGE_NUM=1&PAGE_CNT=5000&PROJECT_NO=" + e(project) + "&PACKAGE_LIST_NO=&PACKAGE_NO=" + e(pkg)
                body += "&DESCRIPTION=&DRAWING_NO=&TAG_NO=&QTY_TYPE=rsi&QTY=&KEY1=&VALUE1=&LOCATION=&SEQUENCE="
                body += "&VENDOR=&ATTRIBUTE10=&TYPE=&CATEGORY=&SUB_CATEGORY=&COMMENTS="
                guard let rows = try? await model.desmQueryAsync("/getIdsmOsDetailList.do", body: body) else { continue }
                let want = pkg.uppercased()
                let n = rows.filter { r in
                    let v = BrowserModel.fstr(r, "PACKAGE_NO")
                    return v.isEmpty || v.uppercased() == want
                }.count
                if form.headerId != headerId { return }
                if let k = form.lines.firstIndex(where: { $0.id == id }) { form.lines[k].dtl = String(n) }
            }
        }
    }

    // MARK: File đính kèm — theo Site.js của web: đếm `/getAttachCountByGrpCd.do` (FILE_GRP_CD) rồi tải cả nhóm (zip)
    // `/attach/getAttachMultipleDownload.do?code=<nhóm>`. Danh sách từng file (popup desmAttListPopUp) chưa có script nên chưa liệt kê riêng.

    func showAttachments(_ model: BrowserModel, group: String, title: String) {
        if attBusy { return }
        let g = group.trimmingCharacters(in: .whitespaces)
        formError = nil
        if g.isEmpty { formNotice = title + ": không có file đính kèm."; return }
        attBusy = true; formNotice = title + ": đang kiểm tra file đính kèm…"
        Task { @MainActor [self] in
            defer { attBusy = false }
            do {
                let obj = try await model.desmPostObject("/getAttachCountByGrpCd.do", body: "FILE_GRP_CD=\(BrowserModel.enc(g))")
                var cnt = 0
                if let res = obj["results"] as? [String: Any], let c = res["CNT"] { cnt = Int("\(c)") ?? 0 }
                if cnt <= 0 { formNotice = title + ": không có file đính kèm."; return }
                formNotice = title + ": \(cnt) file — đang tải…"
                let url = try await model.desmDownload("/attach/getAttachMultipleDownload.do?code=" + BrowserModel.enc(g), fallbackName: "MRR-attachments.zip")
                formNotice = title + ": \(cnt) file đã tải — chọn nơi lưu hoặc mở."
                shareItem = ShareItem(url: url)
            } catch let err {
                formNotice = nil
                formError = "Không tải được file đính kèm: " + err.localizedDescription
            }
        }
    }

    // MARK: Gửi mail, Reject, Delete, Temp Save (theo desmMrrCreationPopUp.js)

    /// `/sendMailDesmMrr.do` — nil = ổn; chuỗi = cảnh báo (mail lỗi nhưng thao tác chính đã xong).
    func sendMail(_ model: BrowserModel, headerId: String, status: String) async -> String? {
        let body = "MRR_HEADER_ID=\(BrowserModel.enc(headerId))&STATUS=\(BrowserModel.enc(status))"
        let r = await model.desmWriteForm("/sendMailDesmMrr.do", body: body, label: "MRR gửi mail (\(status))", payload: body)
        if !r.ok { return "gửi mail thất bại: " + r.err }
        if let c = r.obj["error_code"], "\(c)" == "-2" { return "máy chủ báo gửi mail lỗi" }
        return nil
    }

    /// Pre-Confirmed -> Rejected: `/saveDesmMrrReject.do {MRR_HEADER_ID, REMARK}` rồi gửi mail (STATUS = trạng thái đang mở, như web).
    func reject(_ model: BrowserModel) {
        if saving || form.isNew { return }
        let f = form
        formError = nil; formNotice = nil; saving = true
        Task { @MainActor [self] in
            let body = "MRR_HEADER_ID=\(BrowserModel.enc(f.headerId))&REMARK=\(BrowserModel.enc(f.remark))"
            let r = await model.desmWriteForm("/saveDesmMrrReject.do", body: body, label: "MRR " + f.no + " — Reject", payload: body)
            if r.ok {
                let w = await sendMail(model, headerId: f.headerId, status: f.status)
                var msg: String = "Đã Reject ✓"
                if let w = w { msg += " — " + w }
                formNotice = msg
                await loadInfo(model, headerId: f.headerId); selected = []
                search(model)
            } else { formError = "Reject thất bại: " + r.err }
            saving = false
        }
    }

    /// Xoá cả phiếu (Incomplete/Rejected): `/deleteDesmMrr.do {MRR_HEADER_ID}`.
    func deleteMrr(_ model: BrowserModel) {
        if saving || form.isNew { return }
        let f = form
        formError = nil; formNotice = nil; saving = true
        Task { @MainActor [self] in
            let body = "MRR_HEADER_ID=\(BrowserModel.enc(f.headerId))"
            let r = await model.desmWriteForm("/deleteDesmMrr.do", body: body, label: "MRR " + f.no + " — Delete", payload: body)
            saving = false
            if r.ok { form = DesmMrrForm(); selected = []; savedNew = true; search(model) }
            else { formError = "Xoá thất bại: " + r.err }
        }
    }

    /// Xoá các dòng đã chọn của phiếu đã lưu: `/deleteDesmMrrDtl.do {deleteList: [{MRR_LINE_ID, MATERIAL_CODE}]}`.
    func deleteSavedLines(_ model: BrowserModel) {
        if saving || form.isNew { return }
        let f = form
        let rows = f.lines.filter { selected.contains($0.id) && !$0.lineId.isEmpty }
        if rows.isEmpty { formError = "Chưa chọn dòng nào."; return }
        let list: [[String: String]] = rows.map { ["MRR_LINE_ID": $0.lineId, "MATERIAL_CODE": $0.material] }
        guard let d = try? JSONSerialization.data(withJSONObject: list), let text = String(data: d, encoding: .utf8) else { return }
        formError = nil; formNotice = nil; saving = true
        Task { @MainActor [self] in
            let body = "deleteList=\(BrowserModel.enc(text))"
            let r = await model.desmWriteForm("/deleteDesmMrrDtl.do", body: body, label: "MRR " + f.no + " — xoá \(rows.count) dòng", payload: text)
            if r.ok {
                formNotice = "Đã xoá \(rows.count) dòng ✓"
                await loadInfo(model, headerId: f.headerId); selected = []
                search(model)
            } else { formError = "Xoá dòng thất bại: " + r.err }
            saving = false
        }
    }

    /// Confirmed: sửa Inspection Date + Remarks dòng — `/material/saveMrrHeaderTempInfo.do`.
    func tempSave(_ model: BrowserModel) {
        if saving || form.isNew { return }
        let f = form
        if let a = f.insFrom, let b = f.insTo, DesmMrrFmt.text(a) > DesmMrrFmt.text(b) { formError = "Inspection Date From lớn hơn To."; return }
        let list: [[String: String]] = f.lines.filter { $0.remarkEdited }.map { ["MRR_LINE_ID": $0.lineId, "REMARKS": $0.remarks] }
        guard let d = try? JSONSerialization.data(withJSONObject: list), let text = String(data: d, encoding: .utf8) else { return }
        formError = nil; formNotice = nil; saving = true
        Task { @MainActor [self] in
            let e = BrowserModel.enc
            let body = "MRR_HEADER_ID=\(e(f.headerId))&INSPECTION_DATE_FROM=\(e(DesmMrrFmt.text(f.insFrom)))&INSPECTION_DATE_TO=\(e(DesmMrrFmt.text(f.insTo)))&updateList=\(e(text))"
            let r = await model.desmWriteForm("/material/saveMrrHeaderTempInfo.do", body: body, label: "MRR " + f.no + " — Temp Save", payload: body)
            if r.ok {
                formNotice = "Đã lưu ✓"
                await loadInfo(model, headerId: f.headerId); selected = []
                search(model)
            } else { formError = "Lưu thất bại: " + r.err }
            saving = false
        }
    }

    func setRemark(_ id: String, _ v: String) {
        guard let k = form.lines.firstIndex(where: { $0.id == id }) else { return }
        form.lines[k].remarks = v; form.lines[k].remarkEdited = true; form.lines[k].changed = true
    }

    // MARK: Phiếu mới

    func startNew(_ model: BrowserModel) {
        form = DesmMrrForm(); selected = []; formError = nil; formNotice = nil
        form.attachGrp = UUID().uuidString.lowercased()
        form.recFrom = Date(); form.recTo = Date()
        form.preparedDate = DesmMrrFmt.text(Date())
        Task { @MainActor [self] in
            // Prepared by mặc định = tài khoản đang đăng nhập (getCodeCombo.USER, như log)
            let paramList = "[{\"CODE\":\"M004\"}]"
            if let obj = try? await model.desmPostObject("/getCodeCombo.do", body: "paramList=\(BrowserModel.enc(paramList))"),
               let res = obj["results"] as? [String: Any], let u = (res["USER"] as? [[String: Any]])?.first {
                let ad = BrowserModel.fstr(u, "USER_AD")
                if form.isNew && form.preparedBy.isEmpty { form.preparedBy = ad; form.preparedByName = BrowserModel.fstr(u, "USER_NAME") }
            }
            if let pj = try? await model.desmProjectNo() { project = pj }
        }
    }

    // MARK: Chọn / sửa dòng

    var lineAllOn: Bool { !form.lines.isEmpty && selected.count == form.lines.count }
    func toggleAll() { selected = lineAllOn ? [] : Set(form.lines.map { $0.id }) }

    private func mark(_ i: Int) {
        if form.lines[i].orig == nil { form.lines[i].orig = (form.lines[i].received, form.lines[i].visual) }
        form.lines[i].changed = true
    }
    func applyReceived() {
        guard !selected.isEmpty else { formError = "Chưa chọn dòng nào."; return }
        let v = DesmMrrFmt.text(setDate)
        for i in form.lines.indices where selected.contains(form.lines[i].id) { mark(i); form.lines[i].received = v }
        formError = nil; formNotice = "Đã đặt Received Date \(v) cho \(selected.count) dòng (chưa lưu)."
    }
    func applyVisual() {
        guard !selected.isEmpty else { formError = "Chưa chọn dòng nào."; return }
        for i in form.lines.indices where selected.contains(form.lines[i].id) {
            mark(i); form.lines[i].visual = setVisual
            if form.lines[i].visualDate.isEmpty { form.lines[i].visualDate = DesmMrrFmt.text(Date()) }
        }
        formError = nil; formNotice = "Đã đặt Visual Check \(setVisual) cho \(selected.count) dòng (chưa lưu)."
    }
    /// Chỉ cho phiếu MỚI (dòng chưa lưu): bỏ các dòng đã chọn.
    func removeSelected() {
        guard form.isNew else { return }
        form.lines.removeAll { selected.contains($0.id) }
        selected = []; formNotice = nil
    }
    func add(_ rows: [PkgRow]) {
        let have = Set(form.lines.map { $0.pkg.uppercased() })
        let today = DesmMrrFmt.text(Date())
        let recv = DesmMrrFmt.text(form.recFrom ?? Date())
        var n = 0
        for r in rows where !have.contains(r.no.uppercased()) {
            var l = DesmMrrLineRow(id: "new-" + UUID().uuidString)
            l.invoice = r.plNo; l.shipment = r.s("ATTRIBUTE10"); l.pkg = r.no; l.desc = r.desc; l.type = r.s("PACKAGE_TYPE")
            l.location = r.loc; l.trk = r.trk
            l.received = recv; l.visual = "Good"; l.visualDate = today
            l.attachGrp = UUID().uuidString.lowercased()
            l.changed = true
            form.lines.append(l); n += 1
        }
        form.lines = desmSortedByPkg(form.lines, pkg: { $0.pkg }, code: { _ in "" })
        formNotice = n == 0 ? "Các kiện đó đã có trong phiếu." : "Đã thêm \(n) kiện (chưa lưu)."
        formError = nil
    }

    // MARK: Kiểm tra + Lưu

    /// Trả thông báo lỗi nếu chưa hợp lệ; nil = được lưu.
    func validate(trans: String = "Incomplete") -> String? {
        let f = form
        if f.isNew {
            if f.name.trimmingCharacters(in: .whitespaces).isEmpty { return "Chưa nhập MRR Name." }
            if f.preparedBy.trimmingCharacters(in: .whitespaces).isEmpty { return "Chưa nhập Prepared by." }
            if f.lines.isEmpty { return "Chưa có kiện nào. Bấm Add để thêm kiện." }
        } else if trans == "Incomplete" && !f.lines.contains(where: { $0.changed }) { return "Chưa có thay đổi nào để lưu." }
        if trans == "Pre-Confirmed", let l = f.lines.first(where: { $0.received.isEmpty }) { return "Dòng \(l.pkg) chưa có Received Date (bắt buộc khi Request)." }
        guard let a = f.recFrom, let b = f.recTo else { return "Chưa có khoảng Received Date (From/To)." }
        if DesmMrrFmt.text(a) > DesmMrrFmt.text(b) { return "Received Date From lớn hơn To." }
        if let c = f.insFrom, let d = f.insTo, DesmMrrFmt.text(c) > DesmMrrFmt.text(d) { return "Inspection Date From lớn hơn To." }
        let s = DesmMrrFmt.num(DesmMrrFmt.text(a)), e = DesmMrrFmt.num(DesmMrrFmt.text(b))
        for l in f.lines where !l.received.isEmpty {
            let n = DesmMrrFmt.num(l.received)
            if n < s || n > e { return "Received Date nằm ngoài khoảng \(DesmMrrFmt.text(a)) ~ \(DesmMrrFmt.text(b)) [Package No: \(l.pkg)]" }
        }
        if f.isNew, let l = f.lines.first(where: { $0.received.isEmpty }) { return "Dòng \(l.pkg) chưa có Received Date." }
        return nil
    }

    var saveCount: Int { form.isNew ? form.lines.count : form.lines.filter { $0.changed }.count }

    func save(_ model: BrowserModel, trans: String = "Incomplete") {
        if saving { return }
        if let e = validate(trans: trans) { formError = e; return }
        formError = nil; formNotice = nil
        let f = form
        let list: [[String: Any]] = (f.isNew ? f.lines : f.lines.filter { $0.changed }).map { (l: DesmMrrLineRow) -> [String: Any] in
            return [
                "MRR_LINE_ID": l.lineId, "TRK_ITEM_NAME": l.trk, "PACKING_LIST_NO": l.invoice, "PACKAGE_NO": l.pkg,
                "DESCRIPTION": l.desc, "SHIPMENT_NO": l.shipment, "PACKAGE_TYPE": l.type, "VISUAL_CHECK": l.visual,
                "VISUAL_CHECK_DATE": l.visualDate, "STORAGE_LOCATION": l.location, "RECEIVED_DATE": l.received,
                "REMARKS": l.remarks, "ATTACH_GRP_CD": l.attachGrp, "FILE_PATH": l.filePath, "QTY": l.qty,
            ]
        }
        guard let data = try? JSONSerialization.data(withJSONObject: list), let listText = String(data: data, encoding: .utf8) else {
            formError = "Không tạo được dữ liệu gửi."; return
        }
        let head: [(String, String)] = [
            ("MRR_HEADER_ID", f.headerId), ("MRR_NO", f.no), ("MRR_NAME", f.name.trimmingCharacters(in: .whitespaces)), ("STATUS", f.isNew ? "" : f.status),
            ("RECEIVED_DATE_FROM", DesmMrrFmt.text(f.recFrom)), ("RECEIVED_DATE_TO", DesmMrrFmt.text(f.recTo)),
            ("INSPECTION_DATE_FROM", DesmMrrFmt.text(f.insFrom)), ("INSPECTION_DATE_TO", DesmMrrFmt.text(f.insTo)),
            ("REMARK", f.remark), ("ATTACH_GRP_CD", f.attachGrp), ("PREPARED_BY", f.preparedBy.trimmingCharacters(in: .whitespaces)),
            ("CHECKED_BY", f.checkedBy), ("CONFIRMED_BY", f.confirmedBy.trimmingCharacters(in: .whitespaces)), ("APPROVED_BY", ""),
            ("TRANS_TYPE", trans), ("PROJECT_NO", project),
        ]
        let e = BrowserModel.enc
        let body = head.map { "\($0.0)=\(e($0.1))" }.joined(separator: "&") + "&updateList=" + e(listText)
        var payloadObj = head.reduce(into: [String: Any]()) { $0[$1.0] = $1.1 }
        payloadObj["updateList"] = list
        let payload = (try? JSONSerialization.data(withJSONObject: payloadObj, options: [.sortedKeys])).flatMap { String(data: $0, encoding: .utf8) } ?? listText
        var label: String = "MRR " + f.no + " (sửa dòng)"
        if f.isNew { label = "MRR mới — " + f.name }
        else if trans == "Pre-Confirmed" { label = "MRR " + f.no + " — Request" }
        else if trans == "Confirmed" { label = "MRR " + f.no + " — Confirm" }
        saving = true
        Task { @MainActor [self] in
            if project.isEmpty { project = (try? await model.desmProjectNo()) ?? "" }
            let r = await model.desmWriteForm("/saveDesmMrrSave.do", body: body, label: label, payload: payload)
            saving = false
            if r.ok {
                if f.isNew {
                    formNotice = "Đã gửi lệnh lưu MRR mới ✓ (kiểm tra trong danh sách)."
                    form = DesmMrrForm(); selected = []
                    savedNew = true
                    search(model)
                } else {
                    formNotice = "Đã lưu ✓"
                    if trans != "Incomplete" {
                        // Như web: sau Request/Confirm gọi sendMailDesmMrr với MRR_HEADER_ID + STATUS của kết quả
                        var hid: String = f.headerId
                        if let v = r.obj["MRR_HEADER_ID"] as? String, !v.isEmpty { hid = v }
                        var st: String = trans
                        if let v = r.obj["STATUS"] as? String, !v.isEmpty { st = v }
                        let w = await sendMail(model, headerId: hid, status: st)
                        var msg: String = trans == "Confirmed" ? "Đã Confirm ✓" : "Đã Request ✓"
                        if let w = w { msg += " — " + w }
                        formNotice = msg
                    }
                    await loadInfo(model, headerId: f.headerId); selected = []
                    search(model)
                }
            } else {
                formError = "Lưu thất bại: " + r.err
            }
        }
    }
}

// MARK: - Chọn kiện để Add

@MainActor
final class DesmMrrPickVM: ObservableObject {
    @Published var invoice = ""
    @Published var pkg = ""
    @Published var shipment = ""
    @Published var rows: [PkgRow] = []
    @Published var picked = Set<Int>()
    @Published var loading = false
    @Published var searched = false
    @Published var error: String? = nil

    func search(_ model: BrowserModel) {
        if loading { return }
        let inv = invoice.trimmingCharacters(in: .whitespaces), pk = pkg.trimmingCharacters(in: .whitespaces)
        let sh = shipment.trimmingCharacters(in: .whitespaces)
        if inv.isEmpty && pk.isEmpty && sh.isEmpty { error = "Nhập Invoice No, Package No hoặc Shipment No rồi bấm Search (tìm toàn bộ rất chậm)."; return }
        loading = true; error = nil
        Task { @MainActor [self] in
            do {
                let pj = try await model.desmProjectNo()
                let e = BrowserModel.enc
                var body = "PROJECT_NO=\(e(pj))&PACKAGE_LIST_NO=\(e(inv))&PACKAGE_NO=\(e(pk))&DESCRIPTION=&IS_CONFIRM_MATERIAL=&RECEIPTED="
                body += "&ATTRIBUTE10=\(e(sh))&REMARK=&VENDOR=&LOCATION=&START_RECEIPT_DATE=&END_RECEIPT_DATE="
                body += "&MRR_VISUAL_CHECK=All&MRR_RECEIVED=N&START_MRR_RECEIVED_DATE=&END_MRR_RECEIVED_DATE=&CUSTOMS_YN=&MIR_CATEGORY=&PACKAGE_STATUS="
                let list = try await model.desmQueryAsync("/getIdsmOsSummaryList.do", body: body)
                var out: [PkgRow] = []
                for r in list {
                    let m = PkgFmt.strMap(r)
                    if (m["PACKAGE_NO"] ?? "").isEmpty { continue }
                    out.append(PkgRow(id: out.count, raw: m))
                }
                rows = desmSortedByPkg(out, pkg: { $0.no }, code: { _ in "" })
                picked = []
            } catch let err { error = err.localizedDescription }
            loading = false; searched = true
        }
    }
}

struct DesmMrrPickSheet: View {
    @ObservedObject var model: BrowserModel
    var exclude: Set<String>
    var onAdd: ([PkgRow]) -> Void
    var onClose: () -> Void
    @StateObject private var vm = DesmMrrPickVM()
    private let bg = Color(red: 0.95, green: 0.97, blue: 0.99)

    func field(_ title: String, _ text: Binding<String>) -> some View {
        HStack(spacing: 10) {
            Text(title).font(.system(size: 14, weight: .bold)).frame(width: 96, alignment: .leading)
            TextField("", text: text).textInputAutocapitalization(.characters).autocorrectionDisabled()
                .padding(.horizontal, 10).padding(.vertical, 9)
                .background(Color.white, in: RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.35)))
                .submitLabel(.search).onSubmit { vm.search(model) }
        }
    }

    var shown: [PkgRow] { vm.rows.filter { !exclude.contains($0.no.uppercased()) } }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                VStack(spacing: 8) {
                    field("Invoice No.", $vm.invoice)
                    field("Package No.", $vm.pkg)
                    field("Shipment No.", $vm.shipment)
                    Button { vm.search(model) } label: {
                        Label("Search", systemImage: "magnifyingglass").font(.system(size: 15, weight: .bold))
                            .frame(maxWidth: .infinity).padding(.vertical, 11).foregroundStyle(.white)
                            .background(Color(red: 0.12, green: 0.56, blue: 1.0), in: RoundedRectangle(cornerRadius: 8))
                    }.buttonStyle(.plain)
                }
                .padding(12).background(bg)
                Divider()
                if let e = vm.error {
                    Text(e).font(.system(size: 13)).foregroundStyle(.red).padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading).background(Color.red.opacity(0.08))
                }
                if vm.loading {
                    Spacer(); ProgressView("Đang tìm…"); Spacer()
                } else if shown.isEmpty {
                    Spacer()
                    Text(vm.searched ? "Không có kiện nào chưa nhận MRR theo điều kiện này (hoặc đã nằm trong phiếu)."
                                     : "Nhập Invoice / Package / Shipment rồi bấm Search để chọn kiện cần nhận.")
                        .font(.callout).foregroundStyle(.secondary).multilineTextAlignment(.center).padding(24)
                    Spacer()
                } else {
                    ScrollView {
                        LazyVStack(spacing: 8) {
                            ForEach(shown) { r in
                                Button {
                                    if vm.picked.contains(r.id) { vm.picked.remove(r.id) } else { vm.picked.insert(r.id) }
                                } label: {
                                    HStack(spacing: 10) {
                                        Image(systemName: vm.picked.contains(r.id) ? "checkmark.circle.fill" : "circle")
                                            .font(.system(size: 22)).foregroundStyle(vm.picked.contains(r.id) ? Color.tabBlue : .gray)
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(r.no).font(.system(size: 16, weight: .bold))
                                            Text(r.desc).font(.system(size: 14)).lineLimit(2)
                                            Text([r.plNo, r.s("ATTRIBUTE10")].filter { !$0.isEmpty }.joined(separator: " · "))
                                                .font(.system(size: 12)).foregroundStyle(.secondary)
                                        }
                                        Spacer(minLength: 0)
                                    }
                                    .padding(10).foregroundStyle(.primary)
                                    .background(Color.white, in: RoundedRectangle(cornerRadius: 10))
                                    .shadow(color: .black.opacity(0.10), radius: 2, y: 1)
                                }.buttonStyle(.plain)
                            }
                        }.padding(12)
                    }
                    .background(bg)
                }
                if !vm.picked.isEmpty {
                    Button {
                        onAdd(shown.filter { vm.picked.contains($0.id) }); onClose()
                    } label: {
                        Text("Thêm \(vm.picked.count) kiện vào phiếu").font(.system(size: 16, weight: .bold))
                            .frame(maxWidth: .infinity).padding(.vertical, 13).foregroundStyle(.white)
                            .background(Color.tabBlue, in: RoundedRectangle(cornerRadius: 10))
                    }.buttonStyle(.plain).padding(12)
                }
            }
            .navigationTitle("Chọn kiện (Add)").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { onClose() } } }
        }
    }
}

enum MrrAct { case none, save, request, confirm, reject, deleteMrr, deleteLines, tempSave }

// MARK: - Ô chọn ngày kiểu "From / To" (viền xanh, chữ xanh như ảnh)

struct MrrDatePill: View {
    let placeholder: String
    @Binding var date: Date?
    @State private var show = false
    @State private var temp = Date()
    private let blue = Color(red: 0.12, green: 0.56, blue: 1.0)

    var body: some View {
        Button { temp = date ?? Date(); show = true } label: {
            Text(date.map { DesmMrrFmt.text($0) } ?? placeholder)
                .font(.system(size: 17)).foregroundStyle(blue).lineLimit(1).minimumScaleFactor(0.7)
                .frame(maxWidth: .infinity, minHeight: 32)
                .background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 5))
                .overlay(RoundedRectangle(cornerRadius: 5).stroke(blue))
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $show) {
            VStack(spacing: 10) {
                DatePicker("", selection: $temp, displayedComponents: .date)
                    .datePickerStyle(.graphical).labelsHidden()
                HStack(spacing: 10) {
                    Button("Xoá") { date = nil; show = false }.buttonStyle(.bordered).tint(.red)
                    Spacer()
                    Button("Huỷ") { show = false }.buttonStyle(.bordered)
                    Button("OK") { date = temp; show = false }.buttonStyle(.borderedProminent)
                }
            }
            .padding(16)
            .presentationDetents([.medium])
        }
    }
}

// MARK: - Màn chính

struct DesmMrrSheet: View {
    @ObservedObject var model: BrowserModel
    var onClose: () -> Void
    @StateObject private var vm = DesmMrrVM()
    @State private var showForm = false
    @State private var showPick = false
    @State private var confirmSave = false
    @State private var confirmRemove = false
    @State private var showHeadDetail = false
    @State private var act: MrrAct = .none
    @State private var showAct = false
    private let headBlue = Color(red: 0.33, green: 0.65, blue: 0.98)
    private let bg = Color(red: 0.95, green: 0.97, blue: 0.99)

    // MARK: Danh sách (giao diện làm theo ảnh MRR Search của web mobile)

    private let purple = Color(red: 0.75, green: 0.51, blue: 0.99)
    private let purpleDark = Color(red: 0.58, green: 0.20, blue: 0.92)
    private let orange = Color(red: 1.0, green: 0.58, blue: 0.25)
    private let teal = Color(red: 0.07, green: 0.70, blue: 0.62)
    private let blue = Color(red: 0.12, green: 0.56, blue: 1.0)
    private let labelGray = Color(white: 0.33)

    func formRow<C: View>(_ title: String, @ViewBuilder _ content: () -> C) -> some View {
        HStack(spacing: 8) {
            Text(title).font(.system(size: 17, weight: .bold)).foregroundStyle(labelGray)
                .lineLimit(1).minimumScaleFactor(0.7)
                .frame(width: 128, alignment: .leading)
            content()
        }
    }

    func inputField(_ text: Binding<String>) -> some View {
        TextField("", text: text).textInputAutocapitalization(.characters).autocorrectionDisabled()
            .font(.system(size: 17))
            .padding(.horizontal, 8).frame(height: 32)
            .background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 5))
            .overlay(RoundedRectangle(cornerRadius: 5).stroke(Color.gray.opacity(0.35)))
            .submitLabel(.search).onSubmit { vm.search(model) }
    }

    func dateRange(_ from: Binding<Date?>, _ to: Binding<Date?>) -> some View {
        HStack(spacing: 6) {
            MrrDatePill(placeholder: "From", date: from)
            Text("~").font(.system(size: 17, weight: .bold)).foregroundStyle(labelGray)
            MrrDatePill(placeholder: "To", date: to)
        }
    }

    var statusMenu: some View {
        Menu {
            ForEach(DesmMrrVM.statuses, id: \.self) { st in
                Button(st.isEmpty ? "All" : st) { vm.status = st }
            }
        } label: {
            HStack {
                Text(vm.status.isEmpty ? "Choose MRR Status" : vm.status)
                    .foregroundStyle(vm.status.isEmpty ? Color.gray : Color.primary)
                Spacer(minLength: 0)
                Image(systemName: "chevron.down").font(.system(size: 13, weight: .semibold)).foregroundStyle(.gray)
            }
            .font(.system(size: 17)).padding(.horizontal, 8).frame(height: 32)
            .background(Color.white.opacity(0.6), in: RoundedRectangle(cornerRadius: 5))
            .overlay(RoundedRectangle(cornerRadius: 5).stroke(Color.gray.opacity(0.35)))
        }
    }

    func pill(_ title: String, _ symbol: String, _ color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: symbol).font(.system(size: 17, weight: .bold))
                .lineLimit(1).minimumScaleFactor(0.6)
                .frame(maxWidth: .infinity).padding(.vertical, 12).padding(.horizontal, 2).foregroundStyle(.white)
                .background(color, in: RoundedRectangle(cornerRadius: 5))
        }.buttonStyle(.plain)
    }

    func statusColor(_ s: String) -> Color {
        switch s {
        case "Confirmed": return .green
        case "Pre-Confirmed": return .orange
        case "Rejected": return .red
        default: return .gray
        }
    }

    var searchCard: some View {
        VStack(spacing: 4) {
            if vm.showFilter {
                formRow("MRR No.") { inputField($vm.mrrNo) }
                formRow("MRR Name") { inputField($vm.mrrName) }
                formRow("Invoice No.") { inputField($vm.invoice) }
                formRow("Package No.") { inputField($vm.pkg) }
                formRow("Approval Status") { statusMenu }
                formRow("Received Date") { dateRange($vm.recFrom, $vm.recTo) }
                formRow("Inspection Date") { dateRange($vm.insFrom, $vm.insTo) }
            }
            HStack(spacing: 6) {
                pill(vm.showFilter ? "Hide" : "Show", vm.showFilter ? "chevron.up.2" : "chevron.down.2", teal) {
                    withAnimation { vm.showFilter.toggle() }
                }
                pill("Reset", "arrow.counterclockwise", Color(red: 0.42, green: 0.53, blue: 0.72)) { vm.reset() }
                pill("Search", "magnifyingglass", blue) { vm.search(model) }
                pill("Creation", "pencil", Color(red: 0.94, green: 0.27, blue: 0.27)) { vm.startNew(model); showForm = true }
            }
            .padding(.top, 6)
        }
        .padding(.horizontal, 8).padding(.vertical, 6).background(bg)
    }

    func headCard(_ h: DesmMrrHead) -> some View {
        Button { showHeadDetail = false; vm.open(model, headerId: h.id); showForm = true } label: {
            HStack(spacing: 0) {
                Rectangle().fill(purple).frame(width: 6)
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text(h.name.isEmpty ? h.no : h.name).font(.system(size: 19, weight: .bold)).underline()
                            .lineLimit(1).minimumScaleFactor(0.7)
                        Spacer(minLength: 6)
                        Text(h.preparedBy).font(.system(size: 18)).lineLimit(1).minimumScaleFactor(0.7)
                    }
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text(h.status).font(.system(size: 18))
                        Spacer(minLength: 6)
                        Text(DesmMrrFmt.show(h.recFrom) + " ~ " + DesmMrrFmt.show(h.recTo))
                            .font(.system(size: 18)).lineLimit(1).minimumScaleFactor(0.7)
                    }
                    Text(h.remark.trimmingCharacters(in: .whitespaces).isEmpty ? "N/A" : h.remark)
                        .font(.system(size: 18)).lineLimit(2)
                }
                .padding(.horizontal, 12).padding(.vertical, 10).foregroundStyle(.primary)
            }
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .shadow(color: .black.opacity(0.12), radius: 2, y: 1)
        }.buttonStyle(.plain)
    }

    var rootView: some View {
        VStack(spacing: 0) {
            searchCard
            Divider()
            if let e = vm.error {
                Text(e).font(.system(size: 13)).foregroundStyle(.red).padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading).background(Color.red.opacity(0.08))
            }
            if let n = vm.formNotice, !showForm {
                Text(n).font(.system(size: 13, weight: .semibold)).foregroundStyle(.green).padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading).background(Color.green.opacity(0.10))
            }
            if vm.loading && vm.heads.isEmpty {
                Spacer(); ProgressView("Đang tải…"); Spacer()
            } else if vm.heads.isEmpty {
                Spacer()
                Text(vm.searched ? "No Results." : "Bấm Search để xem danh sách MRR.")
                    .font(.system(size: vm.searched ? 28 : 16, weight: .bold))
                    .foregroundStyle(vm.searched ? Color(red: 0.05, green: 0.36, blue: 0.75) : Color.secondary)
                    .multilineTextAlignment(.center).padding(24)
                Spacer()
            } else {
                ScrollView {
                    LazyVStack(spacing: 10) { ForEach(vm.heads) { headCard($0) } }.padding(12)
                }
                .background(bg)
            }
        }
        .background(bg)
    }

    // MARK: Form "MRR Creation"

    func labeled<C: View>(_ title: String, required: Bool = false, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 2) {
                Text(title).font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary)
                if required { Text("*").font(.system(size: 12, weight: .bold)).foregroundStyle(.red) }
            }
            content()
        }
    }

    func textBox(_ text: Binding<String>, editable: Bool, caps: Bool = false) -> some View {
        TextField("", text: text)
            .textInputAutocapitalization(caps ? .characters : .never).autocorrectionDisabled()
            .font(.system(size: 16)).disabled(!editable)
            .padding(.horizontal, 10).frame(height: 42)
            .background(editable ? Color.white : Color.gray.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.35)))
    }

    func dateBox(_ title: String, _ date: Binding<Date?>, editable: Bool, required: Bool = false) -> some View {
        labeled(title, required: required) {
            if editable {
                HStack(spacing: 6) {
                    if let d = date.wrappedValue {
                        DatePicker("", selection: Binding(get: { d }, set: { date.wrappedValue = $0 }), displayedComponents: .date).labelsHidden()
                        Button { date.wrappedValue = nil } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }.buttonStyle(.plain)
                    } else {
                        Button { date.wrappedValue = Date() } label: {
                            Text("Chọn ngày").font(.system(size: 15)).foregroundStyle(Color.tabBlue)
                                .frame(maxWidth: .infinity, minHeight: 40, alignment: .leading).padding(.horizontal, 10)
                                .background(Color.white, in: RoundedRectangle(cornerRadius: 8))
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.35)))
                        }.buttonStyle(.plain)
                    }
                    Spacer(minLength: 0)
                }
            } else {
                Text(DesmMrrFmt.text(date.wrappedValue).isEmpty ? "-" : DesmMrrFmt.text(date.wrappedValue))
                    .font(.system(size: 16)).frame(maxWidth: .infinity, minHeight: 42, alignment: .leading).padding(.horizontal, 10)
                    .background(Color.gray.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
            }
        }
    }

    var headerCard: some View {
        let isNew = vm.form.isNew
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text(isNew ? "MRR mới" : vm.form.no).font(.system(size: 20, weight: .bold))
                Spacer()
                if !isNew { Text(vm.form.status).font(.system(size: 14, weight: .bold)).foregroundStyle(statusColor(vm.form.status)) }
            }
            labeled("MRR Name", required: true) { textBox($vm.form.name, editable: isNew, caps: true) }
            HStack(spacing: 10) {
                dateBox("Received Date từ", $vm.form.recFrom, editable: isNew, required: true)
                dateBox("đến", $vm.form.recTo, editable: isNew, required: true)
            }
            HStack(spacing: 10) {
                dateBox("Inspection Date từ", $vm.form.insFrom, editable: isNew)
                dateBox("đến", $vm.form.insTo, editable: isNew)
            }
            labeled("Remarks") {
                TextEditor(text: $vm.form.remark).font(.system(size: 15)).frame(minHeight: 64)
                    .scrollContentBackground(.hidden).disabled(!isNew).padding(4)
                    .background(isNew ? Color.white : Color.gray.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.35)))
            }
            if !isNew {
                Text("Đầu phiếu của MRR đã tạo chỉ để xem; sửa đầu phiếu trên bản web.").font(.system(size: 12)).foregroundStyle(.secondary)
            }
        }
        .padding(12).background(Color.white, in: RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.10), radius: 2, y: 1)
    }

    func lineCard(_ l: DesmMrrLineRow, no: Int) -> some View {
        VStack(spacing: 4) {
            lineCardBody(l, no: no)
            if vm.form.canRemark { remarkBox(l) }
        }
    }

    func lineCardBody(_ l: DesmMrrLineRow, no: Int) -> some View {
        let on = vm.selected.contains(l.id)
        let canEdit = vm.form.canEdit
        return Button {
            guard canEdit else { return }
            if on { vm.selected.remove(l.id) } else { vm.selected.insert(l.id) }
        } label: {
            HStack(spacing: 0) {
                Rectangle().fill(orange).frame(width: 6)
                HStack(alignment: .top, spacing: 8) {
                    if canEdit {
                        Image(systemName: on ? "checkmark.circle.fill" : "circle").font(.system(size: 22))
                            .foregroundStyle(on ? Color.tabBlue : .gray).padding(.top, 2)
                    }
                    VStack(alignment: .leading, spacing: 4) {
                        Text(l.invoice).font(.system(size: 19, weight: .bold)).lineLimit(1).minimumScaleFactor(0.7)
                        Button { model.jumpToPackage(l.pkg) } label: {
                            HStack(spacing: 4) {
                                Text(l.pkg).font(.system(size: 19, weight: .bold)).underline().lineLimit(1).minimumScaleFactor(0.7)
                                Image(systemName: "arrow.up.right.square").font(.system(size: 14)).foregroundStyle(Color.tabBlue)
                            }
                        }.buttonStyle(.plain)
                        Text(l.desc).font(.system(size: 18)).lineLimit(2)
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            if !l.dtl.isEmpty {
                                Text("Detail item lines : " + l.dtl).font(.system(size: 17, weight: .bold)).foregroundStyle(blue)
                                    .lineLimit(1).minimumScaleFactor(0.7)
                            }
                            Spacer(minLength: 4)
                            if !l.location.isEmpty {
                                Image(systemName: "mappin.and.ellipse").font(.system(size: 14)).foregroundStyle(.gray)
                                Text(l.location).font(.system(size: 17, weight: .bold)).underline()
                                    .lineLimit(1).minimumScaleFactor(0.6)
                            }
                        }
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text("Received date : " + (l.received.isEmpty ? "-" : l.received))
                                .font(.system(size: 17, weight: .bold)).foregroundStyle(Color(red: 0.94, green: 0.27, blue: 0.27))
                                .lineLimit(1).minimumScaleFactor(0.7)
                            Spacer(minLength: 4)
                            if l.changed { Text("● chưa lưu").font(.system(size: 11, weight: .semibold)).foregroundStyle(.orange) }
                            if l.attCnt > 0 && !l.attachGrp.isEmpty {
                                Button { vm.showAttachments(model, group: l.attachGrp, title: l.pkg) } label: {
                                    Label("\(l.attCnt)", systemImage: "paperclip").font(.system(size: 15, weight: .bold)).foregroundStyle(blue)
                                        .padding(.horizontal, 6).padding(.vertical, 2)
                                }.buttonStyle(.plain)
                            }
                            Text(l.visual).font(.system(size: 17, weight: .bold)).foregroundStyle(Color(red: 0.94, green: 0.27, blue: 0.27))
                        }
                    }
                    Spacer(minLength: 0)
                }
                .padding(.leading, 10).padding(.trailing, 12).padding(.vertical, 10).foregroundStyle(.primary)
            }
            .background(on ? Color.tabBlue.opacity(0.10) : Color.white)
            .overlay(alignment: .topTrailing) {
                ZStack(alignment: .topTrailing) {
                    Path { p in
                        p.move(to: CGPoint(x: 0, y: 0)); p.addLine(to: CGPoint(x: 38, y: 0))
                        p.addLine(to: CGPoint(x: 38, y: 38)); p.closeSubpath()
                    }.fill(teal)
                    Image(systemName: "arrow.left").font(.system(size: 12, weight: .bold)).foregroundStyle(.white)
                        .padding(.top, 5).padding(.trailing, 6)
                }
                .frame(width: 38, height: 38)
            }
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(on ? Color.tabBlue : Color.clear, lineWidth: 1.5))
            .shadow(color: .black.opacity(0.10), radius: 2, y: 1)
        }.buttonStyle(.plain)
    }

    /// Đầu màn "MRR Detail" của phiếu đã tạo: nền tím, nút Show attachment files + mũi tên mở REMARKS / Prepared / Confirmed.
    var detailHeader: some View {
        let f = vm.form
        let recv = "Recv " + DesmMrrFmt.short(DesmMrrFmt.text(f.recFrom)) + " ~ " + DesmMrrFmt.short(DesmMrrFmt.text(f.recTo))
        let insp = "Insp " + DesmMrrFmt.short(DesmMrrFmt.text(f.insFrom)) + " ~ " + DesmMrrFmt.short(DesmMrrFmt.text(f.insTo))
        let prep = f.preparedBy.isEmpty ? f.preparedByName : f.preparedBy
        let conf = f.confirmedBy.isEmpty ? f.confirmedByName : f.confirmedBy
        return VStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .firstTextBaseline) {
                    Text(vm.project.isEmpty ? "-" : vm.project).font(.system(size: 24, weight: .bold)).underline()
                    Spacer(minLength: 8)
                    Text(f.status).font(.system(size: 24, weight: .bold))
                }
                HStack(alignment: .firstTextBaseline) {
                    Text(f.no).font(.system(size: 21)).lineLimit(1).minimumScaleFactor(0.6)
                    Spacer(minLength: 8)
                    Text(f.name).font(.system(size: 21)).lineLimit(1).minimumScaleFactor(0.6)
                }
                .opacity(0.92)
                Text(recv + "  /  " + insp).font(.system(size: 17, weight: .bold)).lineLimit(1).minimumScaleFactor(0.55)
                    .opacity(0.92)
                HStack(spacing: 10) {
                    Button { vm.showAttachments(model, group: vm.form.attachGrp, title: "MRR") } label: {
                        HStack(spacing: 8) {
                            if vm.attBusy { ProgressView().tint(.white) }
                            Text("Show attachment files").font(.system(size: 19, weight: .bold))
                        }
                        .frame(maxWidth: .infinity).padding(.vertical, 8).foregroundStyle(.white)
                        .background(blue, in: RoundedRectangle(cornerRadius: 5))
                    }.buttonStyle(.plain).disabled(vm.attBusy)
                    Button { withAnimation { showHeadDetail.toggle() } } label: {
                        Image(systemName: showHeadDetail ? "arrowtriangle.up.fill" : "arrowtriangle.down.fill")
                            .font(.system(size: 14)).foregroundStyle(purpleDark)
                            .frame(width: 40, height: 38).background(Color.white, in: RoundedRectangle(cornerRadius: 5))
                    }.buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16).padding(.vertical, 12).foregroundStyle(.white)
            .frame(maxWidth: .infinity, alignment: .leading).background(purple)
            if showHeadDetail {
                VStack(alignment: .leading, spacing: 10) {
                    Text("REMARKS").font(.system(size: 22, weight: .bold))
                    Text(f.remark.trimmingCharacters(in: .whitespaces).isEmpty ? "N/A" : f.remark)
                        .font(.system(size: 18)).foregroundStyle(.black)
                        .frame(maxWidth: .infinity, minHeight: 70, alignment: .topLeading).padding(10)
                        .background(Color.white, in: RoundedRectangle(cornerRadius: 5))
                    HStack(spacing: 8) {
                        Text("Prepared  by :" + prep).lineLimit(1).minimumScaleFactor(0.6)
                        Spacer(minLength: 4)
                        Text(f.preparedDate).lineLimit(1)
                    }
                    HStack(spacing: 8) {
                        Text("Confirmed by :" + conf).lineLimit(1).minimumScaleFactor(0.6)
                        Spacer(minLength: 4)
                        Text(f.confirmedDate).lineLimit(1)
                    }
                }
                .font(.system(size: 17)).foregroundStyle(.white)
                .padding(.horizontal, 16).padding(.vertical, 12)
                .frame(maxWidth: .infinity, alignment: .leading).background(purpleDark)
            }
        }
        .shadow(color: .black.opacity(0.18), radius: 3, y: 2)
    }

    func remarkBox(_ l: DesmMrrLineRow) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "text.bubble").foregroundStyle(.gray)
            TextField("Remarks", text: Binding(get: { vm.form.lines.first(where: { $0.id == l.id })?.remarks ?? "" },
                                               set: { vm.setRemark(l.id, $0) }))
                .font(.system(size: 16)).autocorrectionDisabled()
        }
        .padding(.horizontal, 10).frame(height: 38)
        .background(Color.white, in: RoundedRectangle(cornerRadius: 8))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.3)))
    }

    var inspectionCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Inspection Date").font(.system(size: 14, weight: .bold)).foregroundStyle(labelGray)
            dateRange($vm.form.insFrom, $vm.form.insTo)
            Text("Phiếu Confirmed chỉ sửa được Inspection Date và Remarks từng dòng (Temp Save).")
                .font(.system(size: 12)).foregroundStyle(.secondary)
        }
        .padding(12).background(Color.white, in: RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.10), radius: 2, y: 1)
    }

    func actBtn(_ title: String, _ color: Color, _ a: MrrAct) -> some View {
        Button { act = a; showAct = true } label: {
            Text(title).font(.system(size: 16, weight: .bold)).lineLimit(1).minimumScaleFactor(0.7)
                .frame(maxWidth: .infinity).padding(.vertical, 13).foregroundStyle(.white)
                .background(color, in: RoundedRectangle(cornerRadius: 10))
        }.buttonStyle(.plain).disabled(vm.saving)
    }

    /// Hợp lệ trước khi mở hộp xác nhận (cùng kiểm tra như web).
    func tryAct(_ a: MrrAct) {
        switch a {
        case .save: if let e = vm.validate() { vm.formError = e; return }
        case .request: if let e = vm.validate(trans: "Pre-Confirmed") { vm.formError = e; return }
        case .confirm: if let e = vm.validate(trans: "Confirmed") { vm.formError = e; return }
        case .deleteLines: if vm.selected.isEmpty { vm.formError = "Chưa chọn dòng nào."; return }
        default: break
        }
        vm.formError = nil; act = a; showAct = true
    }

    func barBtn(_ title: String, _ color: Color, _ a: MrrAct) -> some View {
        Button { tryAct(a) } label: {
            HStack(spacing: 6) {
                if vm.saving && a == .save { ProgressView().tint(.white) }
                Text(title).font(.system(size: 16, weight: .bold)).lineLimit(1).minimumScaleFactor(0.7)
            }
            .frame(maxWidth: .infinity).padding(.vertical, 13).foregroundStyle(.white)
            .background(color, in: RoundedRectangle(cornerRadius: 10))
        }.buttonStyle(.plain).disabled(vm.saving)
    }

    var bottomBar: some View {
        HStack(spacing: 8) {
            if vm.form.isNew || vm.form.canRequest {
                barBtn(vm.saving ? "Đang lưu…" : "Save (\(vm.saveCount))", .green, .save)
            }
            if vm.form.canRequest {
                barBtn("Request", blue, .request)
                barBtn("Delete", Color(red: 0.94, green: 0.27, blue: 0.27), .deleteMrr)
            }
            if vm.form.canConfirm {
                barBtn("Confirm", .green, .confirm)
                barBtn("Reject", Color(red: 0.94, green: 0.27, blue: 0.27), .reject)
            }
            if vm.form.canTemp { barBtn(vm.saving ? "Đang lưu…" : "Temp Save", .green, .tempSave) }
        }
        .padding(12)
    }

    var actIsDanger: Bool { act == .deleteMrr || act == .deleteLines || act == .reject }
    var actIcon: String { actIsDanger ? "trash" : "exclamationmark.triangle.fill" }
    var actButtonKind: DesmDialogAction.Kind { actIsDanger ? .destructive : .primary }
    var actButtonTitle: String {
        switch act {
        case .deleteMrr, .deleteLines: return "Xoá"
        case .reject: return "Reject"
        case .confirm: return "Confirm"
        case .request: return "Request"
        default: return "Lưu"
        }
    }

    var actTitle: String {
        switch act {
        case .save: return vm.form.isNew ? "Tạo MRR mới" : "Lưu MRR \(vm.form.no)"
        case .request: return "Request MRR \(vm.form.no)"
        case .confirm: return "Confirm MRR \(vm.form.no)"
        case .reject: return "Reject MRR \(vm.form.no)"
        case .deleteMrr: return "Xoá MRR \(vm.form.no)"
        case .deleteLines: return "Xoá \(vm.selected.count) dòng khỏi MRR?"
        case .tempSave: return "Temp Save MRR \(vm.form.no)"
        case .none: return ""
        }
    }
    var actMessage: String {
        switch act {
        case .save:
            return vm.form.isNew
                ? "Gửi MRR mới (\(vm.form.lines.count) kiện) lên DESM thật. Lệnh lưu phiếu mới CHƯA từng thử; sau khi lưu hãy kiểm tra lại trên web."
                : "Lưu \(vm.saveCount) dòng đã sửa của MRR này lên DESM."
        case .request: return "Chuyển phiếu sang Pre-Confirmed và gửi mail thông báo như trên web. Sau đó không sửa được dòng nữa."
        case .confirm: return "Chuyển phiếu sang Confirmed và gửi mail như trên web. Không hoàn tác được trong app."
        case .reject: return "Trả phiếu về trạng thái Rejected (ghi chú đầu phiếu được gửi kèm) và gửi mail như trên web."
        case .deleteMrr: return "Xoá HẲN phiếu MRR này trên DESM. Không hoàn tác được."
        case .deleteLines: return "Xoá các dòng đã chọn khỏi phiếu trên DESM."
        case .tempSave: return "Lưu Inspection Date và Remarks từng dòng đã sửa."
        case .none: return ""
        }
    }
    func runAct() {
        switch act {
        case .save: vm.save(model)
        case .request: vm.save(model, trans: "Pre-Confirmed")
        case .confirm: vm.save(model, trans: "Confirmed")
        case .reject: vm.reject(model)
        case .deleteMrr: vm.deleteMrr(model)
        case .deleteLines: vm.deleteSavedLines(model)
        case .tempSave: vm.tempSave(model)
        case .none: break
        }
    }

    var toolsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Button { vm.toggleAll() } label: {
                    Label(vm.lineAllOn ? "Bỏ chọn" : "Chọn tất cả", systemImage: vm.lineAllOn ? "circle" : "checkmark.circle")
                        .font(.system(size: 14, weight: .semibold))
                }.buttonStyle(.bordered).tint(Color.tabBlue)
                if vm.form.isNew {
                    Button { showPick = true } label: { Label("Add", systemImage: "plus").font(.system(size: 14, weight: .semibold)) }
                        .buttonStyle(.borderedProminent).tint(Color.tabBlue)
                    Button { if !vm.selected.isEmpty { confirmRemove = true } } label: { Label("Delete", systemImage: "trash").font(.system(size: 14, weight: .semibold)) }
                        .buttonStyle(.bordered).tint(.red).disabled(vm.selected.isEmpty)
                } else {
                    Button { tryAct(.deleteLines) } label: { Label("Delete dòng", systemImage: "trash").font(.system(size: 14, weight: .semibold)) }
                        .buttonStyle(.bordered).tint(.red).disabled(vm.selected.isEmpty || vm.saving)
                }
                Spacer(minLength: 0)
            }
            HStack(spacing: 8) {
                DatePicker("", selection: $vm.setDate, displayedComponents: .date).labelsHidden()
                Button("Received Date Update") { vm.applyReceived() }
                    .font(.system(size: 13, weight: .semibold)).buttonStyle(.bordered).tint(.green)
            }
            HStack(spacing: 8) {
                Picker("", selection: $vm.setVisual) { Text("Good").tag("Good"); Text("Defect").tag("Defect") }
                    .pickerStyle(.segmented).frame(width: 150)
                Button("Visual Check Update") { vm.applyVisual() }
                    .font(.system(size: 13, weight: .semibold)).buttonStyle(.bordered).tint(.green)
            }
            Text("Location Update: dùng màn Kiện hàng (chưa làm trong màn này).").font(.system(size: 11)).foregroundStyle(.secondary)
        }
        .padding(12).background(Color.white, in: RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.10), radius: 2, y: 1)
    }

    var signCard: some View {
        let isNew = vm.form.isNew
        return VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                labeled("Prepared by", required: true) { textBox($vm.form.preparedBy, editable: isNew, caps: true) }
                labeled("Ngày") {
                    Text(vm.form.preparedDate.isEmpty ? "-" : vm.form.preparedDate).font(.system(size: 15))
                        .frame(maxWidth: .infinity, minHeight: 42, alignment: .leading).padding(.horizontal, 10)
                        .background(Color.gray.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
                }
            }
            HStack(spacing: 10) {
                labeled("Confirmed by") { textBox($vm.form.confirmedBy, editable: isNew, caps: true) }
                labeled("Ngày") {
                    Text(vm.form.confirmedDate.isEmpty ? "-" : vm.form.confirmedDate).font(.system(size: 15))
                        .frame(maxWidth: .infinity, minHeight: 42, alignment: .leading).padding(.horizontal, 10)
                        .background(Color.gray.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
                }
            }
            if !vm.form.preparedByName.isEmpty || !vm.form.confirmedByName.isEmpty {
                Text([vm.form.preparedByName.isEmpty ? "" : "Lập: " + vm.form.preparedByName,
                      vm.form.confirmedByName.isEmpty ? "" : "Xác nhận: " + vm.form.confirmedByName].filter { !$0.isEmpty }.joined(separator: " · "))
                    .font(.system(size: 12)).foregroundStyle(.secondary)
            }
        }
        .padding(12).background(Color.white, in: RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.10), radius: 2, y: 1)
    }

    var formView: some View {
        VStack(spacing: 0) {
            if vm.formLoading {
                Spacer(); ProgressView("Đang tải MRR…"); Spacer()
            } else {
                if !vm.form.isNew { detailHeader }
                ScrollView {
                    VStack(spacing: 12) {
                        if let e = vm.formError {
                            Text(e).font(.system(size: 13)).foregroundStyle(.red).padding(10)
                                .frame(maxWidth: .infinity, alignment: .leading).background(Color.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
                        }
                        if let n = vm.formNotice {
                            Text(n).font(.system(size: 13, weight: .semibold)).foregroundStyle(.green).padding(10)
                                .frame(maxWidth: .infinity, alignment: .leading).background(Color.green.opacity(0.10), in: RoundedRectangle(cornerRadius: 8))
                        }
                        if vm.form.isNew { headerCard }
                        if !vm.form.canEdit {
                            Text("MRR đang ở trạng thái \(vm.form.status) nên chỉ xem, không sửa được.")
                                .font(.system(size: 13)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                        } else { toolsCard }
                        if vm.form.canTemp { inspectionCard }
                        Text("\(vm.form.lines.count) dòng" + (vm.selected.isEmpty ? "" : " · đã chọn \(vm.selected.count)"))
                            .font(.system(size: 13, weight: .semibold)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                        LazyVStack(spacing: 10) {
                            ForEach(Array(vm.form.lines.enumerated()), id: \.element.id) { i, l in lineCard(l, no: i + 1) }
                        }
                        if vm.form.isNew { signCard }
                    }
                    .padding(12)
                }
                .background(bg)
                if vm.form.canEdit || vm.form.canConfirm || vm.form.canTemp { bottomBar }
            }
        }
        .background(bg)
        .sheet(item: $vm.shareItem) { item in ShareSheet(url: item.url) }
    }

    var body: some View {
        NavigationStack {
            rootView
                .navigationTitle("MRR Search")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { onClose() } } }
                .navigationDestination(isPresented: $showForm) {
                    formView
                        .navigationTitle(vm.form.isNew ? "MRR Creation" : "MRR Detail").navigationBarTitleDisplayMode(.inline)
                }
        }
        .onAppear { if !vm.searched { vm.search(model) } }
        .onChange(of: vm.savedNew) { v in if v { showForm = false; vm.savedNew = false } }
        .sheet(isPresented: $showPick) {
            DesmMrrPickSheet(model: model, exclude: Set(vm.form.lines.map { $0.pkg.uppercased() }),
                             onAdd: { vm.add($0) }, onClose: { showPick = false })
        }
        .desmAlert(isPresented: $showAct, icon: actIcon, title: actTitle, message: actMessage,
                   actions: [DesmDialogAction(title: actButtonTitle, kind: actButtonKind) { runAct() },
                             DesmDialogAction(title: "Huỷ", kind: .cancel)])
        .desmAlert(isPresented: $confirmRemove, icon: "trash", title: "Bỏ \(vm.selected.count) dòng khỏi phiếu?",
                   message: "Chỉ bỏ khỏi phiếu đang soạn, chưa lưu lên DESM.",
                   actions: [DesmDialogAction(title: "Bỏ dòng", kind: .destructive) { vm.removeSelected() },
                             DesmDialogAction(title: "Huỷ", kind: .cancel)])
    }
}


// MARK: - Tải file từ DESM bằng phiên đăng nhập hiện có (GET) -> file tạm

extension BrowserModel {
    @MainActor
    func desmDownload(_ path: String, fallbackName: String) async throws -> URL {
        guard let base = URL(string: BrowserModel.apiOrigin), let url = URL(string: path, relativeTo: base)?.absoluteURL,
              url.host?.lowercased().hasSuffix("doosanenerbility.com") == true else { throw DesmAPIError.message("Địa chỉ không hợp lệ.") }
        let cookies = await desmCookies()
        guard !cookies.isEmpty else { throw DesmAPIError.noSession }
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 120)
        req.httpMethod = "GET"
        req.allHTTPHeaderFields = HTTPCookie.requestHeaderFields(with: cookies)
        req.setValue(BrowserModel.homeURL, forHTTPHeaderField: "Referer")
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw DesmAPIError.unreadable }
        if http.statusCode == 401 || http.url?.path.lowercased().contains("login") == true { throw DesmAPIError.expired }
        guard http.statusCode == 200, !data.isEmpty else { throw DesmAPIError.message("Máy chủ trả HTTP \(http.statusCode).") }
        let ct = (http.value(forHTTPHeaderField: "Content-Type") ?? "").lowercased()
        if ct.contains("text/html") { throw DesmAPIError.message("Máy chủ trả trang web thay vì file (có thể hết phiên).") }
        var name = fallbackName
        if let cd = http.value(forHTTPHeaderField: "Content-Disposition"),
           let r = cd.range(of: "filename=\"[^\"]+\"", options: .regularExpression) {
            let part = String(cd[r]).replacingOccurrences(of: "filename=\"", with: "").replacingOccurrences(of: "\"", with: "")
            if !part.isEmpty { name = part.removingPercentEncoding ?? part }
        }
        name = name.replacingOccurrences(of: "/", with: "_")
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("mrr-att-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let file = dir.appendingPathComponent(name)
        try data.write(to: file)
        return file
    }
}
