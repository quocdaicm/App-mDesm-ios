// PackageDetailView.swift — chi tiết một kiện (như màn "Package" khi chạm thẻ trên web): thông tin kiện, kích thước/trọng lượng,
// cờ SHORT/OVER/DMG/MISSING, Lịch sử thay đổi vị trí, RSI & MRF List, Detail Item List; bấm hạng mục → Detail Item (xem + SAVE).
// Thao tác trên cả kiện (Location Update/Delete, Material Confirm/Cancel, Customs) nằm ở menu "Thao tác" góc phải.
// Dữ liệu/API: PackageData.swift. CHƯA build Xcode / chưa thử máy thật.
// Location Update/Delete cấp hạng mục: làm theo plDetail.js (CODE_TYPE = DETAIL, chặn khi REMAIN_QTY = 0).

import SwiftUI

// MARK: - Khối giao diện nhỏ

struct PkgBandCell: View {
    let key: String
    let value: String
    var underline = false
    var body: some View {
        VStack(spacing: 4) {
            Text(key).font(.system(size: 13)).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.7)
            Text(value).font(.system(size: 16, weight: .bold)).underline(underline).lineLimit(1).minimumScaleFactor(0.6)
        }
        .frame(maxWidth: .infinity)
    }
}

struct PkgBand: View {
    let cells: [(String, String)]
    var body: some View {
        HStack(alignment: .top, spacing: 4) {
            ForEach(Array(cells.enumerated()), id: \.offset) { c in
                PkgBandCell(key: c.element.0, value: c.element.1)
            }
        }
        .padding(.vertical, 12).padding(.horizontal, 8)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.tabBlue.opacity(0.12), lineWidth: 1))
    }
}

struct PkgFlagsBand: View {
    let flags: [(String, Bool)]
    var body: some View {
        HStack(alignment: .top, spacing: 4) {
            ForEach(Array(flags.enumerated()), id: \.offset) { f in
                VStack(spacing: 8) {
                    Text(f.element.0).font(.system(size: 14, weight: .heavy))
                    Image(systemName: f.element.1 ? "checkmark.square.fill" : "square")
                        .font(.system(size: 26)).foregroundStyle(f.element.1 ? Color.red : Color(.tertiaryLabel))
                }
                .frame(maxWidth: .infinity)
            }
        }
        .padding(.vertical, 12).padding(.horizontal, 8)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.tabBlue.opacity(0.12), lineWidth: 1))
    }
}

struct PkgBigButton: View {
    let title: String
    var trailing: String? = nil
    var tint: Color = Color.tabBlue
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack {
                Text(title).font(.system(size: 18, weight: .bold)).foregroundStyle(.primary)
                if let t = trailing { Image(systemName: t).font(.system(size: 16, weight: .bold)).foregroundStyle(tint) }
            }
            .frame(maxWidth: .infinity, minHeight: 54)
            .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(tint.opacity(0.55), lineWidth: 1.5))
        }
        .buttonStyle(.plain)
    }
}

struct PkgDocCard: View {
    let doc: PkgDoc
    var onTap: () -> Void
    var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 5) {
                HStack(alignment: .firstTextBaseline) {
                    Text(doc.id).font(.system(size: 19, weight: .heavy)).underline().foregroundStyle(.primary).lineLimit(1).minimumScaleFactor(0.7)
                    Spacer(minLength: 6)
                    Text(doc.status.isEmpty ? (doc.isMrf ? "MRF" : "-") : doc.status).font(.system(size: 16)).foregroundStyle(.primary)
                }
                let mid = [doc.sub, doc.name].filter { !$0.isEmpty }.joined(separator: " · ")
                if !mid.isEmpty { Text(mid).font(.system(size: 16)).foregroundStyle(.primary).lineLimit(3) }
                HStack {
                    Text(doc.date.isEmpty ? "-" : PkgFmt.day(doc.date)).font(.system(size: 16)).foregroundStyle(.secondary)
                    Spacer()
                    Text("\(doc.lines) dòng · \(PkgFmt.num(doc.qty)) \(doc.unit.isEmpty ? "EA" : doc.unit)")
                        .font(.system(size: 16, weight: .semibold)).foregroundStyle(.primary)
                }
            }
            .padding(.vertical, 12).padding(.leading, 16).padding(.trailing, 14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.secondarySystemGroupedBackground))
            .overlay(alignment: .leading) { Rectangle().fill(doc.isMrf ? Color.orange : Color.tabBlue).frame(width: 6) }
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .shadow(color: Color.tabBlue.opacity(0.10), radius: 6, y: 2)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Chi tiết kiện

struct PackageDetailView: View {
    @ObservedObject var model: BrowserModel
    @ObservedObject var listVM: PackageVM
    let row0: PkgRow
    var onOpenDoc: (DesmDocKind, String) -> Void

    @StateObject private var vm: PackageDetailVM
    @State private var showDocs = true
    @State private var showItems = true
    @State private var openItem: PkgItem? = nil
    @State private var showLog = false
    @State private var locTarget: PkgLocTarget? = nil
    @State private var dialog: DesmDialogState? = nil

    init(model: BrowserModel, listVM: PackageVM, row: PkgRow, onOpenDoc: @escaping (DesmDocKind, String) -> Void) {
        self.model = model
        self.listVM = listVM
        self.row0 = row
        self.onOpenDoc = onOpenDoc
        _vm = StateObject(wrappedValue: PackageDetailVM(row: row))
    }

    /// Bản mới nhất của kiện (sau khi ghi, danh sách nạp lại → vị trí/trạng thái mới)
    var row: PkgRow { listVM.rows.first(where: { $0.no == row0.no }) ?? row0 }

    func ask(_ icon: String, _ title: String, _ message: String, _ button: String, _ destructive: Bool, _ run: @escaping () -> Void) {
        dialog = DesmDialogState(icon: icon, title: title, message: message, actions: [
            DesmDialogAction(title: button, kind: destructive ? .destructive : .primary, handler: run),
            DesmDialogAction(title: "Huỷ", kind: .cancel)
        ])
    }
    var ops: PkgActionOps {
        PkgActionOps(vm: listVM, model: model, ask: { i, t, m, b, d, r in ask(i, t, m, b, d, r) }, openLoc: { rows in locTarget = PkgLocTarget(rows: rows) })
    }

    // MARK: Thao tác vị trí theo hạng mục (plDetail.js: CODE_TYPE = DETAIL)

    func itemLocUpdate(_ items: [PkgItem]) {
        if let e = vm.locationBlocked(items) { vm.actionNote = e; vm.actionIsError = true; return }
        vm.actionNote = nil
        locTarget = PkgLocTarget(items: items)
    }
    func itemLocDelete(_ items: [PkgItem]) {
        if items.isEmpty { vm.actionNote = "Hãy chọn ít nhất một hạng mục trước."; vm.actionIsError = true; return }
        ask("mappin.slash", "Xoá vị trí hạng mục", "Xoá vị trí của \(items.count) hạng mục trên DESM? Thao tác này không tự hoàn tác được.", "Xoá vị trí", true) {
            vm.deleteItemLocation(model, items: items) { vm.loadItems(model) }
        }
    }
    var selectedItemList: [PkgItem] { vm.items.filter { vm.selectedItems.contains($0.id) } }

    // MARK: Phần tử

    var headerCard: some View {
        let r = row
        let nLines = Int(r.lines.split(separator: "/").first.map(String.init) ?? "") 
        return VStack(alignment: .leading, spacing: 6) {
            Text("#\(r.id + 1)  \(r.plNo.isEmpty ? r.no : r.plNo)").font(.system(size: 24, weight: .heavy))
            Text(r.no).font(.system(size: 20))
            if !r.desc.isEmpty { Text(r.desc).font(.system(size: 20)) }
            HStack(spacing: 4) {
                Text("Detail Item Lines").font(.system(size: 20))
                Text(nLines.map { String($0) } ?? "-").font(.system(size: 20, weight: .bold)).foregroundStyle(.red)
            }
            HStack {
                Text(r.statusText).font(.system(size: 20, weight: .semibold)).foregroundStyle(r.isClose ? Color(red: 0.12, green: 0.55, blue: 0.28) : Color.primary)
                Spacer()
                Text(r.lines.isEmpty ? "-" : r.lines).font(.system(size: 20))
                Spacer()
                Text(r.qtyText.isEmpty ? "-" : r.qtyText).font(.system(size: 20))
            }
            HStack(alignment: .center) {
                Text("S/C & Excel Remarks " + r.s("REMARKS")).font(.system(size: 20)).lineLimit(3)
                Spacer(minLength: 8)
                if r.showRemaining {
                    let left = max(r.remaining, 0)
                    let tint: Color = left > 0.0005 ? Color.orange : Color(red: 0.12, green: 0.55, blue: 0.28)
                    VStack(spacing: 0) {
                        Text("REMAIN").font(.system(size: 13, weight: .bold)).foregroundStyle(tint)
                        Text(PkgFmt.num(left)).font(.system(size: 28, weight: .heavy)).foregroundStyle(tint)
                    }
                    .padding(.horizontal, 16).padding(.vertical, 6)
                    .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(tint.opacity(0.14)))
                }
            }
            Divider()
            HStack {
                Text(r.s("PACKAGE_TYPE").isEmpty ? "-" : r.s("PACKAGE_TYPE")).font(.system(size: 20))
                Spacer()
                Button { locTarget = PkgLocTarget(rows: [r]) } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "mappin.and.ellipse").font(.system(size: 18, weight: .semibold))
                        Text(r.loc.isEmpty ? "Chưa có vị trí" : r.loc).font(.system(size: 20, weight: .heavy)).underline().lineLimit(1).minimumScaleFactor(0.7)
                    }
                    .foregroundStyle(r.loc.isEmpty ? Color.red : Color.primary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
        .shadow(color: Color.tabBlue.opacity(0.10), radius: 8, y: 3)
    }

    func flag(_ key: String) -> Bool {
        let r = row
        let v = r.s(key).uppercased()
        let q = PkgFmt.dbl(r.s(key + "_QTY"))
        return (!v.isEmpty && v != "0" && v != "N" && v != "FALSE") || q > 0
    }

    var docsSection: some View {
        VStack(spacing: 10) {
            PkgBigButton(title: "RSI & MRF List", trailing: showDocs ? "arrow.up" : "arrow.down") { withAnimation { showDocs.toggle() } }
            if showDocs {
                if vm.docsLoading { ProgressView("Đang tải RSI & MRF…").padding(.vertical, 8) }
                else if let e = vm.docsError, vm.docs.isEmpty { Text(e).font(.system(size: 14)).foregroundStyle(.red) }
                else if vm.docs.isEmpty { Text("Kiện này chưa có phiếu RSI hoặc MRF.").font(.system(size: 15)).foregroundStyle(.secondary).padding(.vertical, 6) }
                ForEach(vm.docs) { d in
                    PkgDocCard(doc: d) { onOpenDoc(d.isMrf ? .mrf : .rsi, d.id) }
                }
            }
        }
    }

    var itemsSection: some View {
        let allOn = !vm.items.isEmpty && vm.items.allSatisfy { vm.selectedItems.contains($0.id) }
        return VStack(spacing: 10) {
            PkgBigButton(title: "Detail Item List", trailing: showItems ? "arrow.up" : "arrow.down") { withAnimation { showItems.toggle() } }
            if showItems {
                if vm.itemsLoading { ProgressView("Đang tải danh sách hạng mục…").padding(.vertical, 8) }
                if let e = vm.itemsError { Text(e).font(.system(size: 14)).foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading) }
                if !vm.items.isEmpty {
                    HStack {
                        Button {
                            if allOn { vm.selectedItems = [] } else { vm.selectedItems = Set(vm.items.map { $0.id }) }
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: allOn ? "checkmark.square.fill" : "square").font(.system(size: 24)).foregroundStyle(allOn ? Color.tabBlue : Color(.tertiaryLabel))
                                Text("Chọn tất cả · \(vm.items.count) hạng mục" + (vm.selectedItems.isEmpty ? "" : " · đã chọn \(vm.selectedItems.count)"))
                                    .font(.system(size: 15, weight: .bold)).foregroundStyle(.primary)
                            }
                        }
                        .buttonStyle(.plain)
                        Spacer()
                    }
                    .padding(.horizontal, 6)
                }
                if let n = vm.actionNote {
                    Text(n).font(.system(size: 14, weight: .semibold)).foregroundStyle(vm.actionIsError ? Color.red : Color(red: 0.12, green: 0.50, blue: 0.25))
                        .frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 6)
                }
                if !vm.selectedItems.isEmpty {
                    HStack(spacing: 10) {
                        PkgPill(icon: "mappin.and.ellipse", title: "Location Update (\(vm.selectedItems.count))", tint: Color.tabBlue, fill: true) { itemLocUpdate(selectedItemList) }
                        PkgPill(icon: "mappin.slash", title: "Xoá vị trí", tint: Color.red, fill: true) { itemLocDelete(selectedItemList) }
                    }
                    .frame(maxWidth: .infinity)
                }
                ForEach(vm.items) { it in
                    itemCard(it)
                }
                if !vm.itemsLoading && vm.itemsError == nil && vm.items.isEmpty {
                    Text("Kiện này chưa có hạng mục chi tiết.").font(.system(size: 15)).foregroundStyle(.secondary).padding(.vertical, 6)
                }
            }
        }
    }

    func itemCard(_ it: PkgItem) -> some View {
        let on = vm.selectedItems.contains(it.id)
        let remain = it.remain
        let tint: Color = remain > 0.0005 ? Color.orange : Color(red: 0.12, green: 0.55, blue: 0.28)
        return HStack(alignment: .top, spacing: 12) {
            Button {
                if on { vm.selectedItems.remove(it.id) } else { vm.selectedItems.insert(it.id) }
            } label: {
                Image(systemName: on ? "checkmark.square.fill" : "square").font(.system(size: 28)).foregroundStyle(on ? Color.tabBlue : Color(.tertiaryLabel)).frame(width: 34, height: 34)
            }
            .buttonStyle(.plain)
            Button { openItem = it } label: {
                VStack(alignment: .leading, spacing: 5) {
                    Text(it.material.isEmpty ? "(không có mã)" : it.material).font(.system(size: 19, weight: .heavy)).foregroundStyle(.primary).lineLimit(1).minimumScaleFactor(0.7)
                    if !it.desc.isEmpty { Text(it.desc).font(.system(size: 17)).foregroundStyle(.primary).lineLimit(3) }
                    HStack(spacing: 8) {
                        Text("Q'ty : \(PkgFmt.num(it.inQ))/\(PkgFmt.num(it.outQ)) \(it.unit)").font(.system(size: 16, weight: .semibold)).foregroundStyle(Color.tabBlue)
                            .padding(.horizontal, 12).padding(.vertical, 5).background(Capsule().fill(Color.tabBlue.opacity(0.12))).lineLimit(1)
                        Spacer(minLength: 0)
                        Text("Remain " + PkgFmt.num(max(remain, 0))).font(.system(size: 15, weight: .bold)).foregroundStyle(tint)
                            .padding(.horizontal, 12).padding(.vertical, 5).background(Capsule().fill(tint.opacity(0.14))).lineLimit(1).minimumScaleFactor(0.8)
                    }
                    if !it.s("REMARKS").isEmpty { Text("Remarks : " + it.s("REMARKS")).font(.system(size: 15)).foregroundStyle(.secondary).lineLimit(2) }
                    HStack(spacing: 6) {
                        Image(systemName: "mappin.and.ellipse").font(.system(size: 14, weight: .semibold))
                        Text(it.loc.isEmpty ? "—" : it.loc).font(.system(size: 16, weight: .bold)).underline().lineLimit(1)
                        Spacer(minLength: 0)
                    }
                    .foregroundStyle(it.loc.isEmpty ? Color.secondary : Color.primary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 12).padding(.leading, 12).padding(.trailing, 14)
        .background(Color(.secondarySystemGroupedBackground))
        .overlay(alignment: .leading) { Rectangle().fill(remain > 0.0005 ? Color.orange : Color(red: 0.25, green: 0.70, blue: 0.40)).frame(width: 6) }
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(on ? Color.tabBlue : Color.clear, lineWidth: 2))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .shadow(color: Color.tabBlue.opacity(0.10), radius: 6, y: 2)
    }

    var body: some View {
        let r = row
        ZStack(alignment: .top) {
            PkgBackground()
            ScrollView {
                LazyVStack(spacing: 12) {
                    if let e = listVM.error {
                        Text(e).font(.system(size: 14)).foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading).padding(12)
                            .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.red.opacity(0.10)))
                    }
                    if let n = listVM.notice {
                        Text(n).font(.system(size: 14, weight: .semibold)).foregroundStyle(Color(red: 0.12, green: 0.50, blue: 0.25)).frame(maxWidth: .infinity, alignment: .leading).padding(12)
                            .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.green.opacity(0.12)))
                    }
                    if listVM.busy { HStack(spacing: 8) { ProgressView(); Text("Đang gửi lệnh lên DESM…").font(.system(size: 14, weight: .semibold)) }.frame(maxWidth: .infinity, alignment: .leading) }
                    headerCard
                    PkgBand(cells: [("Received", r.s("RECEIPT_DATE").isEmpty ? "-" : PkgFmt.day(r.s("RECEIPT_DATE"))),
                                    ("MRR Received", r.s("MRR_RECEIVED_DATE").isEmpty ? "-" : PkgFmt.day(r.s("MRR_RECEIVED_DATE"))),
                                    ("V/C", r.s("VISUAL_CHECK").isEmpty ? "-" : r.s("VISUAL_CHECK"))])
                    PkgBand(cells: [("L(cm)", PkgFmt.num(r.s("L_CM"), minDecimals: 3)), ("W(cm)", PkgFmt.num(r.s("W_CM"), minDecimals: 3)),
                                    ("H(cm)", PkgFmt.num(r.s("H_CM"), minDecimals: 3)), ("CBM", PkgFmt.num(r.s("VOLUME"), minDecimals: 3)),
                                    ("Net(kg)", PkgFmt.num(r.s("NET"), minDecimals: 3)), ("Gross", PkgFmt.num(r.s("GROSS"), minDecimals: 3))])
                    PkgFlagsBand(flags: [("SHORT", flag("REPORT_SHORT")), ("OVER", flag("REPORT_OVER")), ("DMG", flag("REPORT_DMG")), ("MISSING", flag("REPORT_MISSING"))])
                    PkgBigButton(title: "Lịch sử thay đổi vị trí") { showLog = true }
                    docsSection
                    itemsSection
                }
                .padding(.horizontal, 14).padding(.top, 8).padding(.bottom, 100)
            }
        }
        .navigationTitle("Package")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    PkgActionMenuItems(ops: ops, rows: [r])
                } label: {
                    Image(systemName: "ellipsis.circle").font(.system(size: 19, weight: .semibold))
                }
            }
        }
        .navigationDestination(isPresented: Binding(get: { openItem != nil }, set: { if !$0 { openItem = nil } })) {
            if let it = openItem {
                PkgItemView(model: model, pkg: r, item: it, onOpenDoc: onOpenDoc, onSaved: { vm.loadItems(model) }, dvm: vm, onLocUpdate: { itemLocUpdate([$0]) }, onLocDelete: { it in vm.deleteItemLocation(model, items: [it]) { vm.loadItems(model) } })
            }
        }
        .navigationDestination(isPresented: $showLog) {
            PkgLocLogView(model: model, vm: vm)
        }
        .sheet(item: $locTarget) { t in
            PkgLocationSheet(model: model, target: t, onSaved: {
                listVM.notice = "Đã cập nhật vị trí \(t.names.count) \(t.noun) ✓"
                listVM.reload(model)
                vm.loadItems(model)
            })
            .desmSheet(shot: false)
        }
        .desmDialog(dialog) { dialog = nil }
        .onAppear {
            if vm.items.isEmpty && !vm.itemsLoading { vm.loadItems(model) }
            if vm.docs.isEmpty && !vm.docsLoading { vm.loadDocs(model) }
        }
    }
}

// MARK: - Lịch sử thay đổi vị trí của kiện

struct PkgLocLogView: View {
    @ObservedObject var model: BrowserModel
    @ObservedObject var vm: PackageDetailVM

    var body: some View {
        ZStack {
            PkgBackground()
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 12) {
                    Text(vm.row.no).font(.system(size: 22, weight: .heavy))
                    if let n = vm.logNote { Text(n).font(.system(size: 15)).foregroundStyle(.secondary) }
                    if vm.logLoading { ProgressView() }
                    ForEach(Array(vm.logRows.enumerated()), id: \.offset) { e in
                        let g = e.element
                        VStack(alignment: .leading, spacing: 5) {
                            HStack {
                                Text(g.date.isEmpty ? "-" : g.date).font(.system(size: 17, weight: .heavy))
                                Spacer()
                                Text(g.by.isEmpty ? "-" : g.by).font(.system(size: 15)).foregroundStyle(.secondary)
                            }
                            HStack(spacing: 6) {
                                Image(systemName: "mappin.and.ellipse").foregroundStyle(Color.tabBlue)
                                Text((g.from.isEmpty ? "(ban đầu)" : g.from) + " → " + (g.to.isEmpty ? "-" : g.to)).font(.system(size: 16, weight: .semibold))
                            }
                            Text("\(g.labels.count) hạng mục: " + g.labels.prefix(3).joined(separator: " · ") + (g.labels.count > 3 ? " …" : ""))
                                .font(.system(size: 14)).foregroundStyle(.secondary)
                        }
                        .padding(14).frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color(.secondarySystemGroupedBackground))
                        .overlay(alignment: .leading) { Rectangle().fill(Color.tabBlue).frame(width: 6) }
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                }
                .padding(14).padding(.bottom, 80)
            }
        }
        .navigationTitle("Lịch sử vị trí")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { if vm.logRows.isEmpty && !vm.logLoading { vm.loadLocLog(model) } }
    }
}

// MARK: - Detail Item: thông tin, số lượng, SHORT/OVER/DMG/MISSING + Remarks (SAVE), RSI & MRF của hạng mục

final class PkgItemVM: ObservableObject {
    let pkg: PkgRow
    let item: PkgItem
    @Published var flagOn: [Bool]
    @Published var flagQty: [String]
    @Published var remarks: String
    @Published var saving = false
    @Published var message: String? = nil
    @Published var isError = false
    @Published var docs: [PkgDoc] = []
    @Published var docsLoading = false
    @Published var docsNote: String? = nil

    static let keys = ["REPORT_SHORT", "REPORT_OVER", "REPORT_DMG", "REPORT_MISSING"]
    static let names = ["SHORT", "OVER", "DMG", "MISSING"]

    init(pkg: PkgRow, item: PkgItem) {
        self.pkg = pkg; self.item = item
        var on: [Bool] = [], q: [String] = []
        for k in PkgItemVM.keys {
            let flagV = PkgFmt.dbl(item.s(k)), qty = PkgFmt.dbl(item.s(k + "_QTY"))
            on.append(flagV > 0 || qty > 0)
            q.append(qty > 0 ? PkgFmt.num(qty) : "")
        }
        flagOn = on; flagQty = q; remarks = item.s("REMARKS")
    }

    /// Kiểm tra + dựng dòng gửi /saveIdsmOsDetailList.do (giống diSave/nút SAVE trên web). Trả (list JSON, before JSON) hoặc lỗi.
    func build() -> (json: String, before: String, error: String?) {
        let it = item
        var vals: [String: Any] = [:]
        for (i, k) in PkgItemVM.keys.enumerated() {
            let on = flagOn[i]
            let q = on ? PkgFmt.dbl(flagQty[i]) : 0
            if on && q <= 0 { return ("", "", "Nhập số lượng > 0 cho \(PkgItemVM.names[i]).") }
            let orig = it.s(k + "_QTY")
            if on { vals[k] = q } else if orig.isEmpty { vals[k] = "" } else { vals[k] = 0 }
        }
        let rsiQ = PkgFmt.dbl(it.s("RSI_QTY")), mrfQ = PkgFmt.dbl(it.s("MRF_QTY")), inQ = it.inQ
        if inQ < (rsiQ - mrfQ) { return ("", "", "In Q'ty nhỏ hơn (RSI Q'ty − MRF Q'ty), không thể lưu.") }
        func num(_ k: String) -> Double { (vals[k] as? Double) ?? Double((vals[k] as? Int) ?? 0) }
        var row: [String: Any] = [
            "PROJECT_NO": it.s("PROJECT_NO").isEmpty ? pkg.project : it.s("PROJECT_NO"),
            "TRK_ITEM_NAME": it.s("TRK_ITEM_NAME"), "PACKAGE_NO": it.s("PACKAGE_NO"), "MATERIAL_CODE": it.material,
            "ITEM_SIZE": it.s("ITEM_SIZE"), "DESCRIPTION": it.desc, "DRAWING_NO": it.s("DRAWING_NO"), "LOCATION": it.loc,
            "TAG_NO": it.s("TAG_NO"), "UNIT": it.unit, "MATERIAL": it.s("MATERIAL"), "REMARKS": remarks
        ]
        if it.s("IN_QTY").isEmpty { row["IN_QTY"] = "" } else { row["IN_QTY"] = inQ }
        for k in PkgItemVM.keys {
            row[k] = num(k) > 0 ? "1" : "0"
            row[k + "_QTY"] = vals[k] ?? ""
        }
        var before: [String: Any] = ["PACKAGE_NO": it.s("PACKAGE_NO"), "MATERIAL_CODE": it.material, "TRK_ITEM_NAME": it.s("TRK_ITEM_NAME"), "REMARKS": it.s("REMARKS")]
        for k in PkgItemVM.keys { before[k] = it.s(k); before[k + "_QTY"] = it.s(k + "_QTY") }
        let beforeJSON: String = {
            guard JSONSerialization.isValidJSONObject(before), let d = try? JSONSerialization.data(withJSONObject: before),
                  let s = String(data: d, encoding: .utf8) else { return "" }
            return s
        }()
        return (PkgFmt.json([row]), beforeJSON, nil)
    }

    func save(_ model: BrowserModel, done: @escaping () -> Void) {
        if saving { return }
        let b = build()
        if let e = b.error { message = e; isError = true; return }
        saving = true; message = "Đang lưu…"; isError = false
        Task { @MainActor in
            let aid = WriteAuditStore.begin(label: "Hạng mục chi tiết (Save) — Package", path: "/saveIdsmOsDetailList.do", payload: b.json, before: b.before)
            do {
                let obj = try await model.desmPostObject("/saveIdsmOsDetailList.do", body: "list=\(BrowserModel.enc(b.json))")
                var text = ""
                if JSONSerialization.isValidJSONObject(obj), let d = try? JSONSerialization.data(withJSONObject: obj) { text = String(data: d, encoding: .utf8) ?? "" }
                let e = obj["error"]
                if e == nil || e is NSNull {
                    WriteAuditStore.finish(id: aid, status: "ok", response: text)
                    self.message = "Đã lưu ✓"; self.isError = false
                    done()
                } else {
                    WriteAuditStore.finish(id: aid, status: "rejected", response: text, error: "\(e!)")
                    self.message = "Lưu thất bại: \(e!)"; self.isError = true
                }
            } catch let err {
                var notSent = false
                if let de = err as? DesmAPIError {
                    switch de {
                    case .noSession, .expired: notSent = true
                    default: notSent = false
                    }
                }
                WriteAuditStore.finish(id: aid, status: notSent ? "notsent" : "unknown", error: err.localizedDescription)
                self.message = "Lưu thất bại: \(err.localizedDescription)" + (notSent ? "" : " Hãy kiểm tra trên web xem đã lưu chưa.")
                self.isError = true
            }
            self.saving = false
        }
    }

    /// RSI + MRF của hạng mục này trong kiện (lọc theo Material Code và Package No)
    func loadDocs(_ model: BrowserModel) {
        if docsLoading { return }
        docsLoading = true; docsNote = nil
        Task { @MainActor in
            var out: [PkgDoc] = []
            var failed = false
            let e = BrowserModel.enc
            let mat = item.material
            do {
                var pj = pkg.project
                if pj.isEmpty { pj = try await model.desmProjectNo() }
                let rsiBody = "PAGE_NUM=1&PAGE_CNT=5000&PROJECT_NO=\(e(pj))&RSI_NO=&RSI_NAME=&SUBCONTRACTOR=&ATTRIBUTE10=&MATERIAL_CODE=\(e(mat))&START_REQUEST_DATE=&END_REQUEST_DATE=&BALANCE_QTY=&TYPE=&CATEGORY=&SUB_CATEGORY=&PACKING_LIST_NO=&PACKAGE_NO=\(e(pkg.no))&ITEM_DESC=&MASTER_SHOP_UNIT=&MASTER_SHOP_BLDG=&SHOP_UNIT=&SHOP_BLDG="
                if let l = try? await model.desmQueryAsync("/getDesmRsiViewList.do", body: rsiBody) {
                    var order: [String] = []; var map: [String: PkgDoc] = [:]
                    for r in l where PkgFmt.str(r, "MATERIAL_CODE") == mat && PkgFmt.str(r, "PACKAGE_NO") == pkg.no {
                        let no = PkgFmt.str(r, "RSI_NO"); if no.isEmpty { continue }
                        var d = map[no] ?? PkgDoc(id: no)
                        if map[no] == nil { order.append(no) }
                        d.lines += 1; d.qty += BrowserModel.fnum(r, "REQ_QTY")
                        if d.status.isEmpty { d.status = PkgFmt.str(r, "STATUS") }
                        if d.name.isEmpty { d.name = PkgFmt.str(r, "RSI_NAME") }
                        if d.sub.isEmpty { d.sub = PkgFmt.str(r, "SUBCONTRACTOR") }
                        if d.date.isEmpty { d.date = PkgFmt.str(r, "RSI_APPROVED_DATE").isEmpty ? PkgFmt.str(r, "REQUEST_DATE") : PkgFmt.str(r, "RSI_APPROVED_DATE") }
                        if d.unit.isEmpty { d.unit = PkgFmt.str(r, "UNIT") }
                        map[no] = d
                    }
                    for k in order { if let d = map[k] { out.append(d) } }
                } else { failed = true }
                let mrfBody = "PROJECT_NO=\(e(pj))&RSI_NO=&RSI_NAME=&SUBCONTRACTOR=&MATERIAL_CODE=\(e(mat))&RSI_START_REQUEST_DATE=&RSI_END_REQUEST_DATE=&ZIM_ATTRIBUTE10=&RSI_BALANCE_QTY=&TYPE=&CATEGORY=&SUB_CATEGORY=&PACKING_LIST_NO=&MRF_NO=&MRF_NAME=&PACKAGE_NO=\(e(pkg.no))&ITEM_DESC=&RETURN_TYPE=&MRF_BALANCE_QTY="
                if let l = try? await model.desmQueryAsync("/getMrfSummaryList.do", body: mrfBody) {
                    var order: [String] = []; var map: [String: PkgDoc] = [:]
                    for r in l where PkgFmt.str(r, "MATERIAL_CODE") == mat && PkgFmt.str(r, "PACKAGE_NO") == pkg.no {
                        let no = PkgFmt.str(r, "MRF_NO"); if no.isEmpty { continue }
                        var d = map[no] ?? PkgDoc(id: no, isMrf: true)
                        if map[no] == nil { order.append(no) }
                        d.lines += 1; d.qty += BrowserModel.fnum(r, "MRF_REQ_RETURN_QTY")
                        if d.status.isEmpty { d.status = PkgFmt.str(r, "STATUS") }
                        if d.name.isEmpty { d.name = PkgFmt.str(r, "MRF_NAME") }
                        if d.sub.isEmpty { d.sub = PkgFmt.str(r, "SUBCONTRACTOR") }
                        if d.date.isEmpty { d.date = PkgFmt.str(r, "RETURN_REQ_DATE") }
                        if d.unit.isEmpty { d.unit = PkgFmt.str(r, "UNIT") }
                        map[no] = d
                    }
                    for k in order { if let d = map[k] { out.append(d) } }
                } else { failed = true }
            } catch let err { self.docsNote = err.localizedDescription }
            self.docs = out
            if out.isEmpty && self.docsNote == nil {
                self.docsNote = failed ? "Không tải được danh sách RSI/MRF." : "Hạng mục này chưa có phiếu RSI hoặc MRF."
            }
            self.docsLoading = false
        }
    }
}

struct PkgItemView: View {
    @ObservedObject var model: BrowserModel
    let pkg: PkgRow
    let item: PkgItem
    var onOpenDoc: (DesmDocKind, String) -> Void
    var onSaved: () -> Void
    @ObservedObject var dvm: PackageDetailVM
    var onLocUpdate: (PkgItem) -> Void = { _ in }
    var onLocDelete: (PkgItem) -> Void = { _ in }

    @StateObject private var vm: PkgItemVM
    @State private var showDocs = true
    @State private var dialog: DesmDialogState? = nil

    init(model: BrowserModel, pkg: PkgRow, item: PkgItem, onOpenDoc: @escaping (DesmDocKind, String) -> Void, onSaved: @escaping () -> Void, dvm: PackageDetailVM, onLocUpdate: @escaping (PkgItem) -> Void = { _ in }, onLocDelete: @escaping (PkgItem) -> Void = { _ in }) {
        self.model = model; self.pkg = pkg; self.item = item; self.onOpenDoc = onOpenDoc; self.onSaved = onSaved
        self.dvm = dvm
        self.onLocUpdate = onLocUpdate; self.onLocDelete = onLocDelete
        _vm = StateObject(wrappedValue: PkgItemVM(pkg: pkg, item: item))
    }

    var canEdit: Bool { item.canEdit }

    func q(_ k: String) -> String { PkgFmt.num(item.s(k)) }

    var infoCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(item.s("PACKAGE_NO").isEmpty ? pkg.no : item.s("PACKAGE_NO")).font(.system(size: 24, weight: .heavy))
            Text("ITEM : " + (item.desc.isEmpty ? "-" : item.desc)).font(.system(size: 20))
            Text("DWG : " + (item.s("DRAWING_NO").isEmpty ? "N/A" : item.s("DRAWING_NO"))).font(.system(size: 20))
            Text("TAG : " + (item.s("TAG_NO").isEmpty ? "N/A" : item.s("TAG_NO"))).font(.system(size: 20))
            Text("Net Weight(Kg) : " + q("NET")).font(.system(size: 20))
            Text((item.material.isEmpty ? "-" : item.material) + " / " + (item.unit.isEmpty ? "-" : item.unit)).font(.system(size: 20))
            Text("Location : " + (item.loc.isEmpty ? "-" : item.loc)).font(.system(size: 20))
        }
        .padding(16).frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
        .shadow(color: Color.tabBlue.opacity(0.10), radius: 8, y: 3)
    }

    var editCard: some View {
        VStack(spacing: 12) {
            HStack(alignment: .top, spacing: 8) {
                ForEach(0..<4, id: \.self) { i in
                    VStack(spacing: 8) {
                        Text(PkgItemVM.names[i]).font(.system(size: 14, weight: .heavy))
                        Button {
                            if !canEdit { return }
                            vm.flagOn[i].toggle()
                            if !vm.flagOn[i] { vm.flagQty[i] = "" }
                        } label: {
                            Image(systemName: vm.flagOn[i] ? "checkmark.square.fill" : "square")
                                .font(.system(size: 28)).foregroundStyle(vm.flagOn[i] ? Color.red : Color(.tertiaryLabel))
                        }
                        .buttonStyle(.plain)
                        TextField("Q'ty", text: $vm.flagQty[i])
                            .keyboardType(.decimalPad).multilineTextAlignment(.center)
                            .disabled(!canEdit || !vm.flagOn[i])
                            .font(.system(size: 16, weight: .semibold))
                            .padding(.vertical, 10)
                            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color(.tertiarySystemFill)))
                            .opacity(canEdit && vm.flagOn[i] ? 1 : 0.5)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            TextField("Remarks", text: $vm.remarks, axis: .vertical)
                .lineLimit(3...6)
                .disabled(!canEdit)
                .font(.system(size: 17))
                .padding(14)
                .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.tabBlue.opacity(0.25), lineWidth: 1))
                .opacity(canEdit ? 1 : 0.6)
            if !item.s("COMMENTS").isEmpty {
                Text("Note: " + item.s("COMMENTS")).font(.system(size: 14)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
            }
            Button {
                dialog = DesmDialogState(icon: "square.and.arrow.down.fill", title: "Lưu hạng mục", message: "Lưu thay đổi của hạng mục \(item.material) lên DESM?", actions: [
                    DesmDialogAction(title: "SAVE", kind: .primary) { vm.save(model) { onSaved() } },
                    DesmDialogAction(title: "Huỷ", kind: .cancel)
                ])
            } label: {
                HStack {
                    if vm.saving { ProgressView().tint(.white) }
                    Text("SAVE").font(.system(size: 19, weight: .heavy))
                }
                .foregroundStyle(.white).frame(maxWidth: .infinity, minHeight: 54)
                .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(canEdit ? Color.tabBlue : Color(.systemGray3)))
            }
            .buttonStyle(.plain)
            .disabled(!canEdit || vm.saving)
            if let m = vm.message {
                Text(m).font(.system(size: 14, weight: .semibold)).foregroundStyle(vm.isError ? Color.red : Color(red: 0.12, green: 0.50, blue: 0.25))
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else if !canEdit {
                Text(item.s("TRK_ITEM_NAME").isEmpty ? "Chưa tải đủ dữ liệu hạng mục nên chưa thể lưu." : "Hạng mục chưa được xác nhận (Confirm Material) nên không sửa được.")
                    .font(.system(size: 14)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    var body: some View {
        ZStack(alignment: .top) {
            PkgBackground()
            ScrollView {
                LazyVStack(spacing: 12) {
                    infoCard
                    PkgBand(cells: [("In Q'ty", q("IN_QTY")), ("Out Q'ty", q("OUT_QTY")), ("Remain", q("REMAIN_QTY")), ("RSI Q'ty", q("RSI_QTY"))])
                    PkgBand(cells: [("RSI Bal.", q("BALANCE_QTY")), ("MRF Q'ty", q("MRF_QTY")), ("MRF Bal.", q("MRF_BALANCE_QTY")), ("Cancel", q("RSI_CANCEL_QTY"))])
                    editCard
                    HStack(spacing: 10) {
                        PkgPill(icon: "mappin.and.ellipse", title: "Location Update", tint: Color.tabBlue, fill: true) { onLocUpdate(item) }
                        PkgPill(icon: "mappin.slash", title: "Xoá vị trí", tint: Color.red, fill: true) {
                            dialog = DesmDialogState(icon: "mappin.slash", title: "Xoá vị trí hạng mục", message: "Xoá vị trí của hạng mục \(item.material) trên DESM? Thao tác này không tự hoàn tác được.", actions: [
                                DesmDialogAction(title: "Xoá vị trí", kind: .destructive) { onLocDelete(item) },
                                DesmDialogAction(title: "Huỷ", kind: .cancel)
                            ])
                        }
                    }
                    .frame(maxWidth: .infinity)
                    if let n = dvm.actionNote {
                        Text(n).font(.system(size: 14, weight: .semibold)).foregroundStyle(dvm.actionIsError ? Color.red : Color(red: 0.12, green: 0.50, blue: 0.25))
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    VStack(spacing: 10) {
                        PkgBigButton(title: "RSI & MRF List", trailing: showDocs ? "arrow.up" : "arrow.down") { withAnimation { showDocs.toggle() } }
                        if showDocs {
                            if vm.docsLoading { ProgressView("Đang tải RSI & MRF…").padding(.vertical, 8) }
                            else if vm.docs.isEmpty, let n = vm.docsNote { Text(n).font(.system(size: 15)).foregroundStyle(.secondary).padding(.vertical, 6) }
                            ForEach(vm.docs) { d in
                                PkgDocCard(doc: d) { onOpenDoc(d.isMrf ? .mrf : .rsi, d.id) }
                            }
                        }
                    }
                }
                .padding(.horizontal, 14).padding(.top, 8).padding(.bottom, 100)
            }
            .pkgKeyboardDismiss()
        }
        .navigationTitle("Detail Item")
        .navigationBarTitleDisplayMode(.inline)
        .desmDialog(dialog) { dialog = nil }
        .onAppear { if vm.docs.isEmpty && !vm.docsLoading { vm.loadDocs(model) } }
    }
}
