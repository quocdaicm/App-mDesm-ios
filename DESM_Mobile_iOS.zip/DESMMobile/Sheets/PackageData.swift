// PackageData.swift — dữ liệu, API và ViewModel của màn "Package" native (Thêm > Package).
//
// Làm theo trang web DESM "Package" (menu 196, script reference/plSummary.js) và màn chi tiết kiện đã có ở JSDetail.swift.
//   ĐỌC : /getIdsmOsSummaryList.do (danh sách kiện), /getVoyageList.do, /getLocationCodeList.do,
//         /getIdsmOsDetailList.do (hạng mục của kiện), /getDesmRsiViewList.do + /getMrfSummaryList.do (RSI & MRF của kiện),
//         /getDesmMapCreationList.do + /getDesmMapInfoList.do (bản đồ + ô vị trí)
//   GHI : /saveIdsmOsSummaryListConfirmMaterial.do, /saveIdsmOsSummaryListCancelMaterial.do, /saveIdsmOsSummaryListCustoms.do,
//         /deleteDesmLocation.do, /saveDesmLocationCheck.do + /saveDesmLocation.do, /saveIdsmOsDetailList.do (SAVE hạng mục)
// Mọi lệnh ghi: hộp thoại xác nhận trước, ghi vào "Nhật ký thao tác ghi" (WriteAuditStore), xong thì nạp lại.
// CHƯA build Xcode / chưa thử máy thật. Lệnh ghi chỉ có saveDesmLocationCheck/saveDesmLocation từng có log chạy thật;
// các lệnh còn lại làm theo mã nguồn web (plSummary.js) — hãy thử trên kiện test trước.

import SwiftUI

// MARK: - Gọi API trả về OBJECT (lệnh ghi, bản đồ) — desmQueryAsync chỉ đọc được mảng dòng

private let pkgHTTP: URLSession = {
    let cfg = URLSessionConfiguration.ephemeral
    cfg.httpShouldSetCookies = false
    cfg.timeoutIntervalForRequest = 25
    cfg.timeoutIntervalForResource = 40
    return URLSession(configuration: cfg)
}()

extension BrowserModel {
    /// POST form tới một endpoint .do, trả về JSON dạng object (không ép phải có `results`).
    @MainActor
    func desmPostObject(_ path: String, body: String) async throws -> [String: Any] {
        guard let base = URL(string: BrowserModel.apiOrigin), let url = URL(string: path, relativeTo: base)?.absoluteURL,
              url.host?.lowercased().hasSuffix("doosanenerbility.com") == true else { throw DesmAPIError.message("Địa chỉ không hợp lệ.") }
        let cookies = await desmCookies()
        guard !cookies.isEmpty else { throw DesmAPIError.noSession }
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 25)
        req.httpMethod = "POST"
        req.httpBody = body.data(using: .utf8)
        req.allHTTPHeaderFields = HTTPCookie.requestHeaderFields(with: cookies)
        req.setValue("application/x-www-form-urlencoded; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        req.setValue("XMLHttpRequest", forHTTPHeaderField: "X-Requested-With")
        req.setValue(BrowserModel.apiOrigin, forHTTPHeaderField: "Origin")
        req.setValue(BrowserModel.homeURL, forHTTPHeaderField: "Referer")
        let data: Data
        let resp: URLResponse
        do {
            let r = try await pkgHTTP.data(for: req)
            data = r.0; resp = r.1
        } catch {
            throw DesmAPIError.network(error.localizedDescription)
        }
        guard let http = resp as? HTTPURLResponse else { throw DesmAPIError.unreadable }
        if http.statusCode == 401 { throw DesmAPIError.expired }
        if http.url?.path.lowercased().contains("login") == true { throw DesmAPIError.expired }
        guard let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { throw DesmAPIError.notJSON(http.statusCode) }
        return obj
    }

    /// Lệnh GHI có nhật ký. Trả (thành công?, phản hồi, thông báo lỗi). `error` ở cấp trên của phản hồi = bị từ chối.
    @MainActor
    func desmWriteForm(_ path: String, body: String, label: String, payload: String) async -> (ok: Bool, obj: [String: Any], err: String) {
        let aid = WriteAuditStore.begin(label: label, path: path, payload: payload)
        do {
            let obj = try await desmPostObject(path, body: body)
            var text = ""
            if JSONSerialization.isValidJSONObject(obj), let d = try? JSONSerialization.data(withJSONObject: obj) { text = String(data: d, encoding: .utf8) ?? "" }
            let e = obj["error"]
            if e == nil || e is NSNull {
                WriteAuditStore.finish(id: aid, status: "ok", response: text)
                return (true, obj, "")
            }
            WriteAuditStore.finish(id: aid, status: "rejected", response: text, error: "\(e!)")
            return (false, obj, "\(e!)")
        } catch {
            var notSent = false
            if let de = error as? DesmAPIError {
                switch de {
                case .noSession, .expired: notSent = true
                default: notSent = false
                }
            }
            WriteAuditStore.finish(id: aid, status: notSent ? "notsent" : "unknown", error: error.localizedDescription)
            let hint = notSent ? "" : " Hãy kiểm tra trên web xem đã lưu chưa trước khi thử lại."
            return (false, [:], error.localizedDescription + hint)
        }
    }
}

// MARK: - Định dạng

enum PkgFmt {
    static let numFmt: NumberFormatter = {
        let f = NumberFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.numberStyle = .decimal
        f.usesGroupingSeparator = true
        f.groupingSeparator = ","
        f.minimumFractionDigits = 0
        f.maximumFractionDigits = 3
        return f
    }()
    static let timeFmt: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "HH:mm"
        return f
    }()
    static let dateFmt: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy/MM/dd"
        return f
    }()

    static func num(_ v: Double) -> String { numFmt.string(from: NSNumber(value: v)) ?? String(v) }
    /// "620.000" / "3,375.000" / "" -> "620" ; không phải số thì giữ nguyên, rỗng thì "-"
    static func num(_ s: String, minDecimals: Int = 0) -> String {
        let t = s.replacingOccurrences(of: ",", with: "").trimmingCharacters(in: .whitespaces)
        if t.isEmpty { return "-" }
        guard let v = Double(t) else { return s }
        if minDecimals > 0 {
            let f = NumberFormatter()
            f.locale = Locale(identifier: "en_US_POSIX"); f.numberStyle = .decimal
            f.minimumFractionDigits = minDecimals; f.maximumFractionDigits = 3
            return f.string(from: NSNumber(value: v)) ?? s
        }
        return num(v)
    }
    static func dbl(_ s: String) -> Double {
        Double(s.replacingOccurrences(of: ",", with: "").trimmingCharacters(in: .whitespaces)) ?? 0
    }
    /// "2026/06/17 10:20:11" -> "2026/06/17"
    static func day(_ s: String) -> String { String(s.prefix(10)) }
    static func csvCell(_ s: String) -> String {
        if s.contains(",") || s.contains("\"") || s.contains("\n") { return "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\"" }
        return s
    }
    static func str(_ r: [String: Any], _ k: String) -> String { BrowserModel.fstr(r, k) }
    static func strMap(_ r: [String: Any]) -> [String: String] {
        var o: [String: String] = [:]
        for (k, v) in r {
            if let s = v as? String { o[k] = s.trimmingCharacters(in: .whitespacesAndNewlines) }
            else if let n = v as? NSNumber { o[k] = n.stringValue }
        }
        return o
    }
    static func json(_ arr: [[String: Any]]) -> String {
        guard JSONSerialization.isValidJSONObject(arr), let d = try? JSONSerialization.data(withJSONObject: arr),
              let s = String(data: d, encoding: .utf8) else { return "[]" }
        return s
    }
}

// MARK: - Một kiện (một dòng của /getIdsmOsSummaryList.do)

enum PkgStock { case open, done, unknown }

struct PkgRow: Identifiable {
    let id: Int                    // thứ tự gốc máy chủ trả về
    let raw: [String: String]
    let total: Double
    let shipped: Double
    let hasQty: Bool

    init(id: Int, raw: [String: String]) {
        self.id = id
        self.raw = raw
        let parts = (raw["OUT_STATUS_QTY"] ?? "").split(separator: "/").map { PkgFmt.dbl(String($0)) }
        if parts.count >= 2 {
            self.total = parts[0]; self.shipped = parts[1]; self.hasQty = true
        } else {
            self.total = 0; self.shipped = 0; self.hasQty = false
        }
    }

    func s(_ k: String) -> String { raw[k] ?? "" }
    var no: String { s("PACKAGE_NO") }
    var plNo: String { s("PACKAGE_LIST_NO") }
    var desc: String { s("DESCRIPTION") }
    var loc: String { s("STORAGE_LOCATION") }
    var project: String { s("PROJECT_NO") }
    var trk: String { s("TRK_ITEM_NAME") }
    var remaining: Double { total - shipped }
    var stock: PkgStock {
        if !hasQty || total <= 0 { return .unknown }
        return remaining > 0.0005 ? .open : .done
    }
    /// CLOSE / N/A … như màn chi tiết web (PACKAGE_STATUS, thiếu thì đã xuất hết = CLOSE)
    var statusText: String {
        let st = s("PACKAGE_STATUS")
        if !st.isEmpty { return st }
        return stock == .done ? "CLOSE" : "N/A"
    }
    var isClose: Bool { statusText.uppercased().contains("CLOSE") }
    var lines: String { s("OUT_STATUS") }
    var qtyText: String { hasQty ? PkgFmt.num(total) + "/" + PkgFmt.num(shipped) : "" }
    /// Chỉ hiện "Remaining" khi đã xuất (số đã xuất > 0), như web
    var showRemaining: Bool { hasQty && shipped > 0 }
    var customs: String { s("CUSTOMS_YN").isEmpty ? "N" : s("CUSTOMS_YN") }
    var confirmed: Bool { !s("CONFIRM_DATE").isEmpty }
    var locDate: String { s("LOC_UPDATE_DATE") }

    /// Phần tử gửi cho các API ghi (list)
    func param(code: String? = nil, customs: String? = nil) -> [String: Any] {
        var d: [String: Any] = ["PROJECT_NO": project, "TRK_ITEM_NAME": trk, "PACKAGE_NO": no]
        if let c = code { d["CODE_TYPE"] = c }
        if let c = customs { d["CUSTOMS_YN"] = c }
        return d
    }
}

// MARK: - Bộ lọc gửi lên máy chủ (nút "Bộ lọc")

struct PkgFilter: Equatable {
    var desc = ""
    var confirm = ""        // IS_CONFIRM_MATERIAL: "", "Y", "N"
    var receipted = ""      // RECEIPTED
    var voyage = ""         // ATTRIBUTE10
    var remark = ""
    var vendor = ""
    var location = ""
    var recFrom: Date? = nil
    var recTo: Date? = nil
    var visual = ""         // MRR_VISUAL_CHECK (rỗng = All)
    var mrrReceived = ""    // MRR_RECEIVED
    var mrrFrom: Date? = nil
    var mrrTo: Date? = nil
    var customs = ""        // CUSTOMS_YN

    var count: Int {
        var n = 0
        for t in [desc, confirm, receipted, voyage, remark, vendor, location, visual, mrrReceived, customs] where !t.trimmingCharacters(in: .whitespaces).isEmpty { n += 1 }
        for d in [recFrom, recTo, mrrFrom, mrrTo] where d != nil { n += 1 }
        return n
    }
}

enum PkgSort: String, CaseIterable {
    case original = "Thứ tự gốc", noAsc = "Số kiện ↑", noDesc = "Số kiện ↓", recent = "Mới cập nhật"
}
struct PkgPL: Identifiable { let id: String; let count: Int; var name: String { id } }
enum PkgStockSel: String, CaseIterable { case all = "Tất cả", open = "Còn hàng", done = "Đã xuất hết" }

// MARK: - ViewModel danh sách

final class PackageVM: ObservableObject {
    // Ô tìm nhanh + bộ lọc
    @Published var plNo = ""
    @Published var pkgNo = ""
    @Published var filter = PkgFilter()
    @Published var voyages: [String] = []
    @Published var locations: [String] = []

    // Kết quả
    @Published var rows: [PkgRow] = []
    @Published var loading = false
    @Published var searched = false
    @Published var error: String? = nil
    @Published var notice: String? = nil
    @Published var busy = false
    @Published var lastSearch: Date? = nil

    // Lọc/sắp xếp phía máy (không gọi lại máy chủ)
    @Published var plSel: String? = nil
    @Published var stockSel: PkgStockSel = .all
    @Published var onlyNoLoc = false
    @Published var sort: PkgSort = .original
    @Published var selected = Set<Int>()

    var project = ""

    // MARK: Dữ liệu dẫn xuất

    /// Packing List theo thứ tự xuất hiện + số kiện
    var plCounts: [PkgPL] {
        var order: [String] = []; var map: [String: Int] = [:]
        for r in rows {
            let k = r.plNo.isEmpty ? "(không rõ)" : r.plNo
            if map[k] == nil { order.append(k); map[k] = 0 }
            map[k] = (map[k] ?? 0) + 1
        }
        return order.map { PkgPL(id: $0, count: map[$0] ?? 0) }
    }
    func stockCount(_ s: PkgStockSel) -> Int {
        let base = rows.filter { plSel == nil || ($0.plNo.isEmpty ? "(không rõ)" : $0.plNo) == plSel }
        switch s {
        case .all: return base.count
        case .open: return base.filter { $0.stock == .open }.count
        case .done: return base.filter { $0.stock == .done }.count
        }
    }
    var noLocCount: Int { rows.filter { $0.loc.isEmpty }.count }

    var shown: [PkgRow] {
        var list = rows
        if let p = plSel { list = list.filter { ($0.plNo.isEmpty ? "(không rõ)" : $0.plNo) == p } }
        switch stockSel {
        case .all: break
        case .open: list = list.filter { $0.stock == .open }
        case .done: list = list.filter { $0.stock == .done }
        }
        if onlyNoLoc { list = list.filter { $0.loc.isEmpty } }
        switch sort {
        case .original: break
        case .noAsc: list.sort { $0.no.localizedStandardCompare($1.no) == .orderedAscending }
        case .noDesc: list.sort { $0.no.localizedStandardCompare($1.no) == .orderedDescending }
        case .recent:
            list.sort { a, b in
                let x = a.locDate, y = b.locDate
                if x.isEmpty != y.isEmpty { return !x.isEmpty }
                if x != y { return x > y }
                return a.id < b.id
            }
        }
        return list
    }

    var selectedRows: [PkgRow] { rows.filter { selected.contains($0.id) } }

    func setAll(_ on: Bool) {
        if on { for r in shown { selected.insert(r.id) } }
        else { for r in shown { selected.remove(r.id) } }
    }
    /// Chỉ giữ chọn các kiện đang hiện (ghi/xoá/xác nhận chạy trên MỌI kiện đã chọn nên không để kiện ẩn lọt vào)
    func pruneSelection() {
        let ids = Set(shown.map { $0.id })
        selected = selected.intersection(ids)
    }
    func resetFilters() {
        plNo = ""; pkgNo = ""; filter = PkgFilter()
    }

    // MARK: Tải danh sách

    func search(_ model: BrowserModel) {
        if loading { return }
        loading = true; error = nil; notice = nil
        Task { @MainActor in
            do {
                let pj = try await model.desmProjectNo()
                self.project = pj
                let e = BrowserModel.enc
                let f = self.filter
                func d(_ x: Date?) -> String { x.map { PkgFmt.dateFmt.string(from: $0) } ?? "" }
                let visual = f.visual.trimmingCharacters(in: .whitespaces).isEmpty ? "All" : f.visual.trimmingCharacters(in: .whitespaces)
                var body = "PROJECT_NO=\(e(pj))"
                body += "&PACKAGE_LIST_NO=\(e(self.plNo.trimmingCharacters(in: .whitespaces)))"
                body += "&PACKAGE_NO=\(e(self.pkgNo.trimmingCharacters(in: .whitespaces)))"
                body += "&DESCRIPTION=\(e(f.desc))&IS_CONFIRM_MATERIAL=\(e(f.confirm))&RECEIPTED=\(e(f.receipted))"
                body += "&ATTRIBUTE10=\(e(f.voyage))&REMARK=\(e(f.remark))&VENDOR=\(e(f.vendor))&LOCATION=\(e(f.location))"
                body += "&START_RECEIPT_DATE=\(e(d(f.recFrom)))&END_RECEIPT_DATE=\(e(d(f.recTo)))"
                body += "&MRR_VISUAL_CHECK=\(e(visual))&MRR_RECEIVED=\(e(f.mrrReceived))"
                body += "&START_MRR_RECEIVED_DATE=\(e(d(f.mrrFrom)))&END_MRR_RECEIVED_DATE=\(e(d(f.mrrTo)))"
                body += "&CUSTOMS_YN=\(e(f.customs))&MIR_CATEGORY=&PACKAGE_STATUS="
                let list = try await model.desmQueryAsync("/getIdsmOsSummaryList.do", body: body)
                var out: [PkgRow] = []
                for r in list {
                    let m = PkgFmt.strMap(r)
                    if (m["PACKAGE_NO"] ?? "").isEmpty { continue }
                    out.append(PkgRow(id: out.count, raw: m))
                }
                self.rows = out
                self.selected = []
                self.plSel = nil; self.stockSel = .all; self.onlyNoLoc = false
                self.lastSearch = Date()
            } catch let err {
                self.error = err.localizedDescription
            }
            self.loading = false
            self.searched = true
        }
    }

    /// Nạp lại đúng điều kiện đang dùng, giữ nguyên lọc phía máy (sau khi ghi)
    func reload(_ model: BrowserModel) {
        let keepPl = plSel, keepStock = stockSel, keepNoLoc = onlyNoLoc, keepSort = sort
        let keepNote = notice
        search(model)
        Task { @MainActor in
            // chờ search xong rồi khôi phục bộ lọc phía máy
            for _ in 0..<80 {
                if !self.loading { break }
                try? await Task.sleep(nanoseconds: 250_000_000)
            }
            if let p = keepPl, self.plCounts.contains(where: { $0.name == p }) { self.plSel = p }
            self.stockSel = keepStock; self.onlyNoLoc = keepNoLoc; self.sort = keepSort
            if self.error == nil { self.notice = keepNote }
        }
    }

    func loadOptions(_ model: BrowserModel) {
        if !voyages.isEmpty && !locations.isEmpty { return }
        Task { @MainActor in
            guard let pj = try? await model.desmProjectNo() else { return }
            let e = BrowserModel.enc
            if self.voyages.isEmpty, let l = try? await model.desmQueryAsync("/getVoyageList.do", body: "p_project_code=\(e(pj))") {
                self.voyages = Array(Set(l.map { PkgFmt.str($0, "ATTRIBUTE10") }.filter { !$0.isEmpty })).sorted()
            }
            if self.locations.isEmpty, let l = try? await model.desmQueryAsync("/getLocationCodeList.do", body: "PROJECT_NO=\(e(pj))") {
                self.locations = Array(Set(l.map { PkgFmt.str($0, "NAME") }.filter { !$0.isEmpty })).sorted { $0.localizedStandardCompare($1) == .orderedAscending }
            }
        }
    }

    // MARK: Xuất CSV

    /// Xuất các kiện đang chọn; không chọn thì xuất toàn bộ danh sách đang hiện.
    func csv() -> (text: String, count: Int) {
        let src: [PkgRow] = selected.isEmpty ? shown : shown.filter { selected.contains($0.id) }
        let head = ["Package No", "Packing List", "Description", "Location", "Status", "Dòng xuất/tổng", "SL tổng", "SL đã xuất", "Còn lại",
                    "Package Type", "Remarks", "Received", "MRR Received", "V/C", "Customs", "Xác nhận", "Cập nhật vị trí"]
        var lines = [head.map { PkgFmt.csvCell($0) }.joined(separator: ",")]
        for r in src {
            let cells: [String] = [r.no, r.plNo, r.desc, r.loc, r.statusText, r.lines,
                                   r.hasQty ? PkgFmt.num(r.total) : "", r.hasQty ? PkgFmt.num(r.shipped) : "", r.hasQty ? PkgFmt.num(r.remaining) : "",
                                   r.s("PACKAGE_TYPE"), r.s("REMARKS"), PkgFmt.day(r.s("RECEIPT_DATE")), PkgFmt.day(r.s("MRR_RECEIVED_DATE")),
                                   r.s("VISUAL_CHECK"), r.customs, PkgFmt.day(r.s("CONFIRM_DATE")), r.locDate]
            lines.append(cells.map { PkgFmt.csvCell($0) }.joined(separator: ","))
        }
        return (lines.joined(separator: "\r\n"), src.count)
    }

    // MARK: Lệnh ghi trên các kiện đã chọn (mỗi lệnh đã được hỏi xác nhận ở giao diện)

    func confirmMaterial(_ model: BrowserModel, rows: [PkgRow]) {
        if rows.isEmpty || busy { return }
        busy = true; error = nil; notice = nil
        Task { @MainActor in
            let list = PkgFmt.json(rows.map { $0.param() })
            let r = await model.desmWriteForm("/saveIdsmOsSummaryListConfirmMaterial.do", body: "list=\(BrowserModel.enc(list))",
                                              label: "Package: Material Confirm (\(rows.count) kiện)", payload: list)
            self.busy = false
            if r.ok { self.notice = "Đã xác nhận \(rows.count) kiện ✓"; self.reload(model) }
            else { self.error = "Xác nhận thất bại: " + r.err }
        }
    }

    func cancelMaterial(_ model: BrowserModel, rows: [PkgRow]) {
        if rows.isEmpty || busy { return }
        busy = true; error = nil; notice = nil
        Task { @MainActor in
            let list = PkgFmt.json(rows.map { $0.param() })
            let r = await model.desmWriteForm("/saveIdsmOsSummaryListCancelMaterial.do", body: "list=\(BrowserModel.enc(list))",
                                              label: "Package: Material Cancel (\(rows.count) kiện)", payload: list)
            self.busy = false
            if r.ok { self.notice = "Đã hủy xác nhận \(rows.count) kiện ✓"; self.reload(model) }
            else if r.err == "RSI" {
                let p = (r.obj["PACKAGE_NO"] as? String) ?? ""
                self.error = "Kiện đã có RSI nên không hủy xác nhận được" + (p.isEmpty ? "." : " [Package No : \(p)].")
            } else { self.error = "Hủy xác nhận thất bại: " + r.err }
        }
    }

    func deleteLocation(_ model: BrowserModel, rows: [PkgRow]) {
        if rows.isEmpty || busy { return }
        busy = true; error = nil; notice = nil
        Task { @MainActor in
            let list = PkgFmt.json(rows.map { $0.param(code: "SUMMARY") })
            let r = await model.desmWriteForm("/deleteDesmLocation.do", body: "deleteList=\(BrowserModel.enc(list))",
                                              label: "Package: Location Delete (\(rows.count) kiện)", payload: list)
            self.busy = false
            if r.ok { self.notice = "Đã xoá vị trí \(rows.count) kiện ✓"; self.reload(model) }
            else { self.error = "Xoá vị trí thất bại: " + r.err }
        }
    }

    /// Customs Y/N: web chỉ cho đổi khi các kiện được chọn cùng giá trị; đổi N↔Y.
    func customsTarget(rows: [PkgRow]) -> String? {
        guard let first = rows.first else { return nil }
        if rows.contains(where: { $0.customs != first.customs }) { return nil }
        return first.customs == "N" ? "Y" : "N"
    }
    func setCustoms(_ model: BrowserModel, rows: [PkgRow], to value: String) {
        if rows.isEmpty || busy { return }
        busy = true; error = nil; notice = nil
        Task { @MainActor in
            let list = PkgFmt.json(rows.map { $0.param(customs: value) })
            let r = await model.desmWriteForm("/saveIdsmOsSummaryListCustoms.do", body: "list=\(BrowserModel.enc(list))",
                                              label: "Package: Customs → \(value) (\(rows.count) kiện)", payload: list)
            self.busy = false
            if r.ok { self.notice = "Đã đổi Customs → \(value) cho \(rows.count) kiện ✓"; self.reload(model) }
            else { self.error = "Đổi Customs thất bại: " + r.err }
        }
    }
}

// MARK: - Bản đồ vị trí (chọn ô để Location Update)

struct PkgMap: Identifiable { let id: String; let name: String; let path: String }
struct PkgCell: Identifiable { let id: String; let name: String }

enum PkgLocResult { case saved, failed(String) }

final class PkgLocationVM: ObservableObject {
    @Published var maps: [PkgMap] = []
    @Published var mapId = ""
    @Published var cells: [PkgCell] = []
    @Published var loadingMaps = false
    @Published var loadingCells = false
    @Published var error: String? = nil
    @Published var term = ""
    @Published var saving = false

    var filtered: [PkgCell] {
        let t = term.trimmingCharacters(in: .whitespaces).uppercased()
        if t.isEmpty { return cells }
        return cells.filter { $0.name.uppercased().contains(t) }
    }

    func loadMaps(_ model: BrowserModel) {
        if loadingMaps || !maps.isEmpty { return }
        loadingMaps = true; error = nil
        Task { @MainActor in
            do {
                let pj = try await model.desmProjectNo()
                let l = try await model.desmQueryAsync("/getDesmMapCreationList.do", body: "PROJECT_NO=\(BrowserModel.enc(pj))")
                self.maps = l.map { PkgMap(id: PkgFmt.str($0, "MAP_MST_ID"), name: PkgFmt.str($0, "MAP_NAME"), path: PkgFmt.str($0, "MAP_PATH")) }.filter { !$0.id.isEmpty }
                if let f = self.maps.first { self.mapId = f.id; self.loadCells(model) }
            } catch let err { self.error = err.localizedDescription }
            self.loadingMaps = false
        }
    }

    func loadCells(_ model: BrowserModel) {
        if mapId.isEmpty { return }
        loadingCells = true; error = nil; cells = []
        let id = mapId
        Task { @MainActor in
            do {
                let pj = try await model.desmProjectNo()
                let e = BrowserModel.enc
                let obj = try await model.desmPostObject("/getDesmMapInfoList.do", body: "PROJECT_NO=\(e(pj))&MAP_MST_ID=\(e(id))")
                var out: [PkgCell] = []
                if let res = obj["results"] as? [String: Any], let dtl = res["dtlInfo"] as? [[String: Any]] {
                    for d in dtl {
                        let cid = PkgFmt.str(d, "MAP_DTL_ID"), nm = PkgFmt.str(d, "MAP_NAME")
                        if !cid.isEmpty { out.append(PkgCell(id: cid, name: nm.isEmpty ? cid : nm)) }
                    }
                }
                out.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
                if self.mapId == id { self.cells = out }
            } catch let err { self.error = err.localizedDescription }
            self.loadingCells = false
        }
    }

    /// Bước 1: kiểm tra (saveDesmLocationCheck). Trả LOCATION_DIFF (khác null = kiện đang ở vị trí khác).
    @MainActor
    func check(_ model: BrowserModel, list: String, cell: PkgCell) async -> (diff: String?, err: String?) {
        let e = BrowserModel.enc
        do {
            let obj = try await model.desmPostObject("/saveDesmLocationCheck.do", body: "list=\(e(list))&MAP_MST_ID=\(e(mapId))&MAP_DTL_ID=\(e(cell.id))")
            if let d = obj["LOCATION_DIFF"], !(d is NSNull) { return ("\(d)", nil) }
            if let er = obj["error"], !(er is NSNull) { return (nil, "\(er)") }
            return (nil, nil)
        } catch let err { return (nil, err.localizedDescription) }
    }

    /// Bước 2: ghi vị trí (saveDesmLocation).
    @MainActor
    func save(_ model: BrowserModel, list: String, cell: PkgCell, count: Int) async -> PkgLocResult {
        let e = BrowserModel.enc
        let mapName = maps.first(where: { $0.id == mapId })?.name ?? mapId
        let r = await model.desmWriteForm("/saveDesmLocation.do", body: "list=\(e(list))&MAP_MST_ID=\(e(mapId))&MAP_DTL_ID=\(e(cell.id))",
                                          label: "Package: Location Update → \(mapName) / \(cell.name) (\(count) kiện)", payload: list)
        if r.ok { return .saved }
        if r.err == "qtyCheckErr" {
            let p = (r.obj["PACKAGE_NO"] as? String) ?? ""
            return .failed("Kiện có số lượng 0 nên không cập nhật được vị trí" + (p.isEmpty ? "." : " [Package No : \(p)]."))
        }
        return .failed("Không lưu được vị trí: " + r.err)
    }
}

// MARK: - Dữ liệu chi tiết một kiện (hạng mục + RSI/MRF)

struct PkgLogEv { var date: String; var by: String; var from: String; var to: String; var label: String }

struct PkgItem: Identifiable {
    let id: Int
    let raw: [String: String]
    func s(_ k: String) -> String { raw[k] ?? "" }
    var material: String { s("MATERIAL_CODE") }
    var desc: String { s("DESCRIPTION") }
    var unit: String { s("UNIT") }
    var loc: String { s("LOCATION") }
    var inQ: Double { PkgFmt.dbl(s("IN_QTY")) }
    var outQ: Double { PkgFmt.dbl(s("OUT_QTY")) }
    var remain: Double { s("REMAIN_QTY").isEmpty ? inQ - outQ : PkgFmt.dbl(s("REMAIN_QTY")) }
    var canEdit: Bool { !s("TRK_ITEM_NAME").isEmpty && s("IS_CONFIRM_MATERIAL").uppercased() == "Y" }
    /// Phần tử gửi cho Location Update/Delete cấp hạng mục (plDetail.js: CODE_TYPE = DETAIL)
    var param: [String: Any] {
        ["PROJECT_NO": s("PROJECT_NO"), "TRK_ITEM_NAME": s("TRK_ITEM_NAME"), "MATERIAL_CODE": material, "CODE_TYPE": "DETAIL"]
    }
}

struct PkgDoc: Identifiable {
    let id: String          // số phiếu
    var isMrf = false
    var status = "", name = "", sub = "", date = "", unit = ""
    var lines = 0
    var qty = 0.0
}

final class PackageDetailVM: ObservableObject {
    let row: PkgRow
    @Published var items: [PkgItem] = []
    @Published var itemsLoading = false
    @Published var itemsError: String? = nil
    @Published var docs: [PkgDoc] = []
    @Published var docsLoading = false
    @Published var docsError: String? = nil
    @Published var selectedItems = Set<Int>()
    @Published var logRows: [(date: String, by: String, from: String, to: String, labels: [String])] = []
    @Published var logLoading = false
    @Published var logNote: String? = nil
    @Published var actionNote: String? = nil
    @Published var actionIsError = false
    @Published var actionBusy = false

    init(row: PkgRow) { self.row = row }

    func proj(_ model: BrowserModel) async throws -> String {
        if !row.project.isEmpty { return row.project }
        return try await model.desmProjectNo()
    }

    static func detailBody(project: String, pkg: String) -> String {
        let e = BrowserModel.enc
        return "PAGE_NUM=1&PAGE_CNT=5000&PROJECT_NO=\(e(project))&PACKAGE_LIST_NO=&PACKAGE_NO=\(e(pkg))&DESCRIPTION=&DRAWING_NO=&TAG_NO=&QTY_TYPE=rsi&QTY=&KEY1=&VALUE1=&LOCATION=&SEQUENCE=&VENDOR=&ATTRIBUTE10=&TYPE=&CATEGORY=&SUB_CATEGORY=&COMMENTS="
    }

    func loadItems(_ model: BrowserModel) {
        if itemsLoading { return }
        itemsLoading = true; itemsError = nil
        Task { @MainActor in
            do {
                let pj = try await self.proj(model)
                let l = try await model.desmQueryAsync("/getIdsmOsDetailList.do", body: Self.detailBody(project: pj, pkg: row.no))
                var out: [PkgItem] = []
                for r in l {
                    let m = PkgFmt.strMap(r)
                    if (m["PACKAGE_NO"] ?? row.no) != row.no { continue }
                    out.append(PkgItem(id: out.count, raw: m))
                }
                self.items = out
                self.selectedItems = []
            } catch let err { self.itemsError = err.localizedDescription }
            self.itemsLoading = false
        }
    }

    /// Điều kiện của web: hạng mục có REMAIN_QTY = 0 thì không cập nhật được vị trí.
    func locationBlocked(_ items: [PkgItem]) -> String? {
        if items.isEmpty { return "Hãy chọn ít nhất một hạng mục trước." }
        if items.contains(where: { $0.s("TRK_ITEM_NAME").isEmpty }) { return "Thiếu TRK_ITEM_NAME của hạng mục nên chưa thao tác được." }
        if items.contains(where: { $0.remain <= 0 }) { return "Hạng mục có số lượng còn lại 0 nên không cập nhật vị trí được." }
        return nil
    }

    func deleteItemLocation(_ model: BrowserModel, items: [PkgItem], done: @escaping () -> Void) {
        if items.isEmpty || actionBusy { return }
        actionBusy = true; actionNote = nil
        Task { @MainActor in
            let list = PkgFmt.json(items.map { $0.param })
            let r = await model.desmWriteForm("/deleteDesmLocation.do", body: "deleteList=\(BrowserModel.enc(list))",
                                              label: "Package > Hạng mục: Location Delete (\(items.count))", payload: list)
            self.actionBusy = false
            if r.ok { self.actionNote = "Đã xoá vị trí \(items.count) hạng mục ✓"; self.actionIsError = false; done() }
            else { self.actionNote = "Xoá vị trí thất bại: " + r.err; self.actionIsError = true }
        }
    }

    func loadDocs(_ model: BrowserModel) {
        if docsLoading { return }
        docsLoading = true; docsError = nil
        Task { @MainActor in
            var out: [PkgDoc] = []
            var failed = false
            let e = BrowserModel.enc
            do {
                let pj = try await self.proj(model)
                let rsiBody = "PAGE_NUM=1&PAGE_CNT=5000&PROJECT_NO=\(e(pj))&RSI_NO=&RSI_NAME=&SUBCONTRACTOR=&ATTRIBUTE10=&MATERIAL_CODE=&START_REQUEST_DATE=&END_REQUEST_DATE=&BALANCE_QTY=&TYPE=&CATEGORY=&SUB_CATEGORY=&PACKING_LIST_NO=&PACKAGE_NO=\(e(row.no))&ITEM_DESC=&MASTER_SHOP_UNIT=&MASTER_SHOP_BLDG=&SHOP_UNIT=&SHOP_BLDG="
                if let l = try? await model.desmQueryAsync("/getDesmRsiViewList.do", body: rsiBody) {
                    var order: [String] = []; var map: [String: PkgDoc] = [:]
                    for r in l where PkgFmt.str(r, "PACKAGE_NO") == row.no {
                        let no = PkgFmt.str(r, "RSI_NO"); if no.isEmpty { continue }
                        var d = map[no] ?? PkgDoc(id: no)
                        if map[no] == nil { order.append(no) }
                        d.lines += 1
                        d.qty += BrowserModel.fnum(r, "REQ_QTY")
                        if d.status.isEmpty { d.status = PkgFmt.str(r, "STATUS") }
                        if d.name.isEmpty { d.name = PkgFmt.str(r, "RSI_NAME") }
                        if d.sub.isEmpty { d.sub = PkgFmt.str(r, "SUBCONTRACTOR") }
                        if d.date.isEmpty { d.date = PkgFmt.str(r, "RSI_APPROVED_DATE").isEmpty ? PkgFmt.str(r, "REQUEST_DATE") : PkgFmt.str(r, "RSI_APPROVED_DATE") }
                        if d.unit.isEmpty { d.unit = PkgFmt.str(r, "UNIT") }
                        map[no] = d
                    }
                    for k in order { if let d = map[k] { out.append(d) } }
                } else { failed = true }
                let mrfBody = "PROJECT_NO=\(e(pj))&RSI_NO=&RSI_NAME=&SUBCONTRACTOR=&MATERIAL_CODE=&RSI_START_REQUEST_DATE=&RSI_END_REQUEST_DATE=&ZIM_ATTRIBUTE10=&RSI_BALANCE_QTY=&TYPE=&CATEGORY=&SUB_CATEGORY=&PACKING_LIST_NO=&MRF_NO=&MRF_NAME=&PACKAGE_NO=\(e(row.no))&ITEM_DESC=&RETURN_TYPE=&MRF_BALANCE_QTY="
                if let l = try? await model.desmQueryAsync("/getMrfSummaryList.do", body: mrfBody) {
                    var order: [String] = []; var map: [String: PkgDoc] = [:]
                    for r in l where PkgFmt.str(r, "PACKAGE_NO") == row.no {
                        let no = PkgFmt.str(r, "MRF_NO"); if no.isEmpty { continue }
                        var d = map[no] ?? PkgDoc(id: no, isMrf: true)
                        if map[no] == nil { order.append(no) }
                        d.lines += 1
                        d.qty += BrowserModel.fnum(r, "MRF_REQ_RETURN_QTY")
                        if d.status.isEmpty { d.status = PkgFmt.str(r, "STATUS") }
                        if d.name.isEmpty { d.name = PkgFmt.str(r, "MRF_NAME") }
                        if d.sub.isEmpty { d.sub = PkgFmt.str(r, "SUBCONTRACTOR") }
                        if d.date.isEmpty { d.date = PkgFmt.str(r, "RETURN_REQ_DATE") }
                        if d.unit.isEmpty { d.unit = PkgFmt.str(r, "UNIT") }
                        map[no] = d
                    }
                    for k in order { if let d = map[k] { out.append(d) } }
                } else { failed = true }
            } catch let err { self.docsError = err.localizedDescription }
            self.docs = out
            if out.isEmpty && failed && self.docsError == nil { self.docsError = "Không tải được danh sách RSI/MRF." }
            self.docsLoading = false
        }
    }

    /// Lịch sử đổi vị trí của cả kiện: gom Edit Log của từng hạng mục, giữ các lần LOCATION đổi,
    /// gộp các hạng mục chuyển cùng lúc (cùng ngày, người, vị trí cũ → mới).
    func loadLocLog(_ model: BrowserModel) {
        if logLoading { return }
        logLoading = true; logNote = "Đang tải…"; logRows = []
        Task { @MainActor in
            do {
                let pj = try await self.proj(model)
                var list = items
                if list.isEmpty {
                    let l = try await model.desmQueryAsync("/getIdsmOsDetailList.do", body: Self.detailBody(project: pj, pkg: row.no))
                    list = l.enumerated().map { PkgItem(id: $0.offset, raw: PkgFmt.strMap($0.element)) }
                }
                let targets = list.filter { !$0.s("TRK_ITEM_NAME").isEmpty }
                if targets.isEmpty { self.logNote = "Kiện này chưa có hạng mục chi tiết để tra lịch sử."; self.logLoading = false; return }
                var events: [PkgLogEv] = []
                var failed = 0
                var done = 0
                for it in targets {
                    let body = "PROJECT_NO=\(BrowserModel.enc(it.s("PROJECT_NO").isEmpty ? pj : it.s("PROJECT_NO")))&TRK_ITEM_NAME=\(BrowserModel.enc(it.s("TRK_ITEM_NAME")))&MATERIAL_CODE=\(BrowserModel.enc(it.material))"
                    do {
                        let l = try await model.desmQueryAsync("/getDesmPlDetailEditLogList.do", body: body)
                        var rows = l.map { PkgFmt.strMap($0) }
                        rows.sort { ($0["CREATION_DATE_TXT"] ?? "") < ($1["CREATION_DATE_TXT"] ?? "") }
                        for (i, r) in rows.enumerated() {
                            let loc = r["LOCATION"] ?? "", prev = i > 0 ? (rows[i - 1]["LOCATION"] ?? "") : ""
                            let changed = i > 0 ? loc != prev : !loc.isEmpty
                            if changed {
                                events.append(PkgLogEv(date: r["CREATION_DATE_TXT"] ?? "", by: r["CREATED_BY"] ?? "", from: prev, to: loc,
                                                 label: it.material.isEmpty ? it.desc : it.material))
                            }
                        }
                    } catch { failed += 1 }
                    done += 1
                    self.logNote = "Đang tải… \(done)/\(targets.count)"
                }
                var order: [String] = []; var groups: [String: (e: PkgLogEv, labels: [String])] = [:]
                for e in events {
                    let k = [e.date, e.by, e.from, e.to].joined(separator: "|")
                    if groups[k] == nil { order.append(k); groups[k] = (e, []) }
                    if var g = groups[k], !g.labels.contains(e.label) { g.labels.append(e.label); groups[k] = g }
                }
                var gs = order.compactMap { groups[$0] }
                gs.sort { $0.e.date > $1.e.date }
                self.logRows = gs.map { (date: $0.e.date, by: $0.e.by, from: $0.e.from, to: $0.e.to, labels: $0.labels) }
                var note = gs.isEmpty ? "Kiện này chưa có lịch sử thay đổi vị trí." : "\(gs.count) lần đổi vị trí (mới nhất trước)"
                if failed > 0 { note += " · \(failed) hạng mục không tải được log" }
                self.logNote = note
            } catch let err { self.logNote = err.localizedDescription }
            self.logLoading = false
        }
    }
}
