// MrfReturn.swift — tab "Trả hàng" (MRF).

import SwiftUI
import PhotosUI
import WebKit
import MapKit
import CoreLocation
import UserNotifications

// MARK: - Tab "Trả hàng" (MRF): tìm MRF, tích chọn dòng còn phải trả
//
// Làm theo popup "Return Creation" của web (desmReturnCreationPopUp.js, 2026-10-28):
//   Tìm:  POST /getDesmReturnCreationList.do  (PROJECT_NO, PACKAGE_NO, MRF_NO, MATERIAL_CODE, REQUEST_START_DATE, ATTRIBUTE10, REQUEST_END_DATE, TYPE, CATEGORY)
//         trả MRF_NO, MRF_NAME, SUBCONTRACTOR, RETURN_REQ_DATE, MATERIAL_CODE, PACKAGE_NO, DESCRIPTION, REQ_RETURN_QTY, RETURN_AVAILABLE_QTY, MRF_HEADER_ID, MRF_LINE_ID, RSI_LINE_ID...
//   Lưu:  POST /saveDesmMrfReturnSave.do  updateList=[{MRF_HEADER_ID, MRF_LINE_ID, MATERIAL_CODE, PROJECT_NO, RETURN_DATE(yyyy/MM/dd), RETURN_QTY, RSI_LINE_ID}]
//         lỗi số lượng: {error:"QTY", MRF_LINE_ID, RETURN_AVAILABLE_QTY}. Phần lưu CHƯA thử trên DESM thật.

/// Một hạng mục trong màn MRF Detail: dòng của phiếu (getMrfSummaryList, gồm cả dòng đã trả đủ) ghép với dòng còn trả được
/// (getDesmReturnCreationList). Dòng còn trả được thì tích được để RETURN; dòng đã trả đủ chỉ để xem.
struct DesmMrfItem: Identifiable {
    let id: String
    var pkg = "", desc = "", code = "", unit = ""
    var req = 0.0, done = 0.0
    var out: DesmMrfLine? = nil
    var tickable: Bool { guard let o = out else { return false }; return o.valid && o.balance > 0 }
    var isClosed: Bool {
        if let o = out, o.balance <= 0 { return true }
        return req > 0 && done >= req - 0.0005
    }
}

struct DesmMrfLine: Identifiable {
    let id: String
    var mrfNo = "", mrfName = "", status = "", returnType = "", reqDate = "", rsiNo = "", code = "", desc = "", pkg = "", loc = "", unit = ""
    var req = 0.0, done = 0.0, balance = 0.0
    var headerId: Any = NSNull()
    var lineId: Any = NSNull()
    var rsiLineId: Any = NSNull()
    var valid = true
}

final class DesmMrfReturnVM: ObservableObject {
    @Published var mrfNo = ""
    @Published var mrfName = ""
    @Published var pkg = ""
    @Published var code = ""
    @Published var onlyOpen = true
    @Published var fPkg = ""             // lọc ngay trong phiếu (không gọi máy chủ)
    @Published var fCode = ""
    @Published var showOpts = false
    @Published var saving = false
    @Published var offline = false       // đang xem bản đã lưu (không tải được từ DESM) → không cho trả hàng
    @Published var notice: String? = nil
    var project = ""
    @Published var lines: [DesmMrfLine] = []
    @Published var selected = Set<String>()
    @Published var qty: [String: String] = [:]
    @Published var date = Date()
    @Published var loading = false
    @Published var searched = false
    @Published var error: String? = nil
    @Published var docs: [String: DesmDocDetail] = [:]   // TẤT CẢ dòng của phiếu (kể cả đã trả đủ) theo số MRF
    @Published var docLoading = Set<String>()
    @Published var docFailed = Set<String>()

    /// Tải toàn bộ dòng của phiếu (cùng truy vấn đã dùng ở DocDetail). `force` = tải lại (sau khi RETURN).
    func loadDoc(_ model: BrowserModel, mrf: String, force: Bool = false) {
        if mrf.isEmpty { return }
        if !force && docs[mrf] != nil { return }
        if docLoading.contains(mrf) { return }
        docLoading.insert(mrf); docFailed.remove(mrf)
        Task { @MainActor in
            defer { self.docLoading.remove(mrf) }
            if let d = try? await model.fetchDocDetailAsync(kind: .mrf, no: mrf) { self.docs[mrf] = d }
            else { self.docFailed.insert(mrf) }
        }
    }

    /// Ghép dòng của phiếu với dòng còn trả được theo Package No + Material Code (theo thứ tự nếu trùng).
    func items(for mrf: String) -> [DesmMrfItem] {
        let key = mrf.uppercased()
        let outs = lines.filter { $0.mrfNo.uppercased() == key }
        func nz(_ t: String) -> String { t.split(whereSeparator: { $0.isWhitespace }).joined(separator: " ").lowercased() }
        var used = Set<Int>()
        var result: [DesmMrfItem] = []
        for (i, d) in (docs[mrf]?.lines ?? []).enumerated() {
            let k = nz(d.pkg) + "|" + nz(d.code)
            let hit = outs.indices.first { !used.contains($0) && nz(outs[$0].pkg) + "|" + nz(outs[$0].code) == k }
            var it = DesmMrfItem(id: "v\(i)")
            it.pkg = d.pkg; it.desc = d.desc; it.code = d.code; it.unit = d.unit; it.req = d.req; it.done = d.done
            if let h = hit { used.insert(h); it.out = outs[h] }
            result.append(it)
        }
        for (i, o) in outs.enumerated() where !used.contains(i) {
            var it = DesmMrfItem(id: "o\(o.id)")
            it.pkg = o.pkg; it.desc = o.desc; it.code = o.code; it.req = o.req; it.done = max(0, o.req - o.balance); it.out = o
            result.append(it)
        }
        return desmSortedByPkg(result, pkg: { $0.pkg }, code: { $0.code })
    }

    /// Đầu phiếu lấy từ dữ liệu phiếu khi không còn dòng phải trả nào (phiếu đã trả hết).
    func headerLine(_ mrf: String) -> DesmMrfLine {
        var l = DesmMrfLine(id: "hdr")
        l.mrfNo = mrf
        if let h = docs[mrf]?.header {
            func v(_ k: String) -> String { h.first { $0.0 == k }?.1 ?? "" }
            l.mrfName = v("Tên phiếu"); l.status = v("Đơn vị"); l.returnType = v("Loại trả"); l.reqDate = v("Ngày yêu cầu trả")
        }
        return l
    }

    var groups: [(String, [DesmMrfLine])] {
        var order: [String] = []; var map: [String: [DesmMrfLine]] = [:]
        for l in lines { if map[l.mrfNo] == nil { order.append(l.mrfNo) }; map[l.mrfNo, default: []].append(l) }
        return order.map { ($0, desmSortedByPkg(map[$0] ?? [], pkg: { $0.pkg }, code: { $0.code })) }
    }
    var allSelected: Bool { !lines.isEmpty && selected.count == lines.filter { $0.valid }.count }

    func reset() { mrfNo = ""; mrfName = ""; pkg = ""; code = "" }
    static func dayText(_ d: Date) -> String {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy/MM/dd"
        return f.string(from: d)
    }

    static func fmt(_ v: Double) -> String { v == v.rounded() ? String(Int(v)) : String(format: "%g", v) }

    /// Đổi MRF_HEADER_ID (số sau `MRF!!!` trong QR) thành số MRF bằng getMrfSummaryList.do (bộ lọc trống).
    /// Trả nil nếu lỗi/không thấy (khi đó dùng đường tải toàn bộ danh sách còn phải trả). Trường MRF_HEADER_ID của API này CHƯA kiểm chứng.
    func resolveMrfNo(_ model: BrowserModel, headerId: String) async -> String? {
        guard let pj = try? await model.desmProjectNo() else { return nil }
        let e = desmFormEnc
        let body = "PROJECT_NO=\(e(pj))&RSI_NO=&RSI_NAME=&SUBCONTRACTOR=&MATERIAL_CODE=&RSI_START_REQUEST_DATE=&RSI_END_REQUEST_DATE=&ZIM_ATTRIBUTE10=&RSI_BALANCE_QTY=&TYPE=&CATEGORY=&SUB_CATEGORY=&PACKING_LIST_NO=&MRF_NO=&MRF_NAME=&PACKAGE_NO=&ITEM_DESC=&RETURN_TYPE=&MRF_BALANCE_QTY="
        guard let rows = try? await model.desmQueryAsync("/getMrfSummaryList.do", body: body) else { return nil }
        let hit = rows.first { Self.str($0, "MRF_HEADER_ID") == headerId }
        let no = hit.map { Self.str($0, "MRF_NO") } ?? ""
        return no.isEmpty ? nil : no.uppercased()
    }

    func pick(_ l: DesmMrfLine) { selected.insert(l.id); if (qty[l.id] ?? "").isEmpty { qty[l.id] = Self.fmt(l.balance) } }
    func toggle(_ l: DesmMrfLine) { guard l.valid else { return }; if selected.contains(l.id) { selected.remove(l.id) } else { pick(l) } }
    func setGroup(_ items: [DesmMrfLine], on: Bool) { for l in items where l.valid { if on { pick(l) } else { selected.remove(l.id) } } }
    func setAll(_ on: Bool) { setGroup(lines, on: on) }

    static func str(_ r: [String: Any], _ k: String) -> String {
        if let s = r[k] as? String { return s.trimmingCharacters(in: .whitespacesAndNewlines) }
        if let n = r[k] as? NSNumber { return n.stringValue }
        return ""
    }
    static func num(_ r: [String: Any], _ k: String) -> Double {
        if let n = r[k] as? NSNumber { return n.doubleValue }
        if let s = r[k] as? String { return Double(s) ?? 0 }
        return 0
    }

    func search(_ model: BrowserModel, done: (() -> Void)? = nil) {
        loading = true; error = nil
        Task { @MainActor in
            let pj: String
            do { pj = try await model.desmProjectNo() }
            catch { self.loading = false; self.error = error.localizedDescription; done?(); return }
            self.project = pj
            let e = desmFormEnc
            let body = "PROJECT_NO=\(e(pj))&PACKAGE_NO=\(e(self.pkg))&MRF_NO=\(e(self.mrfNo))&MATERIAL_CODE=\(e(self.code))&REQUEST_START_DATE=&ATTRIBUTE10=&REQUEST_END_DATE=&TYPE=&CATEGORY="
            defer { self.loading = false; self.searched = true; done?() }
            let list: [[String: Any]]
            self.offline = false
            do {
                list = try await model.desmQueryAsync("/getDesmReturnCreationList.do", body: body)
                DesmListCache.save("mrf", body: body, list: list)
            } catch {
                guard let c = DesmListCache.load("mrf", body: body) else { self.error = error.localizedDescription; self.lines = []; return }
                list = c.list
                self.offline = true
                self.error = error.localizedDescription
                self.notice = "Đang xem số liệu đã lưu lúc " + ProgFmt.stamp(c.at) + ". Cần có mạng để trả hàng."
            }
            var out: [DesmMrfLine] = []
            for (i, r) in list.enumerated() {
                let lid = r["MRF_LINE_ID"], hid = r["MRF_HEADER_ID"]
                let ok = lid != nil && !(lid is NSNull) && hid != nil && !(hid is NSNull)
                var l = DesmMrfLine(id: ok ? Self.str(r, "MRF_LINE_ID") + "-" + Self.str(r, "RSI_LINE_ID") : "row\(i)")
                l.mrfNo = Self.str(r, "MRF_NO"); l.mrfName = Self.str(r, "MRF_NAME"); l.status = Self.str(r, "SUBCONTRACTOR")
                l.returnType = Self.str(r, "TYPE"); l.reqDate = Self.str(r, "RETURN_REQ_DATE")
                l.code = Self.str(r, "MATERIAL_CODE"); l.desc = Self.str(r, "DESCRIPTION"); l.pkg = Self.str(r, "PACKAGE_NO")
                l.loc = Self.str(r, "CATEGORY")
                l.req = Self.num(r, "REQ_RETURN_QTY"); l.balance = Self.num(r, "RETURN_AVAILABLE_QTY")
                l.headerId = hid ?? NSNull(); l.lineId = lid ?? NSNull(); l.rsiLineId = r["RSI_LINE_ID"] ?? NSNull()
                l.valid = ok
                if self.onlyOpen && l.balance <= 0 { continue }
                if !self.mrfName.isEmpty && !l.mrfName.localizedCaseInsensitiveContains(self.mrfName) { continue }
                out.append(l)
            }
            out.sort { $0.reqDate > $1.reqDate }
            self.lines = out
            self.selected = self.selected.intersection(Set(out.map { $0.id }))
        }
    }

    func save(_ model: BrowserModel) {
        let chosen = lines.filter { selected.contains($0.id) }
        guard !chosen.isEmpty else { return }
        if offline { error = "Đang xem số liệu đã lưu, cần tải lại danh sách (Search) khi có mạng rồi mới trả hàng."; return }
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy/MM/dd"
        let day = f.string(from: date)
        var list: [[String: Any]] = []
        for l in chosen {
            let q = Double((qty[l.id] ?? Self.fmt(l.balance)).replacingOccurrences(of: ",", with: ".")) ?? 0
            if q <= 0 { error = "Số lượng trả của \(l.code) phải lớn hơn 0."; return }
            if q > l.balance + 0.0005 { error = "\(l.code): số lượng trả \(Self.fmt(q)) vượt quá số còn trả được \(Self.fmt(l.balance))."; return }
            list.append(["MRF_HEADER_ID": l.headerId, "MRF_LINE_ID": l.lineId, "MATERIAL_CODE": l.code, "PROJECT_NO": project,
                         "RETURN_DATE": day, "RETURN_QTY": q, "RSI_LINE_ID": l.rsiLineId])
        }
        guard let data = try? JSONSerialization.data(withJSONObject: list), let json = String(data: data, encoding: .utf8) else {
            error = "Không tạo được dữ liệu gửi đi."; return
        }
        saving = true; error = nil; notice = nil
        model.desmWrite("/saveDesmMrfReturnSave.do", updateList: json, label: "Trả hàng MRF") { res, err in
            self.saving = false
            if res == nil { self.error = err; return }
            guard let r = res as? [String: Any] else { self.error = "Phản hồi không rõ. Hãy kiểm tra trên web trước khi thử lại."; return }
            let e = r["error"]
            if e == nil || e is NSNull {
                self.notice = "Đã trả hàng \(chosen.count) dòng."
                self.selected.removeAll(); self.qty.removeAll()
                self.search(model)
                for m in Set(chosen.map { $0.mrfNo }) { self.loadDoc(model, mrf: m, force: true) }   // cập nhật số đã trả/đã đóng
            } else if (e as? String) == "QTY" {
                let id = Self.str(r, "MRF_LINE_ID")
                let av = Self.str(r, "RETURN_AVAILABLE_QTY")
                let name = chosen.first { Self.str(["x": $0.lineId], "x") == id }?.code ?? id
                self.error = "Vượt số lượng được trả ở dòng \(name). Còn trả được: \(av). Hãy tải lại danh sách để kiểm tra."
            } else {
                self.error = "\(e ?? "Lỗi không rõ")"
            }
        }
    }
}

struct DesmMrfReturnSheet: View {
    @ObservedObject var model: BrowserModel
    var onClose: () -> Void
    /// Phiếu cần mở thẳng (khi mở chồng từ màn kiện); không có thì nhận qua model.pendingRsiScan như cũ.
    var initial: QRRsi? = nil
    @State private var usedInitial = false
    @StateObject private var vm = DesmMrfReturnVM()
    @ObservedObject private var tr = NativeTranslator.shared
    @State private var showForm = true
    @State private var confirm = false
    @State private var path: [String] = []
    private let headBlue = Color(red: 0.33, green: 0.65, blue: 0.98)
    private let bg = Color(red: 0.95, green: 0.97, blue: 0.99)

    func field(_ title: String, _ text: Binding<String>) -> some View {
        HStack(spacing: 10) {
            Text(title).font(.system(size: 14, weight: .bold)).frame(width: 110, alignment: .leading)
            TextField("", text: text)
                .textInputAutocapitalization(.characters).autocorrectionDisabled()
                .padding(.horizontal, 10).padding(.vertical, 9)
                .background(Color.white, in: RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.35)))
                .submitLabel(.search).onSubmit { vm.search(model); withAnimation { showForm = false } }
        }
    }

    func pill(_ title: String, _ symbol: String, _ color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: symbol).font(.system(size: 15, weight: .bold))
                .frame(maxWidth: .infinity).padding(.vertical, 11)
                .foregroundStyle(.white).background(color, in: RoundedRectangle(cornerRadius: 8))
        }.buttonStyle(.plain)
    }

    // MARK: Bước 1 — tìm số MRF, ra danh sách phiếu
    var searchCard: some View {
        VStack(spacing: 8) {
            if showForm {
                field("MRF No.", $vm.mrfNo)
                field("MRF Name", $vm.mrfName)
                field("Package No.", $vm.pkg)
                field("Material Code", $vm.code)
                Toggle("Chỉ dòng còn phải trả", isOn: $vm.onlyOpen).font(.system(size: 13, weight: .semibold))
            }
            HStack(spacing: 8) {
                pill(showForm ? "Hide" : "Filter", showForm ? "chevron.up.2" : "chevron.down.2", Color(red: 0.07, green: 0.70, blue: 0.62)) {
                    withAnimation { showForm.toggle() }
                }
                pill("Reset", "arrow.counterclockwise", Color(red: 0.42, green: 0.53, blue: 0.72)) { vm.reset() }
                pill("Search", "magnifyingglass", Color(red: 0.12, green: 0.56, blue: 1.0)) { vm.search(model); withAnimation { showForm = false } }
            }
        }
        .padding(12)
        .background(bg)
    }

    func voucherCard(_ g: (String, [DesmMrfLine])) -> some View {
        let f = g.1.first
        let left = g.1.reduce(0.0) { $0 + $1.balance }
        return Button { path.append(g.0) } label: {
            HStack(spacing: 0) {
                Rectangle().fill(headBlue).frame(width: 5)
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Text(g.0).font(.system(size: 17, weight: .bold)).underline()
                        Spacer()
                        Text(f?.returnType ?? "").font(.system(size: 14))
                    }
                    HStack {
                        Text(f?.mrfName ?? "").font(.system(size: 15))
                        Spacer()
                        Text(f?.status ?? "").font(.system(size: 15))
                    }
                    HStack {
                        Text("\(g.1.count) dòng · còn trả \(DesmMrfReturnVM.fmt(left))").font(.system(size: 13)).foregroundStyle(.secondary)
                        Spacer()
                        Text(f?.reqDate ?? "").font(.system(size: 15))
                    }
                }
                .padding(12).foregroundStyle(.primary)
            }
            .background(Color.white, in: RoundedRectangle(cornerRadius: 10))
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .shadow(color: .black.opacity(0.12), radius: 2, y: 1)
        }.buttonStyle(.plain)
    }

    var rootView: some View {
        VStack(spacing: 0) {
            searchCard
            Divider()
            if let e = vm.error {
                Text(e).font(.system(size: 13)).foregroundStyle(.red).padding(10).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.red.opacity(0.08))
            }
            if let n = vm.notice {
                Text(n).font(.system(size: 13, weight: .semibold)).foregroundStyle(.green).padding(10).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.green.opacity(0.10))
            }
            if vm.loading && vm.lines.isEmpty {
                Spacer(); ProgressView("Đang tìm…"); Spacer()
            } else if vm.lines.isEmpty {
                Spacer()
                Text(vm.searched ? "Không có phiếu MRF nào còn hàng phải trả theo điều kiện này."
                                 : "Nhập số MRF (hoặc để trống) rồi bấm Search.")
                    .font(.callout).foregroundStyle(.secondary).multilineTextAlignment(.center).padding(24)
                Spacer()
            } else {
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(vm.groups, id: \.0) { g in voucherCard(g) }
                    }.padding(12)
                }
                .background(bg)
            }
        }
    }

    // MARK: Bước 2 — mở phiếu: tích dòng, chỉnh số lượng, bấm RETURN
    func matches(_ l: DesmMrfItem) -> Bool {
        let p = vm.fPkg.trimmingCharacters(in: .whitespaces).lowercased()
        let c = vm.fCode.trimmingCharacters(in: .whitespaces).lowercased()
        if !p.isEmpty && !l.pkg.lowercased().contains(p) { return false }
        if !c.isEmpty && !(l.code.lowercased().contains(c) || l.desc.lowercased().contains(c)) { return false }
        return true
    }

    func header(_ f: DesmMrfLine?) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(f?.mrfNo ?? "").font(.system(size: 22, weight: .semibold))
                Text(f?.status ?? "").font(.system(size: 20))
                Spacer(minLength: 4)
                Text(f?.returnType ?? "").font(.system(size: 18))
            }
            HStack {
                Text(f?.mrfName ?? "").font(.system(size: 20))
                Spacer()
                Text(f?.reqDate ?? "").font(.system(size: 18))
            }
            if vm.showOpts {
                DatePicker("Ngày trả", selection: $vm.date, displayedComponents: .date)
                    .font(.system(size: 14, weight: .semibold))
                    .padding(10).background(Color.white.opacity(0.22), in: RoundedRectangle(cornerRadius: 10))
            }
            HStack {
                Text(vm.showOpts ? "" : "Ngày trả: " + DesmMrfReturnVM.dayText(vm.date)).font(.system(size: 13)).opacity(0.9)
                Spacer()
                Button { withAnimation { vm.showOpts.toggle() } } label: {
                    Image(systemName: vm.showOpts ? "chevron.up" : "chevron.down")
                        .font(.system(size: 16, weight: .bold)).foregroundStyle(headBlue)
                        .frame(width: 56, height: 34).background(Color.white, in: RoundedRectangle(cornerRadius: 6))
                }.buttonStyle(.plain)
            }
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 14).padding(.vertical, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(headBlue)
    }

    func filterBar(_ shown: [DesmMrfLine]) -> some View {
        let valid = shown.filter { $0.valid }
        let allOn = !valid.isEmpty && valid.allSatisfy { vm.selected.contains($0.id) }
        return HStack(spacing: 8) {
            Text("PKG.").font(.system(size: 14, weight: .bold))
            TextField("", text: $vm.fPkg).textInputAutocapitalization(.characters).autocorrectionDisabled()
                .padding(.horizontal, 8).padding(.vertical, 8).frame(maxWidth: .infinity)
                .background(Color(red: 0.95, green: 0.96, blue: 0.98), in: RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.3)))
            Text("MÃ").font(.system(size: 14, weight: .bold))
            TextField("", text: $vm.fCode).textInputAutocapitalization(.characters).autocorrectionDisabled()
                .padding(.horizontal, 8).padding(.vertical, 8).frame(maxWidth: .infinity)
                .background(Color(red: 0.95, green: 0.96, blue: 0.98), in: RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.3)))
            Button { vm.setGroup(shown, on: !allOn) } label: {
                HStack(spacing: 4) {
                    Image(systemName: allOn ? "checkmark.square.fill" : "square").font(.system(size: 22)).foregroundStyle(Color.tabBlue)
                    Text("ALL").font(.system(size: 15, weight: .bold)).foregroundStyle(.primary)
                }
            }.buttonStyle(.plain)
            Button { if !vm.selected.isEmpty { vm.error = nil; confirm = true } } label: {
                HStack(spacing: 4) {
                    if vm.saving { ProgressView().tint(.white) }
                    Text(vm.selected.isEmpty ? "RETURN" : "RETURN (\(vm.selected.count))").font(.system(size: 15, weight: .bold))
                }
                .padding(.horizontal, 10).padding(.vertical, 11)
                .foregroundStyle(.white)
                .background(vm.selected.isEmpty ? Color.gray : Color(red: 0.12, green: 0.56, blue: 1.0), in: RoundedRectangle(cornerRadius: 8))
            }.buttonStyle(.plain).disabled(vm.saving || vm.selected.isEmpty)
        }
        .padding(.horizontal, 10).padding(.vertical, 8)
        .background(Color.white)
    }

    func card(_ l: DesmMrfLine) -> some View {
        let on = vm.selected.contains(l.id)
        let done = max(0, l.req - l.balance)
        return HStack(spacing: 0) {
            Rectangle().fill(l.valid ? headBlue : Color.gray).frame(width: 5)
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 3) {
                        PkgNoLink(model: model, no: l.pkg)
                        PkgLocLine(model: model, no: l.pkg)
                    }
                    Spacer()
                    Button { vm.toggle(l) } label: {
                        Image(systemName: on ? "checkmark.square.fill" : "square")
                            .font(.system(size: 26)).foregroundStyle(l.valid ? Color.tabBlue : Color.gray)
                    }.buttonStyle(.plain).disabled(!l.valid)
                }
                HStack(alignment: .top) {
                    Text(tr.t(l.desc)).font(.system(size: 16)).lineLimit(4)
                    Spacer(minLength: 6)
                    TextField("0", text: Binding(get: { vm.qty[l.id] ?? DesmMrfReturnVM.fmt(l.balance) }, set: { vm.qty[l.id] = $0 }))
                        .keyboardType(.decimalPad).multilineTextAlignment(.center)
                        .font(.system(size: 16, weight: .semibold))
                        .frame(width: 70).padding(.vertical, 6)
                        .background(Color.white, in: RoundedRectangle(cornerRadius: 6))
                        .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.gray.opacity(0.4)))
                }
                HStack(spacing: 4) {
                    Text(l.code).font(.system(size: 16))
                    Spacer(minLength: 4)
                    Text(String(format: "%.3f", l.balance)).font(.system(size: 17, weight: .bold)).foregroundStyle(.red)
                    Text("/").font(.system(size: 17, weight: .bold))
                    Text(String(format: "%.3f", done)).font(.system(size: 17, weight: .bold)).foregroundStyle(Color.tabBlue)
                }
                HStack(spacing: 8) {
                    Text("đỏ = còn trả được · xanh = đã trả").font(.system(size: 10)).foregroundStyle(.secondary)
                    if !l.rsiNo.isEmpty { Text(l.rsiNo).font(.system(size: 10)).foregroundStyle(.secondary) }
                }
                if !l.valid { Text("Thiếu MRF_LINE_ID/MRF_HEADER_ID — không thể trả dòng này.").font(.system(size: 11)).foregroundStyle(.red) }
            }
            .padding(12)
        }
        .background(on ? Color(red: 0.90, green: 0.95, blue: 1.0) : Color.white, in: RoundedRectangle(cornerRadius: 10))
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .shadow(color: .black.opacity(0.12), radius: 2, y: 1)
        .onTapGesture { vm.toggle(l) }
    }

    /// Thẻ hạng mục đã trả đủ (hoặc chưa trả được): chỉ để xem, không có ô tích.
    func closedCard(_ it: DesmMrfItem) -> some View {
        let done = it.isClosed
        let tint: Color = done ? .green : .orange
        return HStack(spacing: 0) {
            Rectangle().fill(tint).frame(width: 5)
            VStack(alignment: .leading, spacing: 6) {
                PkgNoLink(model: model, no: it.pkg)
                PkgLocLine(model: model, no: it.pkg)
                Text(tr.t(it.desc)).font(.system(size: 16)).lineLimit(4)
                HStack(spacing: 4) {
                    Text(it.code).font(.system(size: 16))
                    Spacer(minLength: 4)
                    Text("\(DesmMrfReturnVM.fmt(it.req)) / \(DesmMrfReturnVM.fmt(it.done)) \(it.unit)").font(.system(size: 17, weight: .bold))
                }
                HStack(spacing: 8) {
                    Text(done ? "Đã đóng (trả đủ)" : "Chưa đóng · chưa có trong danh sách chờ trả")
                        .font(.system(size: 11, weight: .bold)).padding(.horizontal, 6).padding(.vertical, 2)
                        .foregroundStyle(tint).background(tint.opacity(0.15), in: Capsule())
                    Text("yêu cầu trả / đã trả").font(.system(size: 10)).foregroundStyle(.secondary)
                }
            }
            .padding(12).frame(maxWidth: .infinity, alignment: .leading)
        }
        .background(Color.white, in: RoundedRectangle(cornerRadius: 10))
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .shadow(color: .black.opacity(0.12), radius: 2, y: 1)
    }

    /// Dải trạng thái của cả phiếu: đã đóng hết hay còn dòng chờ trả (RETURN).
    func stateBanner(_ items: [DesmMrfItem]) -> some View {
        let total = items.count
        let open = items.filter { $0.tickable }.count
        let closed = items.filter { $0.isClosed }.count
        let known = vm.searched && vm.error == nil && !vm.loading
        let text: String, tint: Color
        if total == 0 { text = ""; tint = .gray }
        else if !known { text = "Đang kiểm tra dòng chờ trả…"; tint = .gray }
        else if open > 0 { text = "CHƯA ĐÓNG HẾT · còn \(open)/\(total) dòng chờ trả (tích rồi bấm RETURN)"; tint = .orange }
        else if closed == total { text = "ĐÃ ĐÓNG · \(total)/\(total) dòng đã trả đủ"; tint = .green }
        else { text = "Chưa đóng hết nhưng chưa có dòng nào trả được (\(closed)/\(total) dòng đã đóng)"; tint = .orange }
        return Group {
            if !text.isEmpty {
                Text(text).font(.system(size: 14, weight: .bold)).foregroundStyle(tint)
                    .padding(10).frame(maxWidth: .infinity, alignment: .leading)
                    .background(tint.opacity(0.12))
            }
        }
    }

    func detail(_ mrf: String) -> some View {
        let items = vm.items(for: mrf)
        let shown = items.filter { matches($0) }
        let head = vm.lines.first { $0.mrfNo.uppercased() == mrf.uppercased() } ?? vm.headerLine(mrf)
        let tickLines = shown.compactMap { $0.out }.filter { $0.balance > 0 }
        return VStack(spacing: 0) {
            header(head)
            stateBanner(items)
            NativeTranslateNote().padding(.horizontal, 10)
            filterBar(tickLines)
            Divider()
            if let e = vm.error {
                Text(e).font(.system(size: 13)).foregroundStyle(.red).padding(10).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.red.opacity(0.08))
            }
            if let n = vm.notice {
                Text(n).font(.system(size: 13, weight: .semibold)).foregroundStyle(.green).padding(10).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.green.opacity(0.10))
            }
            if items.isEmpty {
                Spacer()
                if vm.loading || vm.docLoading.contains(mrf) { ProgressView("Đang tải…") }
                else {
                    VStack(spacing: 10) {
                        Text(vm.docFailed.contains(mrf) ? "Không tải được hạng mục của phiếu \(mrf)." : "Phiếu \(mrf) không có hạng mục nào.")
                            .font(.callout).multilineTextAlignment(.center)
                        Button("Tải lại") { vm.loadDoc(model, mrf: mrf, force: true); vm.search(model) }.buttonStyle(.borderedProminent)
                        Button("Xem chi tiết (chỉ xem)") { path.append(Self.closedPrefix + mrf) }
                        Button("Về danh sách") { path.removeAll() }
                    }.padding(24)
                }
                Spacer()
            } else {
                Text("\(shown.count) / \(items.count) hạng mục").font(.system(size: 13)).foregroundStyle(Color.orange)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 12).padding(.vertical, 6).background(bg)
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(shown) { it in
                            if it.tickable, let o = it.out { card(o) } else { closedCard(it) }
                        }
                        if shown.isEmpty { Text("Không có dòng khớp bộ lọc.").font(.footnote).foregroundStyle(.secondary).padding(20) }
                    }.padding(12)
                }
                .background(bg)
            }
        }
        .navigationTitle("MRF Detail")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                NativeTranslateButton(signature: items.count) { items.map { $0.desc } + [head.mrfName] }
            }
        }
        .desmExport {
            DesmTable(name: "mrf-\(mrf)",
                      headers: ["MRF No", "Package No", "Vị trí kiện", "Material Code", "Description", "Đơn vị", "SL yêu cầu", "SL đã trả", "SL còn phải trả", "Đã đóng"],
                      rows: vm.items(for: mrf).map { [mrf, $0.pkg, desmLocOf($0.pkg), $0.code, $0.desc, $0.unit, desmNum($0.req), desmNum($0.done), $0.out.map { desmNum($0.balance) } ?? "", $0.isClosed ? "Y" : ""] })
        }
        .onAppear { vm.loadDoc(model, mrf: mrf) }
    }

    private static let closedPrefix = "closed:"

    /// Phiếu MRF vừa quét: đổi mã QR (MRF_HEADER_ID) thành số MRF, tìm rồi mở thẳng màn MRF Detail.
    /// Phiếu không còn dòng phải trả (đã trả hết) → vẫn mở MRF Detail, dòng đã đóng chỉ để xem.
    private func consumeScan(_ given: QRRsi? = nil) {
        guard let r0 = given ?? model.pendingRsiScan, r0.kind == .mrf else { return }
        if given == nil { model.pendingRsiScan = nil }
        vm.mrfNo = ""; vm.mrfName = ""; vm.pkg = ""; vm.code = ""; vm.onlyOpen = true
        path.removeAll()
        withAnimation { showForm = false }
        Task { @MainActor in
            var r = r0
            if !r.isNo {
                vm.loading = true
                if let no = await vm.resolveMrfNo(model, headerId: r.value) { r = QRRsi(value: no, raw: r0.raw, isNo: true, kind: .mrf) }
            }
            let rr = r
            vm.mrfNo = rr.isNo ? rr.value : ""
            vm.search(model) {
                let hit = vm.lines.first { l in
                    rr.isNo ? l.mrfNo.uppercased() == rr.value
                            : DesmMrfReturnVM.str(["x": l.headerId], "x") == rr.value
                }
                if let h = hit {
                    vm.mrfNo = h.mrfNo
                    path = [h.mrfNo]
                } else if vm.error == nil {
                    if rr.isNo {
                        // Phiếu không còn dòng phải trả (đã đóng hết): vẫn mở màn MRF Detail đầy đủ để xem từng dòng đã đóng/chưa đóng
                        path = [rr.value]
                    } else {
                        vm.error = "Không đổi được mã \(rr.value) sang số MRF (kiểm tra mạng/phiên đăng nhập rồi quét lại)."
                    }
                }
            }
        }
    }

    var body: some View {
        NavigationStack(path: $path) {
            rootView
                .navigationTitle("Trả hàng MRF")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { onClose() } }
                }
                .navigationDestination(for: String.self) { mrf in
                    if mrf.hasPrefix(Self.closedPrefix) {
                        DesmDocDetailView(model: model, kind: .mrf, group: DesmDocGroup(id: String(mrf.dropFirst(Self.closedPrefix.count))))
                    } else { detail(mrf) }
                }
        }
        .desmExport {
            DesmTable(name: "mrf-cho-tra",
                      headers: ["MRF No", "MRF Name", "Trạng thái", "Loại trả", "Ngày yêu cầu", "RSI No", "Package No", "Vị trí kiện", "Material Code", "Description", "Đơn vị", "SL yêu cầu", "SL đã trả", "SL còn phải trả"],
                      rows: vm.lines.map { [$0.mrfNo, $0.mrfName, $0.status, $0.returnType, $0.reqDate, $0.rsiNo, $0.pkg, desmLocOf($0.pkg), $0.code, $0.desc, $0.unit, desmNum($0.req), desmNum($0.done), desmNum($0.balance)] })
        }
        .onChange(of: model.pendingRsiScan) { _ in if initial == nil { consumeScan() } }
        .onChange(of: path) { _ in
            // Đổi phiếu: bỏ chọn/số lượng đã gõ/bộ lọc để không trả nhầm dòng của phiếu khác
            vm.selected.removeAll(); vm.qty.removeAll(); vm.fPkg = ""; vm.fCode = ""; vm.error = nil; vm.notice = nil
        }
        .desmAlert(isPresented: $confirm, icon: "exclamationmark.triangle.fill", title: "Xác nhận trả hàng (RETURN)",
                   message: "Ghi trả hàng \(vm.selected.count) dòng lên DESM ngày \(DesmMrfReturnVM.dayText(vm.date)). Thao tác này không tự hoàn tác được.",
                   actions: [DesmDialogAction(title: "Trả hàng", kind: .destructive) { vm.save(model) },
                             DesmDialogAction(title: "Huỷ", kind: .cancel)])
        .onAppear {
            if let i = initial { if !usedInitial { usedInitial = true; consumeScan(i) } }
            else if model.pendingRsiScan?.kind == .mrf { consumeScan() }
            else if !vm.searched { vm.search(model) }
        }
    }
}
