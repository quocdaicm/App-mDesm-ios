// ProjectProgress.swift — màn "Tiến độ dự án" (Thêm > Tiến độ dự án).
//
// Nguồn dữ liệu: trang PDH "Weekly Progress" (máy chủ desm.doosanenerbility.com CỔNG 8443 — cổng 443 trả 404 cho /pms/...):
//   /pms/getPmsControlGridList.do   PROJECT_ID=T25026            -> danh sách tuần PMS (PMS_SEQ, WEEK, PERIOD, STATUS...)
//   /pms/getPmsProgressGridList.do  PMS_SEQ=...&MODE=W&...       -> cây WBS/Activity của tuần đó (khoảng 9 MB, tải mất vài giây)
// Cách tính: % = ACTUAL_QTY / TOTAL_QTY (theo trọng số của hệ thống); kế hoạch = PLAN_QTY / TOTAL_QTY;
// catch-up = CU_PLAN_QTY / TOTAL_QTY (chỉ ở dòng gốc). Dòng TYPE=ROC (tỷ trọng con của activity) bị bỏ qua khi dựng cây.
// Có nhớ đệm bản trước (3 cấp đầu) để mở lên là thấy số ngay, rồi cập nhật ở nền.
// CHƯA build/chưa thử máy thật: tên trường lấy từ dữ liệu người dùng gửi (desm-fetch-20261102-143319.txt).

import SwiftUI

// MARK: - Màu & định dạng

extension Color {
    static let progGreen = Color(red: 0.16, green: 0.62, blue: 0.36)
    static let progRed = Color(red: 0.86, green: 0.25, blue: 0.25)
    static let progAmber = Color(red: 0.95, green: 0.62, blue: 0.10)
}

enum ProgFmt {
    private static func make(_ digits: Int) -> NumberFormatter {
        let f = NumberFormatter()
        f.locale = Locale(identifier: "vi_VN")
        f.numberStyle = .decimal
        f.minimumFractionDigits = digits
        f.maximumFractionDigits = digits
        return f
    }
    private static let f0 = make(0)
    private static let f1 = make(1)
    private static let f2 = make(2)

    static func num(_ v: Double, _ digits: Int = 2) -> String {
        let f = digits <= 0 ? f0 : (digits == 1 ? f1 : f2)
        return f.string(from: NSNumber(value: v)) ?? String(format: "%.\(max(digits, 0))f", v)
    }
    static func pct(_ v: Double, _ digits: Int = 2) -> String { num(v, digits) + "%" }

    private static let parser: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy/MM/dd"; return f
    }()
    static func parse(_ s: String) -> Date? { s.count >= 10 ? parser.date(from: String(s.prefix(10))) : nil }
    private static let stampFmt: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "vi_VN"); f.dateFormat = "HH:mm dd/MM/yyyy"; return f
    }()
    static func stamp(_ d: Date) -> String { stampFmt.string(from: d) }
    /// "2026/07/28" -> "28/07/26"
    static func date(_ s: String) -> String {
        guard let d = parse(s) else { return s.isEmpty ? "—" : s }
        let f = DateFormatter(); f.locale = Locale(identifier: "vi_VN"); f.dateFormat = "dd/MM/yy"
        return f.string(from: d)
    }
}

// MARK: - Mô hình dữ liệu

struct ProgNode: Identifiable, Codable {
    var id: String
    var name: String
    var type: String          // PJT | WBS | ACT
    var level: Int
    var weight: Double        // WEIGHT_FACTOR_PROGRESS (0...1)
    var total: Double
    var actual: Double
    var plan: Double
    var cuPlan: Double
    var start: String
    var end: String
    var status: String
    var code: String
    var engineer: String
    var children: [ProgNode]

    var pct: Double { total > 0 ? actual / total * 100 : 0 }
    var planPct: Double { total > 0 ? plan / total * 100 : 0 }
    var cuPct: Double { total > 0 ? cuPlan / total * 100 : 0 }
    var delta: Double { pct - planPct }
    var isActivity: Bool { type == "ACT" }
    var isDone: Bool { pct >= 99.995 }

    func trimmed(_ depth: Int) -> ProgNode {
        var n = self
        n.children = depth <= 0 ? [] : children.map { $0.trimmed(depth - 1) }
        return n
    }
}

struct ProgStats: Codable {
    var total = 0, done = 0, doing = 0, notStarted = 0
}

struct ProgWeek: Identifiable, Codable {
    var id: Int               // PMS_SEQ
    var week: String          // "26 W43"
    var period: String        // "12.OCT.26 ~ 18.OCT.26"
    var statusTxt: String     // Processing / Complete
    var confirmTxt: String    // Confirmed ...
    var fromNTP: String       // "W068"
    var projectName: String
    var projectCode: String
    var rocYn: String
    var rollupYn: String

    init?(row r: [String: Any]) {
        func s(_ k: String) -> String {
            if let v = r[k] as? String { return v }
            if let n = r[k] as? NSNumber { return n.stringValue }
            return ""
        }
        guard let n = r["PMS_SEQ"] as? NSNumber else { return nil }
        id = n.intValue
        week = s("WEEK"); period = s("PERIOD"); statusTxt = s("STATUS_TXT"); confirmTxt = s("CONFIRM_TXT"); fromNTP = s("FROM_NTP_TXT")
        projectName = s("ORG_PROJECT_NAME"); projectCode = s("PROJECT_CODE")
        rocYn = s("ROC_YN").isEmpty ? "Y" : s("ROC_YN")
        rollupYn = s("ROLLUP_YN").isEmpty ? "Y" : s("ROLLUP_YN")
    }

    var isProcessing: Bool { statusTxt.lowercased().contains("process") }
}

struct ProgParsed: Sendable {
    var root: ProgNode
    var stats: ProgStats
}

/// Điểm xu hướng: % của dòng gốc mỗi tuần, lưu mỗi khi tải xong một tuần (không phải tải thêm gì).
struct ProgPoint: Codable, Identifiable {
    var id: Int          // PMS_SEQ
    var week: String
    var actual: Double
    var plan: Double
    var cu: Double
}

struct ProgSnapshot: Codable {
    var root: ProgNode
    var stats: ProgStats
    var weeks: [ProgWeek]
    var selected: Int
    var savedAt: Date
}

// MARK: - Dựng cây từ JSON (chạy ở luồng nền)

enum ProgBuilder {
    static func dbl(_ v: Any?) -> Double {
        if let n = v as? NSNumber { return n.doubleValue }
        if let s = v as? String { return Double(s.replacingOccurrences(of: ",", with: "")) ?? 0 }
        return 0
    }
    static func str(_ v: Any?) -> String {
        if let s = v as? String { return s }
        if let n = v as? NSNumber { return n.stringValue }
        return ""
    }

    static func parse(_ data: Data) -> ProgParsed? {
        guard let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let results = obj["results"] as? [[String: Any]], let top = results.first else { return nil }
        var st = ProgStats()
        let root = node(top, idx: 0, stats: &st)
        return ProgParsed(root: root, stats: st)
    }

    static func node(_ d: [String: Any], idx: Int, stats: inout ProgStats) -> ProgNode {
        let type = str(d["TYPE"])
        var kids: [ProgNode] = []
        if let items = d["Items"] as? [[String: Any]] {
            var i = 0
            for c in items {
                if str(c["TYPE"]) == "ROC" { continue }
                kids.append(node(c, idx: i, stats: &stats))
                i += 1
            }
        }
        let n = ProgNode(
            id: "\(idx)|" + str(d["ID"]),
            name: str(d["NAME"]),
            type: type,
            level: Int(dbl(d["LV"])),
            weight: dbl(d["WEIGHT_FACTOR_PROGRESS"]),
            total: dbl(d["TOTAL_QTY"]),
            actual: dbl(d["ACTUAL_QTY"]),
            plan: dbl(d["PLAN_QTY"]),
            cuPlan: dbl(d["CU_PLAN_QTY"]),
            start: str(d["START_DATE"]),
            end: str(d["END_DATE"]),
            status: str(d["PPD_STATUS"]),
            code: str(d["ACTIVITY_ID"]).isEmpty ? str(d["ID"]) : str(d["ACTIVITY_ID"]),
            engineer: str(d["ENGINEER_NAME"]),
            children: kids)
        if type == "ACT" {
            stats.total += 1
            if n.isDone { stats.done += 1 } else if n.pct > 0 { stats.doing += 1 } else { stats.notStarted += 1 }
        }
        return n
    }
}

// MARK: - Tải dữ liệu lớn (timeout dài hơn desmQueryAsync vì phản hồi ~9 MB)

extension BrowserModel {
    private static let progSession: URLSession = {
        let cfg = URLSessionConfiguration.ephemeral
        cfg.httpShouldSetCookies = false
        cfg.timeoutIntervalForRequest = 60
        cfg.timeoutIntervalForResource = 120
        return URLSession(configuration: cfg)
    }()

    @MainActor
    func progressFetch(_ path: String, body: String) async throws -> Data {
        guard let base = URL(string: Self.pmsOrigin), let url = URL(string: path, relativeTo: base)?.absoluteURL,
              url.host?.lowercased().hasSuffix("doosanenerbility.com") == true else { throw DesmAPIError.message("Địa chỉ không hợp lệ.") }
        let cookies = await desmCookies()
        guard !cookies.isEmpty else { throw DesmAPIError.noSession }
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 60)
        req.httpMethod = "POST"
        req.httpBody = body.data(using: .utf8)
        req.allHTTPHeaderFields = HTTPCookie.requestHeaderFields(with: cookies)
        req.setValue("application/x-www-form-urlencoded; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        req.setValue("XMLHttpRequest", forHTTPHeaderField: "X-Requested-With")
        req.setValue("true", forHTTPHeaderField: "AJAX")
        req.setValue(Self.pmsOrigin, forHTTPHeaderField: "Origin")
        req.setValue(Self.pmsOrigin + "/newui/progress.do", forHTTPHeaderField: "Referer")
        let result: (Data, URLResponse)
        do { result = try await Self.progSession.data(for: req) }
        catch { throw DesmAPIError.network(error.localizedDescription) }
        guard let http = result.1 as? HTTPURLResponse else { throw DesmAPIError.unreadable }
        let bad = http.statusCode == 401 || http.statusCode == 503 || http.url?.path.lowercased().contains("login") == true
        if bad {
            if webView != nil { return try await pmsPageFetch(path, body: body) }   // đường lui: gọi từ trang PMS (8443)
            throw DesmAPIError.expired
        }
        if http.statusCode >= 400 { throw DesmAPIError.notJSON(http.statusCode) }
        return result.0
    }
}

// MARK: - ViewModel

@MainActor
final class DesmProgressVM: ObservableObject {
    @Published var weeks: [ProgWeek] = []
    @Published var selected: Int? = nil
    @Published var root: ProgNode? = nil
    @Published var stats = ProgStats()
    @Published var loading = false
    @Published var error: String? = nil
    @Published var updated: Date? = nil
    @Published var fromCache = false
    @Published var history: [ProgPoint] = []
    private var started = false
    private static let historyKey = "desmProgressHistory.v1"

    private static let cacheKey = "desmProgressSnapshot.v1"

    var currentWeek: ProgWeek? { weeks.first { $0.id == selected } }
    var projectName: String {
        let n = currentWeek?.projectName ?? weeks.first?.projectName ?? ""
        return n.isEmpty ? (root?.name ?? "Dự án") : n
    }
    var projectCode: String { currentWeek?.projectCode ?? weeks.first?.projectCode ?? "" }

    func start(model: BrowserModel) async {
        if started { return }
        started = true
        if let hd = UserDefaults.standard.data(forKey: Self.historyKey),
           let h = try? JSONDecoder().decode([ProgPoint].self, from: hd) { history = h.sorted { $0.id < $1.id } }
        if let data = UserDefaults.standard.data(forKey: Self.cacheKey),
           let snap = try? JSONDecoder().decode(ProgSnapshot.self, from: data) {
            root = snap.root; stats = snap.stats; weeks = snap.weeks; selected = snap.selected
            updated = snap.savedAt; fromCache = true
        }
        await reload(model: model)
    }

    func reload(model: BrowserModel, seq: Int? = nil) async {
        if loading { return }
        loading = true; error = nil
        defer { loading = false }
        var step = "getInitDefailProject.do"
        do {
            let code = try await model.desmProjectNo()
            step = "/pms/getPmsControlGridList.do"
            let rows = try await model.desmQueryAsync("/pms/getPmsControlGridList.do", body: "PROJECT_ID=" + BrowserModel.enc(code), origin: BrowserModel.pmsOrigin)
            let list = rows.compactMap { ProgWeek(row: $0) }.sorted { $0.id > $1.id }
            guard !list.isEmpty else { throw DesmAPIError.message("Dự án chưa có tuần PMS nào.") }
            weeks = list
            var pick = list[0].id
            if let s = seq, list.contains(where: { $0.id == s }) { pick = s }
            else if let s = selected, list.contains(where: { $0.id == s }) { pick = s }
            let w = list.first { $0.id == pick } ?? list[0]
            let body = "PMS_SEQ=\(pick)&PERSON_YN=N&ACTUAL_YN=N&EXPECTED_YN=N&WBS_NAME=&DEPT=&ENGINEER_AD=&MANAGER_AD=&THIS_WEEK_FLAG=&DATE_BASE=P"
                + "&PLAN_SEARCH_FLAG=N&PLAN_SEARCH_START=&PLAN_SEARCH_END=&ACT_SEARCH_FLAG=N&ACT_SEARCH_START=&ACT_SEARCH_END="
                + "&EXP_SEARCH_FLAG=N&EXP_SEARCH_START=&EXP_SEARCH_END=&SEARCH_CUM_PROGRESS=&SEARCH_ACT_CODE=&SEARCH_ACT_STS="
                + "&ROC_YN=\(w.rocYn)&ROLLUP_YN=\(w.rollupYn)&ACTIVITY_ID=&MODE=W&CAUSE_TYPE="
            step = "/pms/getPmsProgressGridList.do"
            let data = try await model.progressFetch("/pms/getPmsProgressGridList.do", body: body)
            let parsed = await Task.detached(priority: .userInitiated) { ProgBuilder.parse(data) }.value
            guard let p = parsed else { throw DesmAPIError.message("Không đọc được dữ liệu tiến độ (phiên có thể đã hết hạn).") }
            selected = pick
            root = p.root; stats = p.stats
            updated = Date(); fromCache = false
            let snap = ProgSnapshot(root: p.root.trimmed(2), stats: p.stats, weeks: list, selected: pick, savedAt: Date())
            if let enc = try? JSONEncoder().encode(snap) { UserDefaults.standard.set(enc, forKey: Self.cacheKey) }
            let pt = ProgPoint(id: pick, week: w.week, actual: p.root.pct, plan: p.root.planPct, cu: p.root.cuPct)
            var h = history.filter { $0.id != pick }
            h.append(pt)
            history = Array(h.sorted { $0.id < $1.id }.suffix(26))
            if let he = try? JSONEncoder().encode(history) { UserDefaults.standard.set(he, forKey: Self.historyKey) }
        } catch {
            var msg = error.localizedDescription
            if case DesmAPIError.notJSON(let code)? = error as? DesmAPIError, code == 404 {
                msg = "Máy chủ PDH (cổng 8443) trả HTTP 404 cho \(step)."
            } else if msg.hasPrefix("HTTP 404") {
                msg = "Máy chủ PDH (cổng 8443) trả HTTP 404 cho \(step)."
            } else {
                msg += " [\(step)]"
            }
            self.error = msg
        }
    }

    func select(_ seq: Int, model: BrowserModel) async {
        selected = seq
        await reload(model: model, seq: seq)
    }
}

// MARK: - Thành phần giao diện

struct ProgRing: View {
    let actual: Double
    let plan: Double
    var line: CGFloat = 16

    var body: some View {
        let a = CGFloat(min(max(actual, 0), 100) / 100)
        ZStack {
            Circle().stroke(Color(.tertiarySystemFill), lineWidth: line).padding(line / 2)
            Circle().trim(from: 0, to: max(a, 0.002))
                .stroke(AngularGradient(gradient: Gradient(colors: [Color.tabBlueLight, Color.tabBlue]), center: .center),
                        style: StrokeStyle(lineWidth: line, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .padding(line / 2)
            GeometryReader { g in
                let r = min(g.size.width, g.size.height) / 2 - line / 2
                let ang = (-90.0 + 360.0 * min(max(plan, 0), 100) / 100) * Double.pi / 180
                Circle().fill(Color.progAmber)
                    .overlay(Circle().stroke(Color(.systemBackground), lineWidth: 2))
                    .frame(width: line * 0.7, height: line * 0.7)
                    .position(x: g.size.width / 2 + r * CGFloat(cos(ang)), y: g.size.height / 2 + r * CGFloat(sin(ang)))
            }
            VStack(spacing: 2) {
                Text(ProgFmt.pct(actual, 2))
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.6).lineLimit(1)
                Text("Thực tế").font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary)
            }
            .padding(line + 6)
        }
    }
}

struct ProgBar: View {
    let value: Double
    let plan: Double
    var height: CGFloat = 8

    var body: some View {
        GeometryReader { g in
            let w = g.size.width
            let fillW = max(height, w * CGFloat(min(max(value, 0), 100) / 100))
            let px = max(0, min(w - 2.5, w * CGFloat(min(max(plan, 0), 100) / 100) - 1.25))
            ZStack(alignment: .leading) {
                Capsule().fill(Color(.tertiarySystemFill)).frame(height: height)
                if value > 0 {
                    Capsule()
                        .fill(LinearGradient(colors: [Color.tabBlueLight, Color.tabBlue], startPoint: .leading, endPoint: .trailing))
                        .frame(width: fillW, height: height)
                }
                if plan > 0 {
                    RoundedRectangle(cornerRadius: 1.2).fill(Color.progAmber)
                        .frame(width: 2.5, height: height + 6)
                        .offset(x: px)
                }
            }
            .frame(height: g.size.height)
        }
        .frame(height: height + 6)
    }
}

struct ProgDeltaPill: View {
    let value: Double          // điểm phần trăm (+ nhanh hơn, − chậm hơn)
    var suffix = ""

    private var tone: Color { value > 0.004 ? .progGreen : (value < -0.004 ? .progRed : .secondary) }
    private var icon: String { value > 0.004 ? "arrow.up.right" : (value < -0.004 ? "arrow.down.right" : "equal") }

    var body: some View {
        HStack(spacing: 3) {
            Image(systemName: icon).font(.system(size: 10, weight: .bold))
            Text(ProgFmt.num(abs(value), 2) + suffix).font(.system(size: 12, weight: .semibold, design: .rounded))
        }
        .foregroundColor(tone)
        .padding(.horizontal, 8).padding(.vertical, 3)
        .background(Capsule().fill(tone.opacity(0.13)))
    }
}

struct ProgCard<Content: View>: View {
    var title: String? = nil
    var icon: String? = nil
    var trailing: String? = nil
    @ViewBuilder var content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let t = title {
                HStack(spacing: 6) {
                    if let i = icon { Image(systemName: i).foregroundColor(Color.tabBlue).font(.system(size: 14, weight: .bold)) }
                    Text(t).font(.system(size: 15, weight: .bold))
                    Spacer()
                    if let tr = trailing { Text(tr).font(.system(size: 12, weight: .medium)).foregroundStyle(.secondary) }
                }
            }
            content()
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 3)
    }
}

/// Dòng một nút WBS: tên, % thực tế, thanh tiến độ, kế hoạch, chênh lệch.
struct ProgRow: View {
    @ObservedObject private var tr = NativeTranslator.shared
    let node: ProgNode
    var showChevron = true

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(tr.t(node.name)).font(.system(size: 14, weight: .semibold)).lineLimit(2)
                Spacer(minLength: 6)
                Text(ProgFmt.pct(node.pct, 1)).font(.system(size: 15, weight: .bold, design: .rounded))
                if showChevron {
                    Image(systemName: "chevron.right").font(.system(size: 11, weight: .bold)).foregroundColor(Color(.tertiaryLabel))
                }
            }
            ProgBar(value: node.pct, plan: node.planPct, height: 7)
            HStack(spacing: 8) {
                Text("KH " + ProgFmt.pct(node.planPct, 1)).font(.system(size: 12)).foregroundStyle(.secondary)
                if node.weight > 0 {
                    Text("· TT " + ProgFmt.pct(node.weight * 100, 1)).font(.system(size: 12)).foregroundStyle(.secondary)
                }
                Spacer()
                ProgDeltaPill(value: node.delta)
            }
        }
        .contentShape(Rectangle())
    }
}

/// Dòng một activity (lá của cây).
struct ProgActivityRow: View {
    @ObservedObject private var tr = NativeTranslator.shared
    let node: ProgNode

    private var statusText: String { node.isDone ? "Hoàn thành" : (node.pct > 0 ? "Đang thực hiện" : "Chưa bắt đầu") }
    private var statusColor: Color { node.isDone ? .progGreen : (node.pct > 0 ? Color.tabBlue : .secondary) }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(tr.t(node.name)).font(.system(size: 14, weight: .semibold)).lineLimit(3)
                Spacer(minLength: 6)
                Text(ProgFmt.pct(node.pct, 0)).font(.system(size: 15, weight: .bold, design: .rounded))
            }
            ProgBar(value: node.pct, plan: node.planPct, height: 6)
            HStack(spacing: 8) {
                Text(statusText).font(.system(size: 11, weight: .semibold)).foregroundColor(statusColor)
                    .padding(.horizontal, 7).padding(.vertical, 2)
                    .background(Capsule().fill(statusColor.opacity(0.12)))
                Text(ProgFmt.date(node.start) + " → " + ProgFmt.date(node.end)).font(.system(size: 12)).foregroundStyle(.secondary)
                Spacer()
                if node.planPct > 0 || node.pct > 0 { ProgDeltaPill(value: node.delta) }
            }
            if !node.code.isEmpty || !node.engineer.isEmpty {
                Text([node.code, node.engineer].filter { !$0.isEmpty }.joined(separator: " · "))
                    .font(.system(size: 11)).foregroundStyle(.tertiary).lineLimit(1)
            }
        }
    }
}

// MARK: - Màn chi tiết một nhánh WBS

enum ProgSort: String, CaseIterable, Identifiable {
    case order = "Mặc định", behind = "Chậm nhất", top = "Cao nhất"
    var id: String { rawValue }
}

enum ProgStateFilter: String, CaseIterable, Identifiable {
    case all = "Tất cả", doing = "Đang làm", notStarted = "Chưa bắt đầu", done = "Xong"
    var id: String { rawValue }
}

struct ProgNodeView: View {
    let node: ProgNode
    @State private var sort: ProgSort = .order
    @State private var stateFilter: ProgStateFilter = .all
    @State private var query = ""
    @ObservedObject private var tr = NativeTranslator.shared

    private func matches(_ n: ProgNode) -> Bool {
        switch stateFilter {
        case .all: break
        case .doing: if n.isDone || n.pct <= 0 { return false }
        case .notStarted: if n.pct > 0 { return false }
        case .done: if !n.isDone { return false }
        }
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        if q.isEmpty { return true }
        return n.name.lowercased().contains(q) || n.code.lowercased().contains(q) || n.engineer.lowercased().contains(q)
    }

    private var sorted: [ProgNode] {
        let base = node.children.filter { matches($0) }
        switch sort {
        case .order: return base
        case .behind: return base.sorted { $0.delta < $1.delta }
        case .top: return base.sorted { $0.pct > $1.pct }
        }
    }

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ProgCard {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(alignment: .firstTextBaseline) {
                            Text(ProgFmt.pct(node.pct, 2)).font(.system(size: 34, weight: .bold, design: .rounded))
                            Text("thực tế").font(.system(size: 13, weight: .semibold)).foregroundStyle(.secondary)
                            Spacer()
                            ProgDeltaPill(value: node.delta, suffix: " điểm")
                        }
                        ProgBar(value: node.pct, plan: node.planPct, height: 10)
                        HStack {
                            Text("Kế hoạch " + ProgFmt.pct(node.planPct, 2)).font(.system(size: 12)).foregroundStyle(.secondary)
                            Spacer()
                            Text(ProgFmt.date(node.start) + " → " + ProgFmt.date(node.end)).font(.system(size: 12)).foregroundStyle(.secondary)
                        }
                    }
                }
                if node.children.count > 1 {
                    Picker("Sắp xếp", selection: $sort) {
                        ForEach(ProgSort.allCases) { Text($0.rawValue).tag($0) }
                    }
                    .pickerStyle(.segmented)
                    Picker("Trạng thái", selection: $stateFilter) {
                        ForEach(ProgStateFilter.allCases) { Text($0.rawValue).tag($0) }
                    }
                    .pickerStyle(.segmented)
                    TextField("Tìm theo tên, mã hoặc kỹ sư", text: $query)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .padding(.horizontal, 12).padding(.vertical, 9)
                        .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
                    if sorted.count != node.children.count {
                        Text("\(sorted.count) / \(node.children.count) mục")
                            .font(.system(size: 12)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                    }
                    NativeTranslateNote()
                }
                if node.children.isEmpty {
                    Text("Nhánh này không có mục con.").font(.system(size: 14)).foregroundStyle(.secondary).padding(.top, 20)
                } else if sorted.isEmpty {
                    Text("Không có mục nào khớp bộ lọc.").font(.system(size: 14)).foregroundStyle(.secondary).padding(.top, 20)
                }
                ForEach(sorted) { c in
                    if c.isActivity || c.children.isEmpty {
                        ProgCard { c.isActivity ? AnyView(ProgActivityRow(node: c)) : AnyView(ProgRow(node: c, showChevron: false)) }
                    } else {
                        NavigationLink { ProgNodeView(node: c) } label: {
                            ProgCard { ProgRow(node: c) }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(.horizontal, 14).padding(.top, 8).padding(.bottom, 30)
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .navigationTitle(tr.t(node.name))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                NativeTranslateButton(signature: sorted.count) { [node.name] + sorted.prefix(60).map { $0.name } }
            }
        }
    }
}

// MARK: - Màn chính

struct DesmProgressSheet: View {
    @ObservedObject var model: BrowserModel
    var onClose: () -> Void
    @StateObject private var vm = DesmProgressVM()
    @ObservedObject private var tr = NativeTranslator.shared

    // MARK: các khối

    func hero(_ root: ProgNode) -> some View {
        ProgCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(vm.projectName).font(.system(size: 17, weight: .bold)).lineLimit(2)
                        Text(vm.projectCode + (vm.currentWeek.map { " · " + $0.fromNTP + " kể từ NTP" } ?? ""))
                            .font(.system(size: 12, weight: .medium)).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 8)
                    weekMenu
                }
                HStack(alignment: .center, spacing: 18) {
                    ProgRing(actual: root.pct, plan: root.planPct, line: 16)
                        .frame(width: 148, height: 148)
                    VStack(alignment: .leading, spacing: 12) {
                        metric("Kế hoạch", root.planPct, color: .progAmber, delta: root.delta)
                        metric("Catch-up", root.cuPct, color: Color.tabBlue, delta: root.pct - root.cuPct)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                HStack(spacing: 14) {
                    legendDot(Color.tabBlue, "Thực tế")
                    legendDot(Color.progAmber, "Kế hoạch (mốc cam)")
                    Spacer()
                }
            }
        }
    }

    func metric(_ title: String, _ v: Double, color: Color, delta: Double) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 5) {
                Circle().fill(color).frame(width: 7, height: 7)
                Text(title).font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary)
            }
            HStack(spacing: 8) {
                Text(ProgFmt.pct(v, 2)).font(.system(size: 20, weight: .bold, design: .rounded))
                ProgDeltaPill(value: delta)
            }
        }
    }

    func legendDot(_ c: Color, _ t: String) -> some View {
        HStack(spacing: 5) {
            Circle().fill(c).frame(width: 7, height: 7)
            Text(t).font(.system(size: 11)).foregroundStyle(.secondary)
        }
    }

    var weekMenu: some View {
        Menu {
            ForEach(vm.weeks) { w in
                Button {
                    Task { await vm.select(w.id, model: model) }
                } label: {
                    Text(w.week + " · " + w.period + " · " + w.statusTxt)
                }
            }
        } label: {
            HStack(spacing: 5) {
                Text(vm.currentWeek?.week ?? "Tuần").font(.system(size: 13, weight: .bold))
                Image(systemName: "chevron.up.chevron.down").font(.system(size: 10, weight: .bold))
            }
            .foregroundColor(Color.tabBlue)
            .padding(.horizontal, 11).padding(.vertical, 7)
            .background(Capsule().fill(Color.tabBlue.opacity(0.12)))
        }
    }

    /// Xu hướng theo tuần từ các tuần đã mở (mỗi tuần phải tải ~9 MB nên chỉ lưu những tuần người dùng đã xem).
    var trendCard: some View {
        let pts = vm.history
        return VStack(alignment: .leading, spacing: 10) {
            Text("Xu hướng theo tuần").font(.system(size: 15, weight: .bold))
            if pts.count < 2 {
                Text("Chọn thêm các tuần khác ở menu tuần để dựng biểu đồ (mỗi tuần chỉ cần mở một lần).")
                    .font(.system(size: 12)).foregroundStyle(.secondary)
            } else {
                let hi = max(1.0, (pts.map { max($0.actual, $0.plan) }.max() ?? 1) * 1.15)
                GeometryReader { g in
                    let w = g.size.width, h = g.size.height
                    let step = pts.count > 1 ? w / CGFloat(pts.count - 1) : w
                    ZStack {
                        trendPath(pts.map { $0.plan }, hi: hi, step: step, h: h)
                            .stroke(Color.progAmber, style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round, dash: [5, 4]))
                        trendPath(pts.map { $0.actual }, hi: hi, step: step, h: h)
                            .stroke(Color.tabBlue, style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
                    }
                }
                .frame(height: 120)
                HStack {
                    Text(pts.first?.week ?? "").font(.system(size: 11)).foregroundStyle(.secondary)
                    Spacer()
                    Text(pts.last?.week ?? "").font(.system(size: 11)).foregroundStyle(.secondary)
                }
                HStack(spacing: 14) {
                    legendDot(Color.tabBlue, "Thực tế " + ProgFmt.pct(pts.last?.actual ?? 0))
                    legendDot(Color.progAmber, "Kế hoạch " + ProgFmt.pct(pts.last?.plan ?? 0))
                    Spacer()
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
    }

    func trendPath(_ values: [Double], hi: Double, step: CGFloat, h: CGFloat) -> Path {
        var path = Path()
        for (i, v) in values.enumerated() {
            let pt = CGPoint(x: CGFloat(i) * step, y: h - CGFloat(v / hi) * h)
            if i == 0 { path.move(to: pt) } else { path.addLine(to: pt) }
        }
        return path
    }

    var weekInfo: some View {
        Group {
            if let w = vm.currentWeek {
                ProgCard {
                    HStack(spacing: 10) {
                        Image(systemName: "calendar").foregroundColor(Color.tabBlue)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Tuần PMS " + w.week).font(.system(size: 14, weight: .bold))
                            Text(w.period).font(.system(size: 12)).foregroundStyle(.secondary)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 4) {
                            badge(w.statusTxt, w.isProcessing ? .progAmber : .progGreen)
                            if !w.confirmTxt.isEmpty { badge(w.confirmTxt, .secondary) }
                        }
                    }
                    if w.isProcessing {
                        Text("Tuần này đang cập nhật (chưa chốt) nên số liệu có thể còn thay đổi.")
                            .font(.system(size: 12)).foregroundStyle(.secondary)
                    }
                }
            }
        }
    }

    func badge(_ t: String, _ c: Color) -> some View {
        Text(t).font(.system(size: 11, weight: .semibold)).foregroundColor(c)
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(Capsule().fill(c.opacity(0.13)))
    }

    func timeCard(_ root: ProgNode) -> some View {
        Group {
            if let s = ProgFmt.parse(root.start), let e = ProgFmt.parse(root.end), e > s {
                let cal = Calendar.current
                let total = max(1, cal.dateComponents([.day], from: s, to: e).day ?? 1)
                let passed = min(total, max(0, cal.dateComponents([.day], from: s, to: Date()).day ?? 0))
                let left = max(0, cal.dateComponents([.day], from: Date(), to: e).day ?? 0)
                let share = Double(passed) / Double(total) * 100
                ProgCard(title: "Thời gian dự án", icon: "clock") {
                    VStack(alignment: .leading, spacing: 10) {
                        ProgBar(value: share, plan: 0, height: 8)
                        HStack {
                            Text(ProgFmt.date(root.start)).font(.system(size: 12)).foregroundStyle(.secondary)
                            Spacer()
                            Text(ProgFmt.date(root.end)).font(.system(size: 12)).foregroundStyle(.secondary)
                        }
                        HStack(spacing: 18) {
                            stat("Đã qua", "\(passed) ngày", ProgFmt.pct(share, 0))
                            stat("Còn lại", "\(left) ngày", "")
                            stat("Khối lượng xong", ProgFmt.pct(root.pct, 1), "")
                        }
                    }
                }
            }
        }
    }

    func stat(_ title: String, _ value: String, _ sub: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary)
            Text(value).font(.system(size: 15, weight: .bold, design: .rounded))
            if !sub.isEmpty { Text(sub).font(.system(size: 11)).foregroundStyle(.secondary) }
        }
    }

    var activityCard: some View {
        let s = vm.stats
        return Group {
            if s.total > 0 {
                ProgCard(title: "Công việc (activity)", icon: "checklist", trailing: "\(s.total) mục") {
                    VStack(alignment: .leading, spacing: 12) {
                        GeometryReader { g in
                            let w = g.size.width
                            HStack(spacing: 2) {
                                seg(s.done, s.total, w, .progGreen)
                                seg(s.doing, s.total, w, Color.tabBlue)
                                seg(s.notStarted, s.total, w, Color(.tertiarySystemFill))
                            }
                        }
                        .frame(height: 10)
                        HStack(spacing: 8) {
                            tile("Hoàn thành", s.done, .progGreen)
                            tile("Đang làm", s.doing, Color.tabBlue)
                            tile("Chưa bắt đầu", s.notStarted, .secondary)
                        }
                    }
                }
            }
        }
    }

    @ViewBuilder
    func seg(_ n: Int, _ total: Int, _ w: CGFloat, _ c: Color) -> some View {
        if n > 0 {
            RoundedRectangle(cornerRadius: 4).fill(c)
                .frame(width: max(4, (w - 4) * CGFloat(n) / CGFloat(max(total, 1))))
        }
    }

    func tile(_ title: String, _ n: Int, _ c: Color) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 5) {
                Circle().fill(c).frame(width: 7, height: 7)
                Text(title).font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
            }
            Text("\(n)").font(.system(size: 18, weight: .bold, design: .rounded))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color(.tertiarySystemFill).opacity(0.6)))
    }

    /// Hạng mục cấp 3 ảnh hưởng nhiều nhất đến chênh lệch tổng (tính theo điểm % của cả dự án).
    struct Impact: Identifiable { let id: String; let node: ProgNode; let parent: String; let pts: Double }

    func impacts(_ root: ProgNode) -> [Impact] {
        guard root.total > 0 else { return [] }
        var out: [Impact] = []
        for a in root.children {
            for b in a.children {
                out.append(Impact(id: a.id + "/" + b.id, node: b, parent: a.name, pts: (b.actual - b.plan) / root.total * 100))
            }
        }
        return out
    }

    func attention(_ root: ProgNode) -> some View {
        let all = impacts(root)
        let behind = all.filter { $0.pts < -0.005 }.sorted { $0.pts < $1.pts }.prefix(3)
        let ahead = all.filter { $0.pts > 0.005 }.sorted { $0.pts > $1.pts }.prefix(3)
        return Group {
            if !behind.isEmpty || !ahead.isEmpty {
                ProgCard(title: "Điểm nhấn so với kế hoạch", icon: "scope", trailing: "đóng góp vào tổng") {
                    VStack(alignment: .leading, spacing: 12) {
                        if !behind.isEmpty {
                            Text("CHẬM NHẤT").font(.system(size: 11, weight: .bold)).foregroundColor(.progRed)
                            ForEach(Array(behind)) { impactRow($0) }
                        }
                        if !ahead.isEmpty {
                            Text("VƯỢT KẾ HOẠCH").font(.system(size: 11, weight: .bold)).foregroundColor(.progGreen)
                            ForEach(Array(ahead)) { impactRow($0) }
                        }
                    }
                }
            }
        }
    }

    func impactRow(_ i: Impact) -> some View {
        NavigationLink { ProgNodeView(node: i.node) } label: {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(tr.t(i.node.name)).font(.system(size: 14, weight: .semibold)).lineLimit(2)
                    Text(i.parent + " · " + ProgFmt.pct(i.node.pct, 1) + " / KH " + ProgFmt.pct(i.node.planPct, 1))
                        .font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 6)
                ProgDeltaPill(value: i.pts)
                Image(systemName: "chevron.right").font(.system(size: 11, weight: .bold)).foregroundColor(Color(.tertiaryLabel))
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    func areas(_ root: ProgNode) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Theo khu vực").font(.system(size: 17, weight: .bold)).padding(.horizontal, 4).padding(.top, 4)
            ForEach(root.children) { a in
                ProgCard {
                    VStack(alignment: .leading, spacing: 12) {
                        NavigationLink { ProgNodeView(node: a) } label: {
                            VStack(alignment: .leading, spacing: 8) {
                                HStack(alignment: .firstTextBaseline) {
                                    Text(tr.t(a.name)).font(.system(size: 16, weight: .bold))
                                    Spacer()
                                    Text("Trọng số " + ProgFmt.pct(a.weight * 100, 1)).font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary)
                                    Image(systemName: "chevron.right").font(.system(size: 11, weight: .bold)).foregroundColor(Color(.tertiaryLabel))
                                }
                                HStack(alignment: .firstTextBaseline, spacing: 8) {
                                    Text(ProgFmt.pct(a.pct, 2)).font(.system(size: 24, weight: .bold, design: .rounded))
                                    Text("KH " + ProgFmt.pct(a.planPct, 2)).font(.system(size: 12)).foregroundStyle(.secondary)
                                    Spacer()
                                    ProgDeltaPill(value: a.delta, suffix: " điểm")
                                }
                                ProgBar(value: a.pct, plan: a.planPct, height: 9)
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        if !a.children.isEmpty {
                            Divider()
                            ForEach(a.children) { b in
                                if b.children.isEmpty {
                                    ProgRow(node: b, showChevron: false)
                                } else {
                                    NavigationLink { ProgNodeView(node: b) } label: { ProgRow(node: b) }
                                        .buttonStyle(.plain)
                                }
                                if b.id != a.children.last?.id { Divider().opacity(0.5) }
                            }
                        }
                    }
                }
            }
        }
    }

    var statusBanner: some View {
        Group {
            if let e = vm.error {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.progRed)
                    Text(e).font(.system(size: 13)).foregroundColor(.progRed).frame(maxWidth: .infinity, alignment: .leading)
                    Button("Thử lại") { Task { await vm.reload(model: model) } }.font(.system(size: 13, weight: .semibold))
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.progRed.opacity(0.10)))
            } else if vm.loading {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(vm.root == nil ? "Đang tải dữ liệu tiến độ (khoảng 9 MB)…"
                         : (vm.fromCache ? "Đang hiển thị số liệu đã lưu, đang cập nhật…" : "Đang cập nhật…"))
                        .font(.system(size: 13, weight: .medium)).foregroundStyle(.secondary)
                    Spacer()
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemGroupedBackground)))
            }
        }
    }

    var footer: some View {
        VStack(alignment: .leading, spacing: 4) {
            if let u = vm.updated {
                Text((vm.fromCache ? "Số liệu đã lưu lúc " : "Cập nhật lúc ") + ProgFmt.stamp(u))
                    .font(.system(size: 11, weight: .medium)).foregroundStyle(.secondary)
            }
            Text("Nguồn: PMS Weekly Progress. Tỷ lệ = ACTUAL_QTY / TOTAL_QTY theo trọng số của hệ thống; mốc cam là kế hoạch tại thời điểm cập nhật của tuần. Kéo xuống để làm mới.")
                .font(.system(size: 11)).foregroundStyle(.tertiary)
        }
        .padding(.horizontal, 4)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 14) {
                    statusBanner
                    if let r = vm.root {
                        hero(r)
                        weekInfo
                        trendCard
                        timeCard(r)
                        activityCard
                        attention(r)
                        areas(r)
                    }
                    footer
                }
                .padding(.horizontal, 14).padding(.top, 8).padding(.bottom, 30)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Tiến độ dự án")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { onClose() } }
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 4) {
                        NativeTranslateButton(signature: vm.root?.children.count ?? 0) {
                            guard let r = vm.root else { return [] }
                            return r.children.flatMap { a in [a.name] + a.children.prefix(30).map { $0.name } }
                        }
                        Button { Task { await vm.reload(model: model) } } label: { Image(systemName: "arrow.clockwise") }
                            .disabled(vm.loading)
                    }
                }
            }
            .refreshable { await vm.reload(model: model) }
            .task { await vm.start(model: model) }
        }
    }
}
