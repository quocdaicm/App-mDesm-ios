// DesmAITools.swift — công cụ CHỈ ĐỌC cho AI riêng: danh mục API DESM, truy vấn có tham số, đọc màn đang mở.
// An toàn: chỉ cho gọi các endpoint "get/select" nằm trong danh mục dưới đây (không có save/delete/update). Chưa build/chưa thử trên máy thật.

import Foundation
import WebKit

struct DesmEndpoint {
    let path: String
    let desc: String
    let keys: [String]
    var defaults: [String: String] = [:]
}

enum DesmAITools {
    // MARK: Danh mục endpoint (tham số lấy từ các màn native của app)
    static let catalog: [DesmEndpoint] = [
        DesmEndpoint(path: "/getIdsmOsSummaryList.do",
                     desc: "Danh sách KIỆN HÀNG (Package). Có STORAGE_LOCATION (vị trí kho), trạng thái, ngày nhận, người cập nhật vị trí (LOC_UPDATED_BY, LOC_UPDATE_DATE), xác nhận (CONFIRM_DATE, CONFIRMED_BY), DESCRIPTION. Lọc theo PACKAGE_NO (số kiện, vd 0009-001), PACKAGE_LIST_NO, DESCRIPTION, VENDOR, LOCATION, START_RECEIPT_DATE/END_RECEIPT_DATE (yyyy/MM/dd), PACKAGE_STATUS.",
                     keys: ["PROJECT_NO", "PACKAGE_LIST_NO", "PACKAGE_NO", "DESCRIPTION", "IS_CONFIRM_MATERIAL", "RECEIPTED", "ATTRIBUTE10", "REMARK", "VENDOR", "LOCATION", "START_RECEIPT_DATE", "END_RECEIPT_DATE", "MRR_VISUAL_CHECK", "MRR_RECEIVED", "START_MRR_RECEIVED_DATE", "END_MRR_RECEIVED_DATE", "CUSTOMS_YN", "MIR_CATEGORY", "PACKAGE_STATUS"],
                     defaults: ["MRR_VISUAL_CHECK": "All"]),
        DesmEndpoint(path: "/getIdsmOsDetailList.do",
                     desc: "HẠNG MỤC CHI TIẾT (Detail Item List) của kiện: MATERIAL_CODE, DESCRIPTION, LOCATION (vị trí từng hạng mục), UNIT, IN_QTY, REMAIN_QTY, REMARKS, TRK_ITEM_NAME... Lọc theo PACKAGE_NO, DESCRIPTION, DRAWING_NO, TAG_NO, VENDOR. Tìm theo mã vật tư: KEY1=material và VALUE1=<Material Code>.",
                     keys: ["PAGE_NUM", "PAGE_CNT", "PROJECT_NO", "PACKAGE_LIST_NO", "PACKAGE_NO", "DESCRIPTION", "DRAWING_NO", "TAG_NO", "QTY_TYPE", "QTY", "KEY1", "VALUE1", "LOCATION", "SEQUENCE", "VENDOR", "ATTRIBUTE10", "TYPE", "CATEGORY", "SUB_CATEGORY", "COMMENTS"],
                     defaults: ["PAGE_NUM": "1", "PAGE_CNT": "300", "QTY_TYPE": "rsi"]),
        DesmEndpoint(path: "/getDesmPlDetailEditLogList.do",
                     desc: "LỊCH SỬ CHỈNH SỬA (Edit Log) của MỘT hạng mục: đổi vị trí, số lượng, ghi chú... Bắt buộc TRK_ITEM_NAME và MATERIAL_CODE (lấy từ kết quả /getIdsmOsDetailList.do).",
                     keys: ["PROJECT_NO", "TRK_ITEM_NAME", "MATERIAL_CODE"]),
        DesmEndpoint(path: "/getDesmRsiViewList.do",
                     desc: "RSI (phiếu yêu cầu vật tư) theo ngày yêu cầu START_REQUEST_DATE/END_REQUEST_DATE (yyyy/MM/dd). Lọc RSI_NO, RSI_NAME, SUBCONTRACTOR, MATERIAL_CODE, PACKAGE_NO, ITEM_DESC. Có REQ_QTY, HANDOVER_QTY, BALANCE_QTY, STATUS.",
                     keys: ["PAGE_NUM", "PAGE_CNT", "PROJECT_NO", "RSI_NO", "RSI_NAME", "SUBCONTRACTOR", "ATTRIBUTE10", "MATERIAL_CODE", "START_REQUEST_DATE", "END_REQUEST_DATE", "BALANCE_QTY", "TYPE", "CATEGORY", "SUB_CATEGORY", "PACKING_LIST_NO", "PACKAGE_NO", "ITEM_DESC", "MASTER_SHOP_UNIT", "MASTER_SHOP_BLDG", "SHOP_UNIT", "SHOP_BLDG"],
                     defaults: ["PAGE_NUM": "1", "PAGE_CNT": "1000"]),
        DesmEndpoint(path: "/getDesmRsiOutGoingList.do",
                     desc: "RSI ĐÃ BÀN GIAO (Outgoing) theo ngày bàn giao START_HANDOVER_DATE/END_HANDOVER_DATE (yyyy/MM/dd). Lọc RSI_NO, PACKAGE_NO, SUBCONTRACTOR, MATERIAL_CODE, RSI_NAME.",
                     keys: ["PAGE_NUM", "PAGE_CNT", "PROJECT_NO", "START_HANDOVER_DATE", "END_HANDOVER_DATE", "PACKAGE_NO", "SUBCONTRACTOR", "RSI_NO", "MATERIAL_CODE", "ATTRIBUTE10", "RSI_NAME", "TYPE", "CATEGORY", "SUB_CATEGORY", "COMMENTS", "PACKING_LIST_NO", "PENDING", "RECEIVER_REMARK", "MASTER_SHOP_UNIT", "MASTER_SHOP_BLDG", "SHOP_UNIT", "SHOP_BLDG"],
                     defaults: ["PAGE_NUM": "1", "PAGE_CNT": "1000"]),
        DesmEndpoint(path: "/getMrfSummaryList.do",
                     desc: "MRF (phiếu trả vật tư) đã tạo. Lọc MRF_NO, MRF_NAME, RSI_NO, PACKAGE_NO, SUBCONTRACTOR, MATERIAL_CODE. Có MRF_REQ_RETURN_QTY, MRF_RETURN_QTY, MRF_BALANCE_QTY, STATUS, RETURN_REQ_DATE.",
                     keys: ["PROJECT_NO", "RSI_NO", "RSI_NAME", "SUBCONTRACTOR", "MATERIAL_CODE", "RSI_START_REQUEST_DATE", "RSI_END_REQUEST_DATE", "ZIM_ATTRIBUTE10", "RSI_BALANCE_QTY", "TYPE", "CATEGORY", "SUB_CATEGORY", "PACKING_LIST_NO", "MRF_NO", "MRF_NAME", "PACKAGE_NO", "ITEM_DESC", "RETURN_TYPE", "MRF_BALANCE_QTY"]),
        DesmEndpoint(path: "/getDesmMrfReturnList.do",
                     desc: "MRF ĐÃ TRẢ theo ngày START_HANDOVER_DATE/END_HANDOVER_DATE (yyyy/MM/dd). Lọc MRF_NO, MRF_NAME, PACKAGE_NO, SUBCONTRACTOR, MATERIAL_CODE.",
                     keys: ["PROJECT_NO", "START_HANDOVER_DATE", "END_HANDOVER_DATE", "PACKAGE_NO", "SUBCONTRACTOR", "MRF_NO", "MATERIAL_CODE", "ATTRIBUTE10", "MRF_NAME", "TYPE", "CATEGORY"]),
        DesmEndpoint(path: "/getDesmOutGoingCreationList.do",
                     desc: "Các dòng RSI CÒN CHỜ XUẤT KHO (màn Xuất kho / OUT.G): RSI_NO, RSI_NAME, PACKAGE_NO, MATERIAL_CODE, DESCRIPTION, số lượng yêu cầu và còn xuất được, PENDING (Y = chưa duyệt). Lọc theo RSI_NO, PACKAGE_NO, SUBCON, ngày yêu cầu REQUEST_START_DATE/REQUEST_END_DATE (yyyy/MM/dd).",
                     keys: ["PROJECT_NO", "PACKING_LIST_NO", "PACKAGE_NO", "RSI_NO", "MATERIAL_CODE", "REQUEST_START_DATE", "ATTRIBUTE10", "REQUEST_END_DATE", "DESCRIPTION", "DRAWING_NO", "TAG_NO", "RSI_NAME", "TYPE", "CATEGORY", "SUBCON", "PENDING", "MASTER_SHOP_UNIT", "MASTER_SHOP_BLDG", "SHOP_UNIT", "SHOP_BLDG"]),
        DesmEndpoint(path: "/getDesmReturnCreationList.do",
                     desc: "Các dòng MRF CÒN PHẢI TRẢ (màn Trả hàng / RETURN): MRF_NO, MRF_NAME, PACKAGE_NO, MATERIAL_CODE, REQ_RETURN_QTY, RETURN_AVAILABLE_QTY. Lọc theo MRF_NO, PACKAGE_NO, MATERIAL_CODE, ngày REQUEST_START_DATE/REQUEST_END_DATE.",
                     keys: ["PROJECT_NO", "PACKAGE_NO", "MRF_NO", "MATERIAL_CODE", "REQUEST_START_DATE", "ATTRIBUTE10", "REQUEST_END_DATE", "TYPE", "CATEGORY"]),
        DesmEndpoint(path: "/getDesmRsiList.do",
                     desc: "Danh sách PHIẾU RSI (đầu phiếu, mỗi dòng một phiếu): RSI_NO, RSI_NAME, STATUS, CLOSED_CODE, SUBCONTRACTOR, ngày yêu cầu. Lọc STATUS, RSI_NO, RSI_NAME, SUBCONTRACTOR, ngày START_REQUEST_DATE/END_REQUEST_DATE.",
                     keys: ["STATUS", "CLOSED_CODE", "RSI_NO", "RSI_NAME", "DESCRIPTION", "PROJECT_NO", "START_REQUEST_DATE", "END_REQUEST_DATE", "MATERIAL_TYPE", "SUBCONTRACTOR"]),
        DesmEndpoint(path: "/getDesmMrrList.do",
                     desc: "Danh sách PHIẾU MRR (nhập kho / Material Receiving Report): MRR_NO, MRR_NAME, STATUS (Incomplete, Pre-Confirmed, Confirmed, Rejected), INVOICE, ngày nhận/kiểm tra, người lập/xác nhận. Lọc STATUS, MRR_NO, INVOICE_NO, PACKAGE_NO, SHIPMENT_NO, RECEIVED_DATE_FROM/TO, INSPECTION_DATE_FROM/TO.",
                     keys: ["STATUS", "MRR_NO", "MRR_NAME", "PROJECT_NO", "INVOICE_NO", "PACKAGE_NO", "RECEIVED_DATE_FROM", "RECEIVED_DATE_TO", "INSPECTION_DATE_FROM", "INSPECTION_DATE_TO", "SHIPMENT_NO"]),
        DesmEndpoint(path: "/material/getPlWipCreationList.do",
                     desc: "Các dòng WIP COMPLETION (hàng đã lắp/ra khỏi RSI, chờ ghi hoàn thành): RSI_NO, PACKAGE_NO, MATERIAL_CODE, SHOP_UNIT, SHOP_BLDG, số lượng bàn giao và WIP.",
                     keys: ["PROJECT_NO", "PACKING_LIST_NO", "PACKAGE_NO", "RSI_NO", "RSI_NAME", "SUBCON", "MATERIAL_CODE", "ATTRIBUTE10", "DESCRIPTION", "DRAWING_NO", "TAG_NO", "TYPE", "CATEGORY", "SUB_CATEGORY", "SHOP_UNIT", "SHOP_BLDG"]),
        DesmEndpoint(path: "/vessel/getVesselFinderList.do",
                     desc: "Danh sách TÀU / lô hàng của dự án (vị trí, tình trạng vận chuyển).",
                     keys: ["PROJECT_NO"]),
        DesmEndpoint(path: "/getNotice.do",
                     desc: "Danh sách THÔNG BÁO của DESM (để jobCode trống).",
                     keys: ["jobCode"]),
    ]

    static func catalogText(filter: String) -> String {
        let f = filter.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        var out = "Chỉ đọc. Gọi bằng desm_query(endpoint, params_json, max_rows). PROJECT_NO tự điền nếu bỏ trống. Ngày dạng yyyy/MM/dd. Tham số bỏ trống = không lọc.\n"
        for e in catalog {
            if !f.isEmpty && !(e.path.lowercased().contains(f) || e.desc.lowercased().contains(f)) { continue }
            let ks = e.keys.map { (k: String) -> String in
                if let d = e.defaults[k] { return k + "(mặc định " + d + ")" }
                return k
            }
            out += "\n• " + e.path + " — " + e.desc + "\n  Tham số: " + ks.joined(separator: ", ") + "\n"
        }
        return out
    }

    // MARK: Định nghĩa công cụ gửi cho AI
    static let toolDefs: [AIToolDef] = [
        AIToolDef(name: "desm_list_endpoints",
                  description: "Liệt kê các API DESM được phép tra cứu (chỉ đọc) kèm ý nghĩa và tham số lọc. Gọi trước khi dùng desm_query nếu chưa chắc endpoint/tham số.",
                  schema: ["type": "object",
                           "properties": ["filter": ["type": "string", "description": "Từ khoá lọc danh mục (tuỳ chọn), ví dụ rsi, mrf, kiện"]]]),
        AIToolDef(name: "desm_query",
                  description: "Tra dữ liệu thật từ DESM (chỉ đọc) bằng một endpoint trong danh mục. Trả về các dòng dạng JSON.",
                  schema: ["type": "object",
                           "properties": [
                               "endpoint": ["type": "string", "description": "Đường dẫn endpoint, ví dụ /getIdsmOsSummaryList.do"],
                               "params_json": ["type": "string", "description": "Chuỗi JSON các tham số lọc, ví dụ {\"PACKAGE_NO\":\"0009-001\"}. Bỏ trống nếu không lọc."],
                               "max_rows": ["type": "integer", "description": "Số dòng tối đa trả về (mặc định 40, tối đa 300)."],
                               "count_by": ["type": "string", "description": "Tuỳ chọn: tên một trường (vd STORAGE_LOCATION, STATUS, SUBCONTRACTOR). App đếm số dòng theo từng giá trị của trường đó trên TOÀN BỘ kết quả (kể cả giá trị trống) — dùng để trả lời câu hỏi 'bao nhiêu kiện chưa có vị trí', 'mỗi trạng thái bao nhiêu phiếu'."],
                           ],
                           "required": ["endpoint"]]),
        AIToolDef(name: "desm_lookup",
                  description: "Tra nhanh MỘT số hiệu hoặc từ khoá trên toàn DESM, không cần biết endpoint và KHÔNG cần người dùng mở màn nào: số kiện (vd 0009-001) → thông tin kiện + hạng mục; số RSI (RSI2026006 hoặc tên RSI-LLM18.1-0001) → các dòng phiếu RSI + các dòng còn chờ xuất; số MRF → phiếu MRF + dòng còn phải trả; số MRR → phiếu MRR; từ khoá khác → tìm trong mô tả kiện và hạng mục.",
                  schema: ["type": "object",
                           "properties": ["term": ["type": "string", "description": "Số kiện / số RSI / số MRF / số MRR / từ khoá cần tìm."]],
                           "required": ["term"]]),
        AIToolDef(name: "desm_read_open_page",
                  description: "Đọc nội dung màn DESM đang mở trên app (lưới, ô lọc, chữ trên trang, màn chi tiết kiện). Dùng khi người dùng hỏi về 'màn này', 'trang này', 'đang hiển thị'.",
                  schema: ["type": "object",
                           "properties": ["limit": ["type": "integer", "description": "Số ký tự tối đa (mặc định 12000, tối đa 40000)."]]]),
    ]

    // MARK: Tiện ích
    static func str(_ v: Any) -> String {
        if let s = v as? String { return s }
        if let n = v as? NSNumber { return n.stringValue }
        return ""
    }

    static func int(_ v: Any?) -> Int? {
        if let n = v as? NSNumber { return n.intValue }
        if let s = v as? String { return Int(s.trimmingCharacters(in: .whitespaces)) }
        return nil
    }

    static let maxChars = 22000

    /// Số dự án mặc định đã lấy (dùng lại 10 phút, chỉ truy cập từ luồng chính).
    static var projectCache: (no: String, at: Date)? = nil

    /// Đếm số dòng theo giá trị của một trường trên toàn bộ kết quả (trống = "(trống)"), tối đa 40 nhóm.
    static func countText(_ rows: [[String: Any]], field: String) -> String {
        var counts: [String: Int] = [:]
        for r in rows {
            let v = str(r[field] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            counts[v.isEmpty ? "(trống)" : v, default: 0] += 1
        }
        let sorted = counts.sorted { $0.value != $1.value ? $0.value > $1.value : $0.key < $1.key }
        var out = "Đếm theo " + field + " trên toàn bộ " + String(rows.count) + " dòng (" + String(counts.count) + " giá trị khác nhau):\n"
        for (k, n) in sorted.prefix(40) { out += k + " = " + String(n) + "\n" }
        if sorted.count > 40 { out += "…(còn " + String(sorted.count - 40) + " giá trị ít dòng hơn)\n" }
        return out
    }

    static func format(_ rows: [[String: Any]], maxRows: Int, ignored: [String]) -> String {
        var head = "Tổng \(rows.count) dòng"
        if rows.count > maxRows { head += ", chỉ hiện \(maxRows) dòng đầu (thu hẹp bộ lọc hoặc tăng max_rows)" }
        if !ignored.isEmpty { head += ". Đã bỏ qua tham số không có trong endpoint: " + ignored.joined(separator: ", ") }
        var out = head + ":\n"
        for r in rows.prefix(maxRows) {
            var o: [String: Any] = [:]
            for (k, v) in r {
                if let s = v as? String {
                    let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !t.isEmpty { o[k] = t }
                } else if v is NSNumber {
                    o[k] = v
                }
            }
            if let d = try? JSONSerialization.data(withJSONObject: o, options: [.sortedKeys]), let s = String(data: d, encoding: .utf8) {
                out += s + "\n"
            }
            if out.utf8.count > maxChars { out += "…(đã cắt vì quá dài, hãy thu hẹp bộ lọc)\n"; break }
        }
        return out
    }
}

extension BrowserModel {
    /// Chạy một công cụ AI xin gọi; luôn trả chuỗi (lỗi cũng là chuỗi để AI tự xử lý).
    @MainActor
    func runDesmTool(_ name: String, _ args: [String: Any]) async -> String {
        switch name {
        case "desm_list_endpoints":
            return DesmAITools.catalogText(filter: DesmAITools.str(args["filter"] ?? ""))
        case "desm_read_open_page":
            let limit = min(max(DesmAITools.int(args["limit"]) ?? 12000, 1000), 40000)
            return await readOpenPageText(limit: limit)
        case "desm_query":
            return await desmToolQuery(args)
        case "desm_lookup":
            return await desmToolLookup(DesmAITools.str(args["term"] ?? ""))
        default:
            return "Công cụ không tồn tại: " + name
        }
    }

    /// Tra nhanh một số hiệu/từ khoá: tự chọn endpoint theo dạng số (kiện, RSI, MRF, MRR) hoặc tìm theo mô tả. Chỉ đọc.
    @MainActor
    private func desmToolLookup(_ raw: String) async -> String {
        let term = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if term.isEmpty { return "Thiếu term (số kiện, số RSI/MRF/MRR hoặc từ khoá)." }
        let up = term.uppercased()
        func j(_ d: [String: String]) -> String {
            guard let data = try? JSONSerialization.data(withJSONObject: d), let t = String(data: data, encoding: .utf8) else { return "" }
            return t
        }
        func q(_ title: String, _ ep: String, _ params: [String: String], rows: Int = 40) async -> String {
            let r = await desmToolQuery(["endpoint": ep, "params_json": j(params), "max_rows": rows])
            return "### " + title + "\n" + r
        }
        var parts: [String] = []
        let isPkg = term.range(of: "^[0-9]{3,5}-[0-9]{2,4}$", options: .regularExpression) != nil
        if isPkg {
            parts.append(await q("Kiện " + term + " (STORAGE_LOCATION = vị trí kho của kiện)", "/getIdsmOsSummaryList.do", ["PACKAGE_NO": term], rows: 5))
            parts.append(await q("Hạng mục chi tiết của kiện " + term, "/getIdsmOsDetailList.do", ["PACKAGE_NO": term], rows: 40))
        } else if up.hasPrefix("RSI") {
            var rows = await q("Các dòng của phiếu " + term, "/getDesmRsiViewList.do", ["RSI_NO": term], rows: 60)
            if rows.contains("Tổng 0 dòng") && term.contains("-") {
                rows = await q("Các dòng của phiếu (theo tên RSI) " + term, "/getDesmRsiViewList.do", ["RSI_NAME": term], rows: 60)
            }
            parts.append(rows)
            parts.append(await q("Dòng còn chờ xuất kho của " + term, "/getDesmOutGoingCreationList.do", ["RSI_NO": term], rows: 40))
        } else if up.hasPrefix("MRF") {
            parts.append(await q("Phiếu MRF " + term, "/getMrfSummaryList.do", ["MRF_NO": term], rows: 60))
            parts.append(await q("Dòng MRF còn phải trả " + term, "/getDesmReturnCreationList.do", ["MRF_NO": term], rows: 40))
        } else if up.hasPrefix("MRR") {
            parts.append(await q("Phiếu MRR " + term, "/getDesmMrrList.do", ["MRR_NO": term], rows: 20))
        } else {
            parts.append(await q("Kiện có mô tả chứa \"" + term + "\"", "/getIdsmOsSummaryList.do", ["DESCRIPTION": term], rows: 20))
            parts.append(await q("Hạng mục có mô tả chứa \"" + term + "\"", "/getIdsmOsDetailList.do", ["DESCRIPTION": term], rows: 20))
        }
        return parts.joined(separator: "\n\n")
    }

    @MainActor
    private func desmToolQuery(_ a: [String: Any]) async -> String {
        let ep = DesmAITools.str(a["endpoint"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let path = ep.hasPrefix("/") ? ep : "/" + ep
        guard let e = DesmAITools.catalog.first(where: { $0.path == path }) else {
            return "Endpoint không nằm trong danh mục cho phép (chỉ đọc). Gọi desm_list_endpoints để xem danh sách."
        }
        var obj: [String: Any] = [:]
        if let s = a["params_json"] as? String {
            let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
            if !t.isEmpty {
                guard let o = (try? JSONSerialization.jsonObject(with: Data(t.utf8))) as? [String: Any] else {
                    return "params_json không phải JSON hợp lệ. Ví dụ: {\"PACKAGE_NO\":\"0009-001\"}"
                }
                obj = o
            }
        } else if let o = a["params_json"] as? [String: Any] {
            obj = o
        }
        var given: [String: String] = [:]
        var ignored: [String] = []
        for (k, v) in obj {
            if e.keys.contains(k) { given[k] = DesmAITools.str(v) } else { ignored.append(k) }
        }
        let maxRows = min(max(DesmAITools.int(a["max_rows"]) ?? 40, 1), 300)
        let countBy = DesmAITools.str(a["count_by"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)

        var project = ""
        if e.keys.contains("PROJECT_NO") {
            if let g = given["PROJECT_NO"], !g.isEmpty { project = g }
            else if let c = DesmAITools.projectCache, Date().timeIntervalSince(c.at) < 600 { project = c.no }
            else {
                do {
                    project = try await desmProjectNo()
                    DesmAITools.projectCache = (no: project, at: Date())
                } catch {
                    AILog.add("✗ Không lấy được số dự án: " + error.localizedDescription)
                    return "Không lấy được số dự án (phiên DESM có thể đã hết hạn): " + error.localizedDescription
                }
            }
        }
        var parts: [String] = []
        for k in e.keys {
            var v = given[k] ?? e.defaults[k] ?? ""
            if k == "PROJECT_NO" { v = project }
            parts.append(k + "=" + BrowserModel.enc(v))
        }
        do {
            let rows = try await desmQueryAsync(e.path, body: parts.joined(separator: "&"))
            let t1 = Date()
            let box = DesmRowsBox(isJSON: true, rows: rows)
            let text = await Task.detached(priority: .userInitiated) { () -> String in
                let all = box.rows ?? []
                let counted = countBy.isEmpty ? "" : DesmAITools.countText(all, field: countBy) + "\n"
                return counted + DesmAITools.format(all, maxRows: maxRows, ignored: ignored)
            }.value
            AILog.add("Định dạng " + String(rows.count) + " dòng → " + String(text.utf8.count / 1024) + " KB mất " + String(format: "%.2f", Date().timeIntervalSince(t1)) + "s")
            return text
        } catch {
            AILog.add("✗ " + e.path + ": " + error.localizedDescription)
            return "Lỗi gọi " + e.path + ": " + error.localizedDescription
        }
    }

    /// Đọc chữ của màn đang mở (dùng hàm `__desmDodo.pageText` do DodoBubble.swift tiêm vào trang).
    /// evaluateJavaScript có thể không bao giờ gọi lại (trang đang bận/đang chuyển trang) nên có hạn 12 giây; callback chỉ được dùng đúng một lần.
    @MainActor
    func readOpenPageText(limit: Int) async -> String {
        guard let wv = webView else { return "Không có trang nào đang mở." }
        let js = "(function(){try{return (window.__desmDodo && window.__desmDodo.pageText) ? String(window.__desmDodo.pageText(\(limit)) || '') : '';}catch(e){return '';}})()"
        let t0 = Date()
        AILog.add("Đọc trang đang mở (tối đa " + String(limit) + " ký tự)…")
        let res: String? = await withCheckedContinuation { (c: CheckedContinuation<String?, Never>) in
            let gate = AIGate()
            wv.evaluateJavaScript(js) { r, _ in
                if gate.claim() { c.resume(returning: (r as? String) ?? "") }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 12) {
                if gate.claim() { c.resume(returning: nil) }
            }
        }
        let secs = String(format: "%.1f", Date().timeIntervalSince(t0))
        guard let t = res else {
            AILog.add("✗ Đọc trang QUÁ THỜI GIAN sau " + secs + "s (trang bận hoặc đang chuyển trang)")
            return "Trang không phản hồi sau 12 giây (có thể đang tải hoặc đang bận). Hãy bảo người dùng chờ trang tải xong rồi hỏi lại."
        }
        AILog.add("← Đọc trang xong sau " + secs + "s, " + String(t.utf8.count / 1024) + " KB")
        return t.isEmpty ? "Không đọc được nội dung trang (trang trống hoặc chưa tải xong)." : t
    }
}
